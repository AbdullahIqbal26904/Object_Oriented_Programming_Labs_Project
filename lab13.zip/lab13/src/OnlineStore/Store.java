package OnlineStore;

import java.util.ArrayList;
import java.util.List;

public class Store {
    List<Product> p;
    public Store(){
        p=new ArrayList<>();
    }
    public void addProduct(Product product){
        this.p.add(product);
    }
    public void removeProduct(Product product){
        this.p.remove(product);
    }
    public void viewProduct(){
        for (Product p1:p){
            System.out.println(p1);
        }
    }
}
