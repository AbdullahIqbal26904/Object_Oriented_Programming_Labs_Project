package OnlineStore;

import java.util.List;

public class main {
    public static void main(String[] args) {
        Product p = new Product(11,"xyz","jfjfjf",76,90);
        Product p1 = new Product(12,"rtetg","jfjfjf",88,100);
        Product p2 = new Product(13,"yujj","jfjfjf",56,7);
        Store s = new Store();

        s.addProduct(p);
        s.addProduct(p1);
        s.addProduct(p2);
        s.viewProduct();
        s.removeProduct(p2);
        System.out.println("Store contains items:- ");
        s.viewProduct();

        Customer c = new Customer(87,"jkkl","afbdd");
        Order o = new Order(1,c);
        o.addItem(p,2);
        o.addItem(p1,4);
        o.addItem(p2,4);
        o.removeItem(p2,1);
        double total = o.getTotal();
        System.out.println(total);
        System.out.println();
        List<Product> p3 = o.getItems();
        System.out.println(c +"has order of:- ");
        for (Product ol:p3)
        System.out.println(ol);
        s.viewProduct();
    }
}
