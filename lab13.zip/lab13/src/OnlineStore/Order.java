package OnlineStore;

import java.util.ArrayList;
import java.util.List;

public class Order {
    int id;
    Customer customer;
    List<Product> items = new ArrayList<>();
    double total;

    public Order(int id, Customer customer) {
        this.id = id;
        this.customer = customer;
    }

    public void addItem(Product item, int qty){
        item.setQuantity(item.getQuantity()-qty);
        this.total=item.getQuantity()*item.getPrice();
        boolean found=false;
        for (Product p:items){
            if(p.getId()==item.getId()){
                p.setQuantity(p.getQuantity()+qty);
                found=true;
                break;
            }
        }
        if(!found){
            Product p = new Product(item.getId(), item.getName(),item.getDescription(), item.getPrice(), qty);
            items.add(p);
        }
    }
    public void removeItem(Product item,int qty){
        for (Product p:items){
            if(p.getId()==item.getId()){
                p.setQuantity(p.getQuantity()-qty);
                this.total -= p.getPrice()*qty;
                if(p.getQuantity()==0){
                    items.remove(p);
                }
                item.setQuantity(item.getQuantity()+qty);
                break;
            }
        }
    }
    public double getTotal(){
        return total;
    }

    public List<Product> getItems() {
        return items;
    }
}
