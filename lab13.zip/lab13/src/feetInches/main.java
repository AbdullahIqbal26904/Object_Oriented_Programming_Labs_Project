package feetInches;

public class main {
    public static void main(String[] args) {
        FeetInches f = new FeetInches(13,14);
        System.out.println(f);
        FeetInches f2 = f.add(new FeetInches(13,5));
        System.out.println(f2);
        FeetInches g = new FeetInches(new FeetInches(89,14));
        System.out.println(g);
        FeetInches noarg = new FeetInches();
        System.out.println(noarg);

    }
}
