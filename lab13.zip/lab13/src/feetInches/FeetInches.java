package feetInches;

public class FeetInches {
    int feet;
    int inches;
    public FeetInches(){
        this.feet=0;
        this.inches=0;
    }

    public int getFeet() {
        return feet;
    }

    public void setFeet(int feet) {
        this.feet = feet;
    }

    public int getInches() {
        return inches;
    }

    public void setInches(int inches) {
        this.inches = inches;
    }

    public FeetInches(int feet, int inches){
        this.feet=feet;
        this.inches=inches;
        simplify();
    }

    @Override
    public String toString() {
        return "FeetInches{" +
                "feet=" + feet +
                ", inches=" + inches +
                '}';
    }
    public FeetInches add(FeetInches f){
        int total=f.inches+this.inches;
        int total2=f.feet+this.feet;
        return new FeetInches(total2,total);
    }

    public FeetInches(FeetInches feetInches){
        this.feet=feetInches.feet;
        this.inches=feetInches.inches;
    }
    public void simplify(){
        if(inches>11) {feet++;
        this.inches=inches-12;}
    }
}
