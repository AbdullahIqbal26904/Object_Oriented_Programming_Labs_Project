package Problem_3;

public class main {
    public static void main(String[] args){
        point p1 = new point(2,2);
        point p2 = new point(3,7);
        System.out.println(p1);
        System.out.println(p2);
        System.out.println(p1.check());
        System.out.println(p2.check());
    }
}
