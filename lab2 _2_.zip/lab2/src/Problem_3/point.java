package Problem_3;

public class point {

    private int x;
    private int y;
    public point(int x,int y){
        this.x=x;
        this.y=y;
    }
    public boolean check(){
        if(x==y)
        {
            return true;
        }
        return false;
    }
    public String toString(){
        return "x: "+x+" y: "+y;
    }
}
