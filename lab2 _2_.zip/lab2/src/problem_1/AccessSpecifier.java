package problem_1;

public class AccessSpecifier {
    private int privateVar =0;
    protected int protectedVar=0;
    int defaultVar=0;
    public int publicVar=0;

    private void privateMethod(){
        this.privateVar++;
    }
    protected void protectedMethod(){
        protectedVar++;

    }
    public void defaultMethod(){
        defaultVar++;
    }
    public void publicMethod(){
        publicVar++;
    }

}
