package problem_1;

public class testAccessSpecifier {
    public static void main(String[] args){
        AccessSpecifier as1 = new AccessSpecifier();
        //System.out.println(as1.privateVar);
        //System.out.println(as1.privateMethod);
        as1.protectedMethod();
        System.out.println(as1.protectedVar);
        System.out.println(as1.defaultVar);
        as1.defaultMethod();
        System.out.println(as1.publicVar);
        as1.publicMethod();

    }
}
