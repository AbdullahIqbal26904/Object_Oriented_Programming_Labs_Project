package problem2;
public class Student
{
        String fname,sname;
        String[] courses = new String[10];
        int a;

public  Student(String fname,String sname){
        this.fname=fname;
        this.sname=sname;
        this.courses[0]="Maths :";
        a=random();
        this.courses[1]=String.valueOf(a)+" "+calculateGrade(String.valueOf(a));
        this.courses[2]="computer :";
        a=random();
        this.courses[3]=String.valueOf(a)+" "+calculateGrade(String.valueOf(a));
        this.courses[4]="discreete maths :";
        a=random();
        this.courses[5]=String.valueOf(a)+" "+calculateGrade(String.valueOf(a));
        this.courses[6]="history :";
        a=random();
        this.courses[7]=String.valueOf(a)+" "+calculateGrade(String.valueOf(a));
        this.courses[8]="English :";
        a=random();
        this.courses[9]=String.valueOf(a)+" "+calculateGrade(String.valueOf(a));
        }
public String getName(){
        return fname;
        }
public String getsName(){
        return sname;
        }
public int random(){
        return (int)(Math.random()*101);
        }
public String calculateGrade(String a) {
        if (Integer.parseInt(a) > 90) {
        return "A";
        }
        if (Integer.parseInt(a) > 80) {
        return "B";
        }
        if (Integer.parseInt(a) > 70) {
        return "C";
        }
        if (Integer.parseInt(a) > 60) {
        return "D";
        }
        return "fail";
        }
public String getDetails(){
        return "first name: " + fname +"\nSecond name: "+ sname;
        }
    public static void main(String[] args){
        String[] fName = {"Abdullah","Shiraz","ali","ahmed","abc","cde","efg","oki","kjhu","lkjhh"};
        String[] sName = {"iop","tre","ghjk","qasz","hgfd","hgf","jhgf","edxc","edfv","bvgc"};

        Student s1 = new Student(fName[(int)(Math.random()*10)],sName[(int)(Math.random()*10)]);
        Student s2 = new Student(fName[(int)(Math.random()*10)],sName[(int)(Math.random()*10)]);
        Student s3 = new Student(fName[(int)(Math.random()*10)],sName[(int)(Math.random()*10)]);
        Student s4 = new Student(fName[(int)(Math.random()*10)],sName[(int)(Math.random()*10)]);
        Student s5 = new Student(fName[(int)(Math.random()*10)],sName[(int)(Math.random()*10)]);
        Student s6 = new Student(fName[(int)(Math.random()*10)],sName[(int)(Math.random()*10)]);
        Student s7 = new Student(fName[(int)(Math.random()*10)],sName[(int)(Math.random()*10)]);
        Student s8 = new Student(fName[(int)(Math.random()*10)],sName[(int)(Math.random()*10)]);
        Student s9 = new Student(fName[(int)(Math.random()*10)],sName[(int)(Math.random()*10)]);
        Student s10 = new Student(fName[(int)(Math.random()*10)],sName[(int)(Math.random()*10)]);
        Student s[] = {s1,s2,s3,s4,s5,s6,s7,s8,s9,s10};
        for(int i=0; i< s.length; i++){
            System.out.println(s[i].getDetails());
            System.out.println();
            for(int x=0;x<s[i].courses.length;x+=2){
                System.out.print(s[i].courses[x]+" ");
                System.out.print(s[i].courses[x+1]+" ");
                System.out.println();
            }
            System.out.println();
        }
    }
        }
