package problem2;

public class Main {
    public static void main(String[] args){
        String[] fName = {"Abdullah","Shiraz","ali","ahmed","abc","cde","efg","oki","kjhu","lkjhh"};
        String[] sName = {"iop","tre","ghjk","qasz","hgfd","hgf","jhgf","edxc","edfv","bvgc"};

        Student s1 = new Student(fName[(int)(Math.random()*10)],sName[(int)(Math.random()*10)]);
        Student s2 = new Student(fName[(int)(Math.random()*10)],sName[(int)(Math.random()*10)]);
        Student s3 = new Student(fName[(int)(Math.random()*10)],sName[(int)(Math.random()*10)]);
        Student s4 = new Student(fName[(int)(Math.random()*10)],sName[(int)(Math.random()*10)]);
        Student s5 = new Student(fName[(int)(Math.random()*10)],sName[(int)(Math.random()*10)]);
        Student s6 = new Student(fName[(int)(Math.random()*10)],sName[(int)(Math.random()*10)]);
        Student s7 = new Student(fName[(int)(Math.random()*10)],sName[(int)(Math.random()*10)]);
        Student s8 = new Student(fName[(int)(Math.random()*10)],sName[(int)(Math.random()*10)]);
        Student s9 = new Student(fName[(int)(Math.random()*10)],sName[(int)(Math.random()*10)]);
        Student s10 = new Student(fName[(int)(Math.random()*10)],sName[(int)(Math.random()*10)]);
        Student s[] = {s1,s2,s3,s4,s5,s6,s7,s8,s9,s10};
        for(int i=0; i< s.length; i++){
            System.out.println(s[i].getDetails());
            System.out.println();
            for(int x=0;x<s[i].courses.length;x+=2){
                System.out.print(s[i].courses[x]+" ");
                System.out.print(s[i].courses[x+1]+" ");
                System.out.println();
            }
            System.out.println();
        }
    }
}
