import java.util.Scanner;

public class p5 {
    public static void div(int a , int b){
        int r=0;
        try {
            r = a/b;
        }catch (ArithmeticException e){
            Scanner sc = new Scanner(System.in);
            int m = sc.nextInt();
            while (m==0){
                System.out.println("Re enter number");
                m=sc.nextInt();
            }
            r=a/m;
        }
        System.out.println(r);
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        div(Integer.parseInt(sc.next()),0);
    }
}
