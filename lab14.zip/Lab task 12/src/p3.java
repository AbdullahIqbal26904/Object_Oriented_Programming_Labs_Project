import java.util.Scanner;

public class p3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter number 1");
        String a = sc.next();
        System.out.println("Enter 2 number");
        String b = sc.next();
        try {
            System.out.println(Integer.parseInt(b)-Integer.parseInt(a));
        }catch (Exception e){
            if(b.length()>Integer.parseInt(a))
                System.out.print(b.substring(0,Integer.parseInt(a)));
            else {
                System.out.println("Not possible");
            }
        }
    }
}
