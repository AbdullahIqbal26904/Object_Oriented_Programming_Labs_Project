import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class p2 {
    public static void main(String[] args) {
        Random r = new Random();
        int[]  a= new int[5];
        for(int i=0;i<a.length;i++){
            a[i]= r.nextInt();
        }
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter index: ");
        String n = sc.next();
        System.out.println("Enter number.");
        String num = sc.next();
        try {
            a[Integer.parseInt(n)]=Integer.parseInt(num);
            System.out.println(Arrays.toString(a));
        }catch (ArrayIndexOutOfBoundsException e){
            if(Integer.parseInt(n)>5){
                int[] g = new int[Integer.parseInt(n)];
               for (int i=0;i<a.length;i++){
                   g[i]=a[i];
               }
                g[Integer.parseInt(n)-1]=Integer.parseInt(num);
                System.out.println(Arrays.toString(g));
            }
        }
    }
}
