import java.util.Scanner;

public class p4driver {
    public static void sod(int a) throws SOD{
        if (a>999) throw new SOD("Num greater than 999");
        else if(a<0) throw new SOD("Number is negative");
        else System.out.println((a%1000)/100+(a%100)/10+a%10);
    }
    public static void main(String[] args) throws SOD{
        Scanner sc = new Scanner(System.in);
        sod(56);
        sod(1000);
    }

}
