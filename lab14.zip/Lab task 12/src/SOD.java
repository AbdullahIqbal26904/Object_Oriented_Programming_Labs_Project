public class SOD extends Exception{
    public SOD(String message) {
        super(message);
    }
}
