import java.util.InputMismatchException;
import java.util.Scanner;

public class p1 {
    public static void main(String[] args) {
        String a,b;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter first number");
        a = sc.next();
        System.out.println("Enter second number");
        b =sc.next();


        try {
            int result = Integer.parseInt(a)*Integer.parseInt(b);
            System.out.println(result);
        }catch (NumberFormatException e){
            System.out.println(repeat(a,
                    b));
    }
    }
    public static String repeat(String a,String b){
        StringBuilder  r=new StringBuilder();
        for (int i=0;i<Integer.parseInt(a);i++){
            r.append(b);
        }
        return r.toString();
    }
}
