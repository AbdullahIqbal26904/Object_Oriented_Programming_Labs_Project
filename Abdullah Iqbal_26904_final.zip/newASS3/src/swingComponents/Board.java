package swingComponents;

import myComponents.*;
import myComponents.Button;
import myComponents.Rectangle;
import myComponents.Shape;

import javax.swing.*;
import javax.swing.event.MouseInputListener;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class Board extends JPanel implements ActionListener , MouseInputListener{

    private final int B_WIDTH = 1080;
    private final int B_HEIGHT = 720;
    private final int DELAY = 10;
    private Shape currentShape;
    private Ctb  colorToolbar;
    Tooltip t;
    private final ArrayList<Tooltip> tooltips = new ArrayList<>();
    private ArrayList<Tooltip> tt = new ArrayList<>();

    private Timer timer;
    Shape shapebeingdrawn;
    stacks shapeStack = new stacks();
    private ltb Layerbar;
    private Button current_shape;
    private int key = 0;
    private Grid grid;
    private Rectangle currentRectangle;
    private shapesToolbar shapes;
    private ltb layerTool;
    private boolean keyPressed = false;
    private boolean mousePressed = false;

    private boolean start_drawing = false;
    private menuBar Menu;

    Image pressed;
    Image depressed;

    private int x_init;
    private int y_init;
    private int x_final;
    private int y_final;
    private FreeDrawing freeDrawing;
    public ltb getLayerbar() {
        return Layerbar;
    }

    public void setLayerbar(ltb layerbar) {
        Layerbar = layerbar;
    }
    private class TAdapter extends KeyAdapter {

        @Override
        public void keyReleased(KeyEvent e) {
            
            int key = e.getKeyCode();
            System.out.println(key);
            keyPressed = false;

            if (key == KeyEvent.VK_SPACE) {
                
            }

        }

        @Override
        public void keyPressed(KeyEvent e) {

        	keyPressed = true;
            key = e.getKeyCode();

            if (key == KeyEvent.VK_SPACE) {
                
            }

        }
    }

    public Board() {

        InitBoard();
       // freeDrawing = new FreeDrawing(Color.blue,6);
    }
    void DrawingPanel()
    {
        setBackground( Color.WHITE );
        setPreferredSize( new Dimension( B_WIDTH, B_HEIGHT ) );
        this.addMouseListener( this );
        this.addMouseMotionListener(this  );
        setFocusable(true);
    }

    private void InitializeAssets() {

        
        ImageIcon button_dep = new ImageIcon("src/square_depressed.png");
        depressed=button_dep.getImage();
        ImageIcon button_pre = new ImageIcon("src/square_pressed.png");
        pressed=button_pre.getImage();

    }

    private void InitBoard() {

    	addMouseListener( this );
    	addMouseMotionListener( this );
    	addKeyListener(new TAdapter());
        setBackground(Color.WHITE);
        setPreferredSize(new Dimension(B_WIDTH, B_HEIGHT));
        setFocusable(true);

        InitializeAssets();

        Menu = new menuBar(0, 0, 700, 32, depressed, pressed,this);
        shapes= new shapesToolbar(200,0,40,500,pressed,depressed);
        colorToolbar =new Ctb(500,0,B_WIDTH,40);
        layerTool=new ltb(900,40,B_WIDTH,B_HEIGHT,pressed,depressed);
        grid=new Grid();
        tt=shapes.getTooltips();
        tt.add(new Tooltip(colorToolbar.getEditButton(),"Edit Color"));
        timer = new Timer(10, this);
        timer.start();
    }


    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Menu.paint(g,this);
        shapes.paint(g,this);
        colorToolbar.paint(g,this);
        layerTool.paint(g,this);


        drawButton(g);
        for (LayerButton lb : layerTool.getLayers()) {
            for (Shape s : lb.getShapes()) {
                s.draw(g);
            }
        }

        if (currentShape != null) {
            currentShape.draw(g);
        }
        //freeDrawing.draw(g);
    }

    
    private void drawNotification(String text, Graphics g)
    {
    	g.setColor(Color.RED);
    	g.drawString(text + key + " pressed", 20, 20);
    }

    private void drawButton(Graphics g) {
        grid.paint(g);
        if(t!=null){
            t.paint(g);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        
        Toolkit.getDefaultToolkit().sync();
        repaint();
    }
    
    public void IsClicked(int x, int y)
    {
    }


	@Override
	public void mouseClicked(MouseEvent e) {
		    Menu.click(e.getX(),e.getY());
            //Menu.handleClick(e.getX(),e.getY());
            shapes.click(e.getX(),e.getY());
        colorToolbar.click(e.getX(),e.getY());
            layerTool.click(e.getX(),e.getY());
        grid.handleClick(e.getX(),e.getY());

        //IsClicked(e.getX(),e.getY());
//        if(shapesToolbar.freedrawing){
//            freeDrawing.draw(getGraphics());
//        } else if (shapesToolbar.rectangledraw) {
//            shapesToolbar.rectangledraw=false;
//            Rectangle.startPoint = new Point(e.getX(),e.getY());
//            currentRectangle = new Rectangle(Rectangle.startPoint);
//        }
	}
    int width,height,x1,y1,size;
    ArrayList<Shape> shapes1;
	@Override
	public void mousePressed(MouseEvent e) {
        // TODO Auto-generated method stub
        if (e.getY() >= 120 && e.getX() <= 750) {
            if (shapesToolbar.freedrawing) {
                if (currentShape instanceof FreeDrawing) currentShape.processMouseEvent(e);
                currentShape = new FreeDrawing(6);

            }


//            if (shapesToolbar.freedrawing) {
//            }

            if (shapesToolbar.rectangledraw) {
                currentShape = new Rectangle(e.getPoint());
            }
            if (shapesToolbar.rightangledraw) {
                currentShape = new Rightangletriangle(e.getPoint(), e.getPoint());
            }
            if (shapesToolbar.triangledraw) {
                currentShape = new EquilateralTriangle(e.getPoint());
            }

            if (shapesToolbar.hexagondraw) {
                currentShape = new Hexagon(e.getPoint());
            }
            if (shapesToolbar.circledraw) {
                currentShape = new Circle(e.getPoint());
            }
            if (shapesToolbar.pentagramdraw) {
                currentShape = new Pentagram(e.getPoint());
            }
        }}

	@Override
	public void mouseReleased(MouseEvent e) {
        if (e.getY() >= 65 && e.getX() <= 750) {
            if (currentShape != null) {
                layerTool.getTopLayer().add(currentShape);
                currentShape = null;
            }
        }
    }
	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
	}


	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub

	}

	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
        if (e.getY() >= 110 && e.getX() <= 750) {
            if (currentShape instanceof FreeDrawing) currentShape.processMouseEvent(e);
        }

        if (currentShape != null) currentShape.setEndPoint(e.getPoint());
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		x_final = e.getX() - x_init;
		y_final = e.getY() - y_init;

        if((e.getX()>=200&&e.getX()<=300)&&(e.getY()>=0&&e.getY()<=40)){
           t= tt.get(0);
        } else if ((e.getX()>=300&&e.getX()<=400)&&(e.getY()>=0&&e.getY()<=40)) {
            t=tt.get(1);
        }
        else if ((e.getX()>=400&&e.getX()<=500)&&(e.getY()>=0&&e.getY()<=40)) {
            t=tt.get(2);
        }
        else if ((e.getX()>=200&&e.getX()<=300)&&(e.getY()>=40&&e.getY()<=80)) {
            t=tt.get(3);
        }else if ((e.getX()>=300&&e.getX()<=400)&&(e.getY()>=40&&e.getY()<=80)) {
            t=tt.get(4);
        }else if ((e.getX()>=400&&e.getX()<=500)&&(e.getY()>=40&&e.getY()<=80)) {
            t=tt.get(5);
        } else if ((e.getX()>=900&&e.getX()<=1000)&&(e.getY()>=0&&e.getY()<=40)) {
            t=tt.get(6);
        } else t=null;
	}
 }