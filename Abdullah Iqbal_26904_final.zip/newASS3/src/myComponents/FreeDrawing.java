package myComponents;

import java.awt.*;
import java.awt.Point;
import java.util.List;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

public class FreeDrawing extends Shape {
    private final ArrayList<Point> points;
    private final int radius;

    public FreeDrawing(int radius) {
        super();
        this.radius = radius;
        points = new ArrayList<>();
    }

    @Override
    public void draw(Graphics g) {
        g.setColor(Ctb.getStrokeColor());
        for (Point point : points) {
            int x = (int) point.getX();
            int y = (int) point.getY();
            g.fillOval(x - radius, y - radius, radius * 2, radius * 2);
        }
    }

    @Override
    public void processMouseEvent(MouseEvent event) {
        int x = event.getX();
        int y = event.getY();
        if (event.getID() == MouseEvent.MOUSE_PRESSED) {
            points.add(new Point(x, y));
        } else if (event.getID() == MouseEvent.MOUSE_DRAGGED) {
            points.add(new Point(x, y));
        }
    }

    @Override
    public void setEndPoint(Point endPoint) {

    }
}
