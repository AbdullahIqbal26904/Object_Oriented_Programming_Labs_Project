package myComponents;

import java.io.File;
import java.io.IOException;

public class SaveFile {
    public SaveFile(){ }

    public void FileSave() throws IOException {
        String fileSeparator = System.getProperty("file.separator");

        //  C:\Users\Irtiza\Downloads\src\Open
        String absoluteFilePath = fileSeparator + "Users" + fileSeparator + "hp" + fileSeparator + "IdeaProjects" + fileSeparator +"newASS3" +fileSeparator+"src"+fileSeparator+"Files.txt";
        File file = new File(absoluteFilePath);
        if (file.createNewFile()) {
            System.out.println(absoluteFilePath + " File Created");
        } else System.out.println("File " + absoluteFilePath + " already exists");


        file = new File("C:\\Users\\hp\\IdeaProjects\\newASS3\\src\\Files");
        if (file.createNewFile()) {
            System.out.println("file.txt File Created in Project root directory");
        } else System.out.println("File file.txt already exists in the project root directory");


        String relativePath = "tmp" + fileSeparator + "file.txt";
        file = new File(relativePath);
        if (file.createNewFile()) {
            System.out.println(relativePath + " File Created in Project root directory");
        } else System.out.println("File " + relativePath + " already exists in the project root directory");
    }
}
