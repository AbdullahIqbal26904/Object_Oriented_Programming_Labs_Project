package myComponents;

import javax.swing.*;
import java.awt.*;
import java.awt.image.ImageObserver;
import java.io.Serializable;
import java.util.ArrayList;

public class LayerButton extends MyButton implements Serializable {
    private final ArrayList<Shape> shapes = new ArrayList<>();

    public ArrayList<Shape> getShapes() {
        return shapes;
    }

    public LayerButton(int x, int y, int width, int height, String text, Image i_depressed, Image i_pressed) {
        super(x, y, width, height, text, i_depressed, i_pressed);
    }

    public LayerButton(int x, int y, int width, int height, Image icon, Image i_depressed, Image i_pressed) {
        super(x, y, width, height, icon, i_depressed, i_pressed);
    }

    public LayerButton(int x, int y, int width, int height, Color selectedcolor, Image i_depressed, Image i_pressed) {
        super(x, y, width, height, selectedcolor, i_depressed, i_pressed);
    }

    public LayerButton(int x, int y, int length, int height) {
        super(x, y, length, height);
    }

    public LayerButton(int x, int y, int width, int height, String text) {
        super(x, y, width, height, text);
    }
}
