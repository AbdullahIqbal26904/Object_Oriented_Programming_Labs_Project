package myComponents;

import java.awt.*;
import java.awt.event.MouseEvent;

public abstract class Shapefreedraw {
    private Color color;

    public Shapefreedraw(Color color) {
        this.color = color;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public abstract void draw(Graphics g);

    public abstract void processMouseEvent(MouseEvent event);
}
