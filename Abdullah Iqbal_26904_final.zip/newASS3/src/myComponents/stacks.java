package myComponents;

public class stacks {
    public Node head;
    Shape s;
    public void push(Shape shape){
        if(head==null){
            head=new Node(shape);
            return;
        }
        Node current = new Node(shape);
        current.next=head;
        head=current;
//        while (current.next!=null){
//            current=current.next;
//        }
//        current.next=new Node(shape);
    }
    public Shape pop(){
        if(head!=null){
            s= head.shape;
            head=head.next;
            return s;

        }else{
            System.out.println("Stack is null.");
            return null;
        }
    }
    public static void printStack(stacks a){
        if(a.head==null){
            return;
        }
        while (a.head!=null){
            System.out.println(a.head.shape);
            a.head=a.head.next;
        }
    }
}
