package myComponents;

import java.awt.*;
import java.awt.Point;

public interface PositionListener {
    void click(int x, int y);
    void press(int x, int y);
    void release(int x, int y);
    void drawTooltips(Graphics g);

    void setTooltipsVisible(Boolean b, Point p);
}
