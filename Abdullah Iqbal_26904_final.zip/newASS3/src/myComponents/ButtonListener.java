package myComponents;

public interface ButtonListener {
    void onClick(int x,int y);
}
