package myComponents;

import swingComponents.Board;

import javax.swing.*;
import java.awt.*;
import java.awt.Point;
import java.awt.image.ImageObserver;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class menuBar implements PositionListener {
    private int x;
    private int y;
    private int width;
    private int height;
    private boolean clicked = false;
    boolean filed=false;
    boolean editeD=false;
    Graphics g;
    ImageObserver observer;
    SaveFile saveFile;

    ArrayList<MyButton> buttons = new ArrayList<>();
    ArrayList<MyButton> fileDropdown = new ArrayList<>();
    ArrayList<MyButton> EditDropDown = new ArrayList<>();
    MyButton b1,b2,b3;
    private final ArrayList<MyButton> file_names = new ArrayList<>();
    private Window openingWindow;
    private Board board;


    public menuBar(int x, int y, int width, int height,Image pre,Image dep,Board board){
        this.x=x;
        this.y=y;
        this.width=width;
        this.height=height;
        this.board=board;

        MyButton button1 = new MyButton(0,0,100,40,"File",pre,dep);
        MyButton button2 = new MyButton(100,0,100,40,"Edit",pre,dep);
        b1 = new  MyButton(0,40,100,40,"New",pre,dep);
        b2 = new MyButton(0,80,100,40,"Open",pre,dep);
        b3 = new MyButton(0,120,100,40,"Save",pre,dep);
        buttons.add(button1);
        buttons.add(button2);
        openingWindow = new Window(200,200,200,200, "Open FIle",board);

        button1.setListener(new ButtonListener() {
            @Override
            public void onClick(int x, int y) {
                //System.out.println("file clicked");

                fileDropdown.add(b1);
                fileDropdown.add(b2);
                fileDropdown.add(b3);
                b1.setListener(new ButtonListener() {
                    @Override
                    public void onClick(int x, int y) {
                        //createNewFile();
                        newFile();
                        System.out.println("new clicked");
                    }
                });
                b2.setListener(new ButtonListener() {
                    @Override
                    public void onClick(int x, int y) {
                        openFile();
                        System.out.println("Open clicked");
                    }
                });
                b3.setListener(new ButtonListener() {
                    @Override
                    public void onClick(int x, int y) {
                        saveFile();
                        System.out.println("Save clicked");
                    }
                });

                filed=true;
                System.out.println("File clicked");
            }
        });
        button2.setListener(new ButtonListener() {
            @Override
            public void onClick(int x, int y) {
                System.out.println("edit clicked");
                MyButton e1 = new MyButton(100,40,100,40,"Undo",pre,dep);
                MyButton e2 =  new MyButton(100,80,100,40,"Redo",pre,dep);
                EditDropDown.add(e1);
                EditDropDown.add(e2);
                e1.setListener(new ButtonListener() {
                    @Override
                    public void onClick(int x, int y) {
                        System.out.println("Undo clicked");
                    }
                });
                e2.setListener(new ButtonListener() {
                    @Override
                    public void onClick(int x, int y) {
                        System.out.println("Redo clicked");
                    }
                });

                editeD=true;
            }
        });
    }
    public void paint(Graphics g, ImageObserver observer){
        g.setColor(Color.lightGray);
        g.fillRect(x,y,width,height);
        for (MyButton b: buttons){
            b.paint(g,observer);
        }
        for (MyButton b2:fileDropdown){
            b2.paint(g,observer);
            if(editeD){
                for (MyButton b3:EditDropDown){
                    b3.paint(g,observer);
                }
            }
//            if(openingWindow.getVisible()){
                openingWindow.paint(g);
//                for(MyButton b:file_names){
//                    b.paint4(g);
//                }
//            }
        }}

    @Override
    public void click(int x, int y) {
        for (MyButton b: buttons){
            b.IsClicked(x,y);
            if(b.IsPressed()){
                b.getListener().onClick(x,y);
            }
        }
//        if (b2.Clicked(x, y)) {
//            openingWindow.setVisible(true);
//            openFiles();
//        }
        for (MyButton b2: fileDropdown){
            b2.IsClicked(x,y);
            if(b2.IsPressed()){
                b2.getListener().onClick(x,y);
            }
        }
        for (MyButton b2: EditDropDown){
            b2.IsClicked(x,y);
            if(b2.IsPressed()){
                b2.getListener().onClick(x,y);
            }
        }
        if (openingWindow.getVisible()){
            openingWindow.onClick(x,y);
        }

    }

    public void handleClick(int inputX, int inputY) {
//        if (!openingWindow.getVisible()) {
//            if (openingWindow.getVisible()) {
//                if (b1.Clicked(inputX, inputY)) {
//                    createNewFile();
//                }
//                if (b1.Clicked(inputX, inputY)) {
//                    openingWindow.setVisible(true);
//                    openFiles();
//                }
//                if (b2.Clicked(inputX, inputY)) {
//                    System.out.println("New Project Open");
//                }
//            }
        }
//        else if (openingWindow.getVisible()) {
//            for(MyButton b : file_names){
//                if(b.IsClicked(inputX,inputY)){
//                    System.out.println(b.getText()+" Opened");
//                    openingWindow.setVisible(false);
//                    break;
//                }
//            }
//            if (openingWindow.Clicked(inputX, inputY)) {
//                openingWindow.setVisible(false);
//            }
//        }

    public static void createNewFile() { //option 1

//        Date date = Calendar.getInstance().getTime();
//        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-hh-mm-ss");
//        String strDate = dateFormat.format(date);
//
//        if (!(new File("./src/saves/").exists())){
//            new File("./src/saves/").mkdir();
//        }
//        File f = new File("./src/saves/"+strDate+".dat");
//        ObjectOutputStream o = null;
//        try {
//            o = new ObjectOutputStream(new FileOutputStream(f));
//            o.writeObject(board.getLayerbar());
//        } catch (IOException e) {
//            throw new RuntimeException(e);
//        }

    }
    public void openFiles(){ //option 3
        File file = new File("src/saves");
        String[] names = file.list();
        int y = 300;
        for (String name : names) {
            MyButton button = new MyButton(150, y, 300, 50, Color.BLACK, Color.GRAY, name);
            file_names.add(button);
            y += 50;
        }
    }
    private void newFile() {
        ImageIcon button_dep = new ImageIcon("src/square_depressed.png");
        Image notpress = button_dep.getImage();
        ImageIcon button_pre = new ImageIcon("src/square_pressed.png");
        Image press = button_pre.getImage();
        board.setLayerbar(new ltb(752, 52, 192, 650, notpress, press));
    }
    private void saveFile(){
        Date date = Calendar.getInstance().getTime();
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd-hh-mm-ss");
        String strDate = dateFormat.format(date);

        if (!(new File("./src/saves/").exists())){
            new File("./src/saves/").mkdir();
        }
        File f = new File("./src/saves/"+strDate+".dat");
        ObjectOutputStream o = null;
        try {
            o = new ObjectOutputStream(new FileOutputStream(f));
            o.writeObject(board.getLayerbar());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    private void openFile() {
        System.out.println("open file");
        openingWindow.setVisible(true);
    }


    @Override
    public void press(int x, int y) {

    }

    @Override
    public void release(int x, int y) {

    }

    @Override
    public void drawTooltips(Graphics g) {

    }

    @Override
    public void setTooltipsVisible(Boolean b, Point p) {

    }
}
