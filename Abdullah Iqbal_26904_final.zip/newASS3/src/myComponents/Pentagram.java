package myComponents;

import java.awt.*;
import java.awt.Point;
import java.awt.event.MouseEvent;

public class Pentagram extends Shape {
    private final java.awt.Point startPoint;
    private java.awt.Point endPoint;

    public Pentagram(java.awt.Point startPoint) {
        super();
        this.startPoint = startPoint;
        this.endPoint = startPoint;
    }

    public void setEndPoint(Point endPoint) {
        this.endPoint = endPoint;
    }

    @Override
    public void draw(Graphics g) {
        int x1 = startPoint.x;
        int y1 = startPoint.y;
        int x2 = endPoint.x;
        int y2 = endPoint.y;

        int radius = (int) Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));

        double angle = Math.toRadians(36); // 36 degrees for each point of the star
        int[] xPoints = new int[10];
        int[] yPoints = new int[10];

        for (int i = 0; i < 10; i++) {
            if (i % 2 == 0) {
                xPoints[i] = (int) (x1 + radius * Math.cos(i * angle));
                yPoints[i] = (int) (y1 + radius * Math.sin(i * angle));
            } else {
                xPoints[i] = (int) (x1 + (radius / 2) * Math.cos(i * angle));
                yPoints[i] = (int) (y1 + (radius / 2) * Math.sin(i * angle));
            }
        }
        Graphics2D g2d = (Graphics2D) g;

        g2d.setStroke(new BasicStroke(3));
        g2d.setColor(Ctb.getFillColor());
        g2d.fillPolygon(xPoints, yPoints, 10);
        g2d.setColor(Ctb.getStrokeColor());
        g2d.drawPolygon(xPoints, yPoints, 10);
    }


    @Override
    public void processMouseEvent(MouseEvent event) {

    }
}
