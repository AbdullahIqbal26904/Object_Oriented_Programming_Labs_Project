package myComponents;

import swingComponents.Board;

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;

public class Window extends MyButton  {
    private final MyButton topBar;
    private ArrayList<MyButton> filesnames;
    private final MyButton closeButton;
    private boolean visible;
    private Board board;

    public Window(int x, int y, int width, int height, String text,Board board) {
        super(x, y, width, height,Color.BLACK, Color.GRAY);

        int topBarHeight = 30;
        topBar = new MyButton(x, y, width, topBarHeight, Color.BLACK, Color.GRAY, text);

        int closeButtonSize = 20;
        filesnames = new ArrayList<>();
        visible=false;
        closeButton = new MyButton(x + width - closeButtonSize - 5, y + 5, closeButtonSize, closeButtonSize,  Color.WHITE, Color.RED);
        this.board=board;
    }
    public void onClick(int x, int y){
        if (visible){
            for (MyButton b: filesnames){
                if (b.IsClicked(x, y)) {
                    ObjectInputStream o = null;
                    try {
                        o = new ObjectInputStream(new FileInputStream("./src/saves/"+b.getText()));
                        board.setLayerbar((ltb) o.readObject());
                        visible = false;
                        return;
                    } catch (IOException | ClassNotFoundException e) {
                        throw new RuntimeException(e);
                    }
                }

            }
        }


    }

    public void paint(Graphics g) {
        if(!visible ) return;
        super.paint4(g);
        topBar.paint4(g);
        closeButton.paint4(g);
        loadFiles();
        for (MyButton b:filesnames){
        b.paint(g,null);
        }
    }
    public void loadFiles(){

        ImageIcon button_dep = new ImageIcon("src/square_depressed.png");
        Image notpress = button_dep.getImage();
        ImageIcon button_pre = new ImageIcon("src/square_pressed.png");
        Image press = button_pre.getImage();


        File ff = new File("./src/saves/");
        File[] files = ff.listFiles();

        for (int i = 0; i < files.length; i++) {
            filesnames.add(new MyButton(x, y + 32*(i+1), 100, 32, files[i].getName(), notpress, press));
        }
    }

    public boolean Clicked(int x, int y){
        return closeButton.Clicked(x,y);
    }

    public void setVisible(boolean visible){
        this.visible = visible;
    }

    public boolean getVisible(){
        return visible;
    }
}
