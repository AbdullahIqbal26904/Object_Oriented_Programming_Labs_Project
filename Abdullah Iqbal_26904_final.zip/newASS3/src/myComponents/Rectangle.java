package myComponents;

import java.awt.*;
import java.awt.Point;
import java.awt.event.MouseEvent;

public class Rectangle extends Shape  {
    public java.awt.Point startPoint;
    public java.awt.Point endPoint;


    public Rectangle(java.awt.Point startPoint) {
        super();
        this.startPoint = startPoint;
        this.endPoint = startPoint;
    }

    @Override
    public void draw(Graphics g) {
        int x = Math.min(startPoint.x, endPoint.x);
        int y = Math.min(startPoint.y, endPoint.y);
        int width = Math.abs(startPoint.x - endPoint.x);
        int height = Math.abs(startPoint.y - endPoint.y);
        g.setColor(getFillColor());
        g.fillRect(x, y, width, height);
        Graphics2D g2d = (Graphics2D) g;
        g2d.setStroke(new BasicStroke(3.0f));
        g2d.setColor(getStrokeColor());
        g.drawRect(x, y, width, height);
    }

    @Override
    public void processMouseEvent(MouseEvent event) {

    }

    public void setEndPoint(Point endPoint) {
        this.endPoint = endPoint;
    }
}
