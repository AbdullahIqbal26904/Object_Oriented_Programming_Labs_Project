package myComponents;

import java.awt.*;
import java.awt.Point;
import java.awt.event.MouseEvent;

public class EquilateralTriangle extends Shape {
    private final java.awt.Point startPoint;
    private java.awt.Point endPoint;

    public EquilateralTriangle(java.awt.Point startPoint) {
        super();
        this.startPoint = startPoint;
        this.endPoint = startPoint;
    }

    public void setEndPoint(Point endPoint) {
        this.endPoint = endPoint;
    }

    @Override
    public void draw(Graphics g) {
        g.setColor(Ctb.getFillColor());

        int[] xPoints = {startPoint.x, endPoint.x, startPoint.x + (endPoint.x - startPoint.x) / 2};
        int[] yPoints = {startPoint.y, startPoint.y, endPoint.y};

        Polygon triangle = new Polygon(xPoints, yPoints, 3);
        Graphics2D g2d = (Graphics2D) g;
        g2d.fill(triangle);
        g2d.setColor(Ctb.getStrokeColor());
        g2d.draw(triangle);
    }

    @Override
    public void processMouseEvent(MouseEvent event) {

    }

}
