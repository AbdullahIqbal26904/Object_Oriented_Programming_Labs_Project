package myComponents;

import java.awt.*;
import java.awt.Point;
import java.awt.event.MouseEvent;

public abstract class Shape {
    private Color fillColor, strokeColor;

    public Shape() {
        this.fillColor = new Color(Ctb.selectedcolor.getRGB());
        this.strokeColor = new Color(Ctb.selectedcolor.getRGB());
    }

    public Color getFillColor() {
        return fillColor;
    }

    public void setFillColor(Color fillColor) {
        this.fillColor = fillColor;
    }

    public Color getStrokeColor() {
        return strokeColor;
    }

    public void setStrokeColor(Color strokeColor) {
        this.strokeColor = strokeColor;
    }

    public abstract void draw(Graphics g);

    public abstract void processMouseEvent(MouseEvent event);

    public abstract void setEndPoint(Point endPoint);
}
