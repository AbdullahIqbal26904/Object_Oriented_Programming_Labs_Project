package myComponents;

public class Node {
    public Shape shape;
    public Node next;
    public Node(Shape shape){
        this.shape=shape;
        this.next=null;
    }
}
