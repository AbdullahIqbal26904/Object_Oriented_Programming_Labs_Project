package myComponents;

import java.awt.*;
import java.awt.Point;
import java.awt.event.MouseEvent;


public class Rightangletriangle extends Shape {
    private final java.awt.Point startPoint;
    private java.awt.Point endPoint;

    public Rightangletriangle(java.awt.Point startPoint, java.awt.Point endPoint) {
        super();
        this.startPoint = startPoint;
        this.endPoint = endPoint;
    }

    public void draw(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setStroke(new BasicStroke(3.0f));
        g2d.setColor(getFillColor());

        int x1 = startPoint.x;
        int y1 = startPoint.y;
        int x2 = endPoint.x;
        int y2 = endPoint.y;

        int width = Math.abs(x2 - x1);
        int height = Math.abs(y2 - y1);

        // Find the coordinates of the third point for the right-angled triangle
        int x3, y3;
        if (x2 >= x1 && y2 >= y1) {
            x3 = x1;
            y3 = y2;
        } else if (x2 < x1 && y2 >= y1) {
            x3 = x2;
            y3 = y1;
        } else if (x2 >= x1 && y2 < y1) {
            x3 = x2;
            y3 = y1;
        } else {
            x3 = x1;
            y3 = y2;
        }

        int[] xPoints = {x1, x2, x3};
        int[] yPoints = {y1, y2, y3};

        g2d.fillPolygon(xPoints, yPoints, 3);
        g2d.setColor(getStrokeColor());
        g2d.drawPolygon(xPoints, yPoints, 3);
    }

    @Override
    public void processMouseEvent(MouseEvent event) {

    }

    public void setEndPoint(Point endPoint) {
        this.endPoint = endPoint;
    }

}
