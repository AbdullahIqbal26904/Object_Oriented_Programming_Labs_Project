package myComponents;

import java.awt.*;
import java.awt.Point;
import java.awt.event.MouseEvent;

public class Circle extends Shape{
    private final java.awt.Point startPoint;
    private java.awt.Point endPoint;

    public Circle(java.awt.Point startPoint) {
        super();
        this.startPoint = startPoint;
        this.endPoint = startPoint;
    }

    public void setEndPoint(Point endPoint) {
        this.endPoint = endPoint;
    }

    @Override
    public void draw(Graphics g) {
        int x1 = startPoint.x;
        int y1 = startPoint.y;
        int x2 = endPoint.x;
        int y2 = endPoint.y;

        int radius = (int) Math.sqrt(Math.pow(x2 - x1, 2) + Math.pow(y2 - y1, 2));

        int centerX = x1 - radius;
        int centerY = y1 - radius;
        Graphics2D g2d = (Graphics2D) g;
        //these 2 are new lines
        g2d.setColor(Ctb.getFillColor());
        g2d.fillOval(centerX, centerY, 2 * radius, 2 * radius);
        //
        g2d.setStroke(new BasicStroke(2));
        g2d.setColor(Ctb.getStrokeColor());
        g2d.drawOval(centerX, centerY, 2 * radius, 2 * radius);
    }

    @Override
    public void processMouseEvent(MouseEvent event) {

    }
}
