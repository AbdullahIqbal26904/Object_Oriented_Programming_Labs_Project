package myComponents;

import java.awt.*;

public class Grid extends Button{
    private int count;
    public Grid() {
        super(500, 70, 100, 40, Color.BLACK, Color.WHITE, "Grid");
    }

    public void handleClick(int x, int y){
        if(super.Clicked(x,y)){
            if(count == 64){
                count = 0;
            }
            else if(count == 0){
                count += 2;
            }
            else{
                count *= 2;
            }
        }
    }

    public void paint(Graphics g) {
        super.paint(g);
        if (count != 0) {
            int y = 120;
            int x = 0;
            for (int i = 0; i < 900/count ; i++) {
                g.drawLine(0, y + count, 900, y + count);
                y += count;
                g.drawLine(x+count,120,x+count,900);
                x += count;
            }
        }
    }
}
