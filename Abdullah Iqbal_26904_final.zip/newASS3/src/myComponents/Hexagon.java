package myComponents;

import java.awt.*;
import java.awt.Point;
import java.awt.event.MouseEvent;
import java.awt.geom.Path2D;

public class Hexagon extends Shape {
    private final java.awt.Point startPoint;
    private java.awt.Point endPoint;

    public Hexagon(java.awt.Point startPoint) {
        super();
        this.startPoint = startPoint;
        this.endPoint = startPoint;
    }

    public void setEndPoint(Point endPoint) {
        this.endPoint = endPoint;
    }

    @Override
    public void draw(Graphics g) {
        int x1 = startPoint.x;
        int y1 = startPoint.y;
        int x2 = endPoint.x;
        int y2 = endPoint.y;

        int radius = Math.max(Math.abs(x2 - x1), Math.abs(y2 - y1));

        int centerX = x1 + radius;
        int centerY = y1 + radius;

        int[] xPoints = new int[6];
        int[] yPoints = new int[6];

        for (int i = 0; i < 6; i++) {
            double angle = 2.0 * Math.PI * (i + 0.5) / 6;
            xPoints[i] = (int) (centerX + radius * Math.cos(angle));
            yPoints[i] = (int) (centerY + radius * Math.sin(angle));
        }

        Path2D path = new Path2D.Double();
        path.moveTo(xPoints[0], yPoints[0]);
        for (int i = 1; i < 6; i++) {
            path.lineTo(xPoints[i], yPoints[i]);
        }
        path.closePath();
        Graphics2D g2d = (Graphics2D) g;
        g2d.setStroke(new BasicStroke(3));
        g2d.setColor(Ctb.getFillColor());
        g2d.fill(path);
        g2d.setColor(Ctb.getStrokeColor());
        g2d.draw(path);
    }


    @Override
    public void processMouseEvent(MouseEvent event) {

    }
}
