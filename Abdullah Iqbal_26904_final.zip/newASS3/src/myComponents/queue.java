package myComponents;

public class queue {
    Node head;
    public void enqueue(Shape shape){
        if(head==null){
            head=new Node(shape);
            return;
        }
        Node current = head;
        while (current.next!=null){
            current=current.next;
        }
        current.next=new Node(shape);
    }
    public Shape dequeue(){
        if(head==null){
            return null;
        }
        Shape s = head.shape;
        head=head.next;
        return s;
    }
    public static void printQueue(queue a){
        if(a.head==null){
            return;
        }
        while (a.head!=null){
            System.out.println(a.head.shape);
            a.head=a.head.next;
        }
    }
}
