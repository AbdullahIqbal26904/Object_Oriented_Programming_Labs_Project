package myComponents;

import javax.swing.*;
import java.awt.*;
import java.awt.Point;
import java.awt.image.ImageObserver;
import java.io.Serializable;
import java.util.ArrayList;

public class ltb implements PositionListener, Serializable {
    private final int x;
    private final int y;
    private final int width;
    private final int height;
    private ArrayList<LayerButton> Layers = new ArrayList<>();
    private MyButton deleteButton, AddButton, UpButton, DownButton;
    private int layerCount = 0;
    private ImageIcon press, not_pressed;

    public ltb(int x, int y, int width, int height, Image press, Image not_pressed) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.press = new ImageIcon(press);
        this.not_pressed = new ImageIcon(not_pressed);

        deleteButton = new MyButton(900, 70, 40, 32, "DEL", not_pressed, press);
        deleteButton.setListener(new ButtonListener() {
            @Override
            public void onClick(int x, int y) {
                deleteLayer();
            }
        });

        AddButton = new MyButton(940, 70, 40, 32, "ADD",not_pressed , press);
        AddButton.setListener(new ButtonListener() {
            @Override
            public void onClick(int x, int y) {
                addLayer();
            }
        });

        UpButton = new MyButton(980, 70, 40, 32, "UP", not_pressed, press);
        UpButton.setListener(new ButtonListener() {
            @Override
            public void onClick(int x, int y) {
                upLayer();
            }
        });

        DownButton = new MyButton(1020, 70, 40, 32, "DWN", not_pressed, press);
        DownButton.setListener(new ButtonListener() {
            @Override
            public void onClick(int x, int y) {
                downLayer();
            }
        });

        LayerButton layer1 = new LayerButton(900, 102, 165, 32, "Background", not_pressed, press);
        Layers.add(layer1);
        layerCount++;
        addLayer();
        addLayer();
    }

    private void downLayer() {
        for (int i = 0; i < Layers.size() - 1; i++) {
            if (Layers.get(i).IsPressed()) {
                Layers.get(i).y += 32;
                Layers.get(i + 1).y -= 32;

                LayerButton first = Layers.get(i);
                LayerButton second = Layers.get(i + 1);
                Layers.remove(i);
                Layers.add(i, second);
                Layers.remove(i + 1);
                Layers.add(i + 1, first);
                break;
            }
        }
    }

    private void upLayer() {
        if (Layers.size() == 1) return;
        for (int i = 1; i < Layers.size(); i++) {
            if (Layers.get(i).IsPressed()) {
                if (Layers.get(i).y == 102) continue;
                Layers.get(i).y -= 32;
                Layers.get(i - 1).y += 32;

                LayerButton first = Layers.get(i);
                LayerButton second = Layers.get(i - 1);
                Layers.remove(i);
                Layers.add(i, second);
                Layers.remove(i - 1);
                Layers.add(i - 1, first);

            }
        }

    }

    private void addLayer() {
        Layers.add(new LayerButton(900, 120 + 32 * layerCount, 165, 32, "Layer" + layerCount, not_pressed.getImage(), press.getImage()));
        layerCount++;
    }

    private void deleteLayer() {
        if (Layers.size()==1) return; //dont delete the last layer
        for (int i = 0; i < Layers.size(); i++) {
            if (Layers.get(i).IsPressed()) {
                for (int j = i + 1; j < Layers.size(); j++) {
                    Layers.get(j).y -= 32;
                }
                Layers.remove(Layers.get(i));
                layerCount--;
            }
        }
    }

    public ArrayList<LayerButton> getLayers() {
        return Layers;
    }

    public ArrayList<Shape> getTopLayer(){
        return Layers.get(0).getShapes();
    }
    public void paint(Graphics g, ImageObserver observer) {
        g.setColor(Color.gray);
        g.fillRect(x, y, width, height);

        for (MyButton b : Layers) {
            b.paint(g, observer);
        }

        deleteButton.paint(g,observer);
        AddButton.paint(g, observer);
        UpButton.paint(g, observer);
        DownButton.paint(g, observer);
    }


    @Override
    public void click(int x, int y) {
        for (MyButton b : Layers) {
            b.IsClicked2(x, y);
            if (b.IsPressed()) {
                for (MyButton b2 : Layers) {
                    if (b2.equals(b)) continue;
                    b2.setPressed(false);
                }
            }
        }
        if (deleteButton.IsClicked(x, y)) {
            deleteButton.getListener().onClick(x, y);
            deleteButton.setPressed(false);
        }

        if (AddButton.IsClicked(x, y)) {
            AddButton.getListener().onClick(x, y);
            AddButton.setPressed(false);
        }

        if (UpButton.IsClicked(x, y)) {
            UpButton.getListener().onClick(x, y);
            UpButton.setPressed(false);
        }

        if (DownButton.IsClicked(x, y)) {
            DownButton.getListener().onClick(x, y);
            DownButton.setPressed(false);
        }
    }

    @Override
    public void press(int x, int y) {
    }

    @Override
    public void release(int x, int y) {
    }

    @Override
    public void drawTooltips(Graphics g) {
//        AddButton.drawTooltip(g);
//        UpButton.drawTooltip(g);
//        DownButton.drawTooltip(g);
//        deleteButton.drawTooltip(g);
    }

    @Override
    public void setTooltipsVisible(Boolean bb, Point p) {
//        AddButton.setTooltipVisible(AddButton.contains(p));
//        UpButton.setTooltipVisible(UpButton.contains(p));
//        DownButton.setTooltipVisible(DownButton.contains(p));
//        deleteButton.setTooltipVisible(deleteButton.contains(p));

    }

}
