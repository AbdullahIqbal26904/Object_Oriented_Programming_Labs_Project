package problem1;

import java.util.ArrayList;

public class Project {
    private int linesOfCode;
    private int linesOfCodeWritten;
    private int linesOfCodeTested;
    private int duration;
    private ArrayList<Employee> employees = new ArrayList<>();

    public Project(int linesOfCode, int duration) {
        this.linesOfCode = linesOfCode;
        this.duration=duration;
        this.employees=new ArrayList<>();
        this.linesOfCodeWritten=0;
        this.linesOfCodeTested=0;
    }
    public void addEmployee(Employee e){
        employees.add(e);
    }
    public int doProject(){
        int daysOverdue=0;
        if(!isProjectCompleted()){
            for (Employee employee: employees){
                int linesWorked = employee.work();
                if(employee instanceof Programmer){
                    addLinesOfCodeWritten(linesWorked);
                } else if (employee instanceof Tester) {
                    addLinesOfCodeTested(linesWorked);
                }
            }
        }
        daysOverdue++;
        return daysOverdue-duration;
    }
    public void addLinesOfCodeWritten(int lw){
        this.linesOfCodeWritten+=lw;
    }
    public void addLinesOfCodeTested(int lt){
        this.linesOfCodeTested+=lt;
    }
    public boolean isProjectCompleted(){
        return linesOfCodeWritten>=linesOfCode;
    }

    @Override
    public String toString() {
        return "Project{" +
                "linesOfCode=" + linesOfCode +
                ", linesOfCodeWritten=" + linesOfCodeWritten +
                ", linesOfCodeTested=" + linesOfCodeTested +
                ", duration=" + duration +
                ", employees=" + employees +
                '}';
    }
}
