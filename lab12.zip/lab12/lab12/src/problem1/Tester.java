package problem1;

public class Tester extends Employee{
     int linesOfCode;

    public Tester(String name, int idNum) {
        super(name, idNum);
        this.linesOfCode=work();
    }

    @Override
    public String toString() {
        return "Tester{" +
                "name='" + name + '\'' +
                ", IdNum=" + IdNum +
                '}';
    }

    @Override
    public double salary() {
        return linesOfCode*0.01;
    }

    @Override
    public int work() {
        return 150+(int) (Math.random()*101);
    }
}
