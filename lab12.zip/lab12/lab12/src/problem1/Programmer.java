package problem1;

public class Programmer extends Employee{
    double rate;
    int time;
    public Programmer(String name, int idNum,double rate,int time) {
        super(name, idNum);
        this.rate=rate;
        this.time=time;
    }

    @Override
    public String toString() {
        return "Programmer{" +
                "name='" + name + '\'' +
                ", IdNum=" + IdNum +
                '}';
    }

    @Override
    public double salary() {
        double salary = work()*rate*(time/60);
        return salary;
    }

    @Override
    public int work() {
        return 500+((int) (Math.random() * 1000));
    }
}
