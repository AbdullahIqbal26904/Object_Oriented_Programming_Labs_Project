package problem1;

public class main {
    public static void main(String[] args) {
        Project p = new Project(1000,10);
        p.addEmployee(new Programmer("xyz",12,0.1,60));
        p.addEmployee(new Programmer("rew",151,0.09,60));
        p.addEmployee(new Tester("ght",345));
        p.addEmployee(new Tester("xyz",346));
        int daysOverdue = p.doProject();
        if(daysOverdue>0) System.out.println("Project completed on time");
        else System.out.println("Project was overdue by "+daysOverdue);
        System.out.println(p.toString());;

    }
}
