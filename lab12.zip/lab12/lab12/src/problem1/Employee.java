package problem1;

public abstract class Employee {
    String name;
    int IdNum;

    public abstract int work();

    public Employee(String name, int idNum) {
        this.name = name;
        IdNum = idNum;
    }
    public abstract double salary();

    public String getName() {
        return name;
    }

    public int getIdNum() {
        return IdNum;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setIdNum(int idNum) {
        IdNum = idNum;
    }
}
