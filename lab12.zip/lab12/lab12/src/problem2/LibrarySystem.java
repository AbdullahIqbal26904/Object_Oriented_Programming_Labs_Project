package problem2;

public class LibrarySystem {
    public static void main(String[] args) {
        // Create a library
        Library library = new Library();

        // Create some books
        Book book1 = new Book("The Catcher in the Rye", "J.D. Salinger", "Fiction");
        Book book2 = new Book("To Kill a Mockingbird", "Harper Lee", "Fiction");
        Book book3 = new Book("The Great Gatsby", "F. Scott Fitzgerald", "Fiction");
        Book book4 = new Book("1984", "George Orwell", "Fiction");

      User user1 = new User("Abdullah","abcd",123);
        User user2 = new User("Abdullah","abcd",123);
//        user1.addCheckoutHistory(book1);
//        user1.addCheckoutHistory(book2);
//        user1.addCheckoutHistory(book3);
//        user1.addCheckoutHistory(book4);

//        System.out.println(user1.getCheckoutHistory());
//        user1.removeCheckoutHistory(book1);
//        System.out.println(book1.isAvailability());
//        System.out.println(book2.isAvailability());
//        System.out.println(user1.getCheckoutHistory());
//        System.out.println(user1);

        library.addBook(book1);
        library.addBook(book2);
        library.addBook(book3);
        library.addBook(book4);
        library.addUser(user1);
        library.addUser(user2);
        library.checkOutBook(book1,user1);
        library.displayAllBooks();
        System.out.println(book1.isAvailability());
        library.displayAllUsers();
        System.out.println(book2.isAvailability());
        System.out.println("books borrowed: "+library.getBooksBorrowed());
        library.updateBookInfo(book1,"abc","jkl","lki");
        library.displayAllBooks();
        library.returnBook(book1,user1);
        library.displayAllUsers();
    }
}