package problem2;

import java.time.LocalDate;
import java.util.ArrayList;

public class User {
        private String name;
        private String address;
    LocalDate d = LocalDate.now();

    private int contact;
        private ArrayList<Book> checkoutHistory;

        // Constructor
        public User(String name, String address,int contact) {
            this.name = name;
            this.address = address;
            this.contact=contact;
            this.checkoutHistory = new ArrayList<>();
        }

        // Getters and Setters
        public String getName() {
            return name;
        }

        public String getAddress() {
            return address;
        }

        public int getContact() {
            return contact;
        }

        public ArrayList<Book> getCheckoutHistory() {
            return checkoutHistory;
        }

        // Methods to manage checkout history
        public void addCheckoutHistory(Book book) {
            checkoutHistory.add(book);
            book.setAvailability(false);
            book.setDueDate( d);
        }

        public void removeCheckoutHistory(Book book) {
            checkoutHistory.remove(book);
            book.setAvailability(true);
        }

    @Override
    public String toString() {
        return "User{" +
                "name='" + name + '\'' +
                ", address='" + address + '\'' +
                ", contact=" + contact +
                ", checkoutHistory=" + checkoutHistory +
                '}';
    }
}
