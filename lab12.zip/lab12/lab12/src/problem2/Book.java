package problem2;

import java.time.LocalDate;
import java.util.Date;

public class Book {
    private String title;
    private String author;
    private String subject;
    private boolean availability;
    private Date checkout;
    private LocalDate dueDate;

    public void setAvailability(boolean availability) {
        this.availability = availability;
    }


    public void setCheckout(Date checkout) {
        this.checkout = checkout;
    }

    public void setDueDate(LocalDate dueDate) {
        this.dueDate = dueDate;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getSubject() {
        return subject;
    }

    public boolean isAvailability() {
        return availability;
    }


    public Date getCheckout() {
        return checkout;
    }

    public LocalDate getDueDate() {
        return dueDate;
    }


    public Book(String title, String author, String subject) {
        this.title = title;
        this.author = author;
        this.subject = subject;
        availability=true;
    }

    @Override
    public String toString() {
        return "Book{" +
                "title='" + title + '\'' +
                ", author='" + author + '\'' +
                ", subject='" + subject + '\'' +
                ", availability=" + availability +
                ", checkout=" + checkout +
                ", dueDate=" + dueDate +
                '}';
    }
}
