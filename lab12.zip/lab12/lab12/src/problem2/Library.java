package problem2;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Library {
    private List<Book> books;
    private List<User> users;
    List<Book> booksBorrowed = new ArrayList<>();
    private static int br;

    public Library() {
        this.books = new ArrayList<>();
        this.users = new ArrayList<>();
    }
    public void updateBookInfo(Book book, String title, String author, String subject) {
        book.setTitle(title);
        book.setAuthor(author);
        book.setSubject(subject);
        System.out.println("book updated");
    }

    // Methods to manage books
    public void addBook(Book book) {
        books.add(book);
    }

    public void removeBook(Book book) {
        books.remove(book);
    }

    public Book findBookByTitle(String title) {
        for (Book book : books) {
            if (book.getTitle().equalsIgnoreCase(title)) {
                return book;
            }
        }
        return null;
    }

    public Book findBookByAuthor(String author) {
        for (Book book : books) {
            if (book.getAuthor().equalsIgnoreCase(author)) {
                return book;
            }
        }
        return null;
    }

    public Book findBookBySubject(String subject) {
        for (Book book : books) {
            if (book.getSubject().equalsIgnoreCase(subject)) {
                return book;
            }
        }
        return null;
    }
    public void  booksBorrowed(Book book){
        br++;
        booksBorrowed.add(book);
    }
    public List<Book> getBooksBorrowed(){
        return booksBorrowed;
    }

    public void displayAllBooks() {
        System.out.println("Books in Library:");
        for (Book book : books) {
            System.out.println(book.toString());
        }
    }

    // Methods to manage users
    public void addUser(User user) {
        users.add(user);
    }

    public void removeUser(User user) {
        users.remove(user);
    }

    public User findUserByName(String name) {
        for (User user : users) {
            if (user.getName().equalsIgnoreCase(name)) {
                return user;
            }
        }
        return null;
    }

    public void displayAllUsers() {
        System.out.println("Users in Library:");
        for (User user : users) {
            System.out.println(user.toString());
        }
    }

    // Methods to manage checked-out books
    public void checkOutBook(Book book, User user) {
        if (book.isAvailability()) {
            user.addCheckoutHistory(book);

        } else {
            System.out.println("book is already checked out");
        }
    }
    public void returnBook(Book book, User user) {
        ArrayList<Book> b = user.getCheckoutHistory();
        boolean contains=false;
        for (Book b2 : b){
            if(b2==book) contains=true;
        }
        if(contains){
            user.removeCheckoutHistory(book);
            System.out.println("book returned from the user");
        }
    }
//

}
