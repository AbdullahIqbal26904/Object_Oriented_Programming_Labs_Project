/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package accessspecifiers_demo;

/**
 *
 * @author ibm
 */
public class AccessSpecifiers_Demo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Access_Specifer obj=new Access_Specifer();
        
        
        System.out.println("Object1: "+obj);
         System.out.println();
        
         Access_Specifer obj2 =  new Access_Specifer("Ali", "Ahmed");
         System.out.println("Object2: "+obj2);
         System.out.println();
         
         String[] temp = {"claws", "tail"};
         
        Access_Specifer obj3 =  new Access_Specifer("Angry", "Man", 200, false, temp);
        System.out.println("Object3: "+obj3);
        System.out.println();
        
        
        
        Access_Specifer obj4 =  new Access_Specifer(obj3);
        System.out.println("object4: "+obj4);
        System.out.println();
        obj3.SetEquipment("Teeth", "Rope");
        System.out.println("Object4 :"+obj4);
        
    }
    
}
