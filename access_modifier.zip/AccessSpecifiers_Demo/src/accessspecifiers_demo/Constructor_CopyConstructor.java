package accessspecifiers_demo;
class Pet
{
    public String name = "doge";
}

class Superhero
{
    private String fname = "Mosquito";
    private String lname = "Man";
    private int height = 178;
    private boolean flies = true;
    
    private String[] equipment = { "utility belt", "sword" };
    
    public Superhero()
    {
        
    }
    
    public Superhero(String fname, String lname)
    {
        this.fname = fname;
        this.lname = lname;
    }
    
    public Superhero(String fname, String lname, int height, boolean flies, String[] equipment )
    {
        this(fname, lname);
        this.height = height;
        this.flies = flies;
        this.equipment = equipment;
    }
    
    public Superhero(Superhero other )
    {
        fname = other.fname;
        lname = other.lname;
        height = other.height;
        flies = other.flies;
        //Shallow Copying
        equipment = other.equipment; 
        //Deep Copying
        //equipment[0] = other.equipment[0];
        //equipment[1] = other.equipment[1];
    }
    
    public void SetEquipment(String one, String two)
    {
        equipment[0] = one;
        equipment[1] = two;
    }
    
    public void Details()
    {
        System.out.println("First Name:\t" + fname);
        System.out.println("Last Name:\t" + lname);
        System.out.println("Height:\t" + height + " cm");
        if(flies)
            System.out.println("Flies:\t" + "yes");
        else
            System.out.println("Flies:\t" + "no");
        System.out.println("Equipment: " + equipment[0] + ", " + equipment[1]);
    }
    
}

public class Constructor_CopyConstructor{
    public static void main(String[] args) {
        Superhero hero1 =  new Superhero();
        hero1.Details();
        System.out.println();
        Superhero hero2 =  new Superhero("Gulab", "Jamun");
        hero2.Details();
        System.out.println();
        String[] temp = {"claws", "tail"};
        Superhero hero3 =  new Superhero("Angry", "Man", 200, false, temp);
        hero3.Details();
        System.out.println();
        Superhero hero4 =  new Superhero(hero3);
        hero4.Details();
        System.out.println();
        hero3.SetEquipment("Teeth", "Rope");
        hero4.Details();
    }
}