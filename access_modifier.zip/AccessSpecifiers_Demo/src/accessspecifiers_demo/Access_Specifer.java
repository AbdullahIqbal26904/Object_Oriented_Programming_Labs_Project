/*


 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package accessspecifiers_demo;

import java.util.Arrays;
import java.util.Objects;

 public class Access_Specifer {
   private String fname;
   public String name;
   protected String lname;
   int height;
   public boolean flies ;
   private String[] equipment = { "utility belt", "sword" };
//Constructor Chaining

   public Access_Specifer(String fname, String lname, int height, boolean flies, String[] equipment) {
        this(fname,lname);
        this.height = height;
        this.flies = flies;
        this.equipment = equipment;
    }

    public Access_Specifer() {
        System.out.println("No argument constructor invoked");
    }
    public Access_Specifer(Access_Specifer obj) {
    fname=obj.fname;
    lname=obj.lname;
    flies=obj.flies;
    equipment[0] = obj.equipment[0];
    equipment[1] = obj.equipment[1];  
    }
    public Access_Specifer(String fname, String lname) {
        
        this.fname = fname;
        this.lname = lname;
    }

    public Access_Specifer(String name) {
        this.name = name;
    }
    
    public void SetEquipment(String one, String two)
    {
        equipment[0] = one;
        equipment[1] = two;
    }

    @Override
    public String toString() {
        return "Access_Specifer{" + "\nfname=" + fname + ", \n lname=" + lname + ",\n height=" + height + ", \nflies=" + flies + ", \nEquipment:" + equipment[0] + " , " + equipment[1] + '}';
    }



}



