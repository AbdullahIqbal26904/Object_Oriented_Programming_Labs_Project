/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Demo_package;

import accessspecifiers_demo.*;

/**
 *
 * @author ibm
 */
public class NewClass extends Access_Specifer {
    public static void main(String[] args) {
        Access_Specifer obj=new Access_Specifer();
        
        NewClass obj3=new NewClass();
                obj3.lname="hello";
      
//  obj3.height=123;
    }
}
