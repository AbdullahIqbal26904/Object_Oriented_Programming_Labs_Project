public class ComplimentaryTicket extends fixedpriceticket {

    public ComplimentaryTicket() {
        super(0.0);
    }

    public String toString() {
        return super.toString() + "\nThis ticket is complimentary!";
    }
}
