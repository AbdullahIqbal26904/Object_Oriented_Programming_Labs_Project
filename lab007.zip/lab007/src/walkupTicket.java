public class walkupTicket extends fixedpriceticket {

    public walkupTicket() {
        super(50.0);
    }

    public String toString() {
        return super.toString() + "\nThis is a walk-up ticket!";
    }
}