import java.util.ArrayList;
import java.util.Random;

public abstract class ticket {
    private int serialNumber;

    private static ArrayList<Integer> assignedSerialNumbers = new ArrayList<>();

    public ticket() {
        Random rand = new Random();
        int newSerialNumber = rand.nextInt(1000000);
        while (assignedSerialNumbers.contains(newSerialNumber)) {
            newSerialNumber = rand.nextInt(1000000);
        }
        assignedSerialNumbers.add(newSerialNumber);
        this.serialNumber = newSerialNumber;
    }

    public abstract double getPrice();

    public int getSerialNumber() {
        return this.serialNumber;
    }

    public String toString() {
        return "Serial Number: " + this.serialNumber + "\nPrice: $" + this.getPrice();
    }
}
