public class studentAdvanceTicket extends advanceticket {

    public studentAdvanceTicket(int daysInAdvance) {
        super(daysInAdvance);
    }

    public double getPrice() {
        return super.getPrice() / 2.0;
    }

    public String toString() {
        return super.toString() + "\nThis is a student ticket.";
    }
}
