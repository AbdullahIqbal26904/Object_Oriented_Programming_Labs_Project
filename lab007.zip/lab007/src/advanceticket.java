public class advanceticket extends ticket {
    private double price;
    private int daysInAdvance;

    public advanceticket(int daysInAdvance) {
        super();
        this.daysInAdvance = daysInAdvance;

        if (daysInAdvance >= 10) {
            this.price = 30.0;
        } else {
            this.price = 40.0;
        }
    }

    public double getPrice() {
        return this.price;
    }

    public String toString() {
        return super.toString() + "\nNumber of Days in Advance: " + this.daysInAdvance;
    }
}