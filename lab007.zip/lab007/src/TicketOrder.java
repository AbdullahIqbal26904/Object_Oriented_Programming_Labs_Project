public class TicketOrder {
    public static void main(String[] args) {
        ticket[] tickets = new ticket[3];
        tickets[0] = new walkupTicket();
        tickets[1] = new advanceticket(15);
        tickets[2] = new studentAdvanceTicket(5);

        for (int i = 0; i < tickets.length; i++) {
            System.out.println(tickets[i]);
        }
    }
}