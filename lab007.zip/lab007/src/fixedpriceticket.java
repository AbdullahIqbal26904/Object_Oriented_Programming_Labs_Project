public abstract class fixedpriceticket extends ticket {
    private double price;

    public fixedpriceticket(double price) {
        super();
        this.price = price;
    }

    public double getPrice() {
        return this.price;
    }
}
