package Question3;

public class Car implements Vehicle{
    @Override
    public void Start() {
        System.out.println("Car engine started.");
    }

    @Override
    public void Stop() {
        System.out.println("Car stopped");
    }
}
