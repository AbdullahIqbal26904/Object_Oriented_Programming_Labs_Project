package Question3;

public class VehicleFactory {
//    public VehicleFactory(String a){
//        getVehicle(a);
//    }
    public static Vehicle getVehicle(String type){
        if(type.equalsIgnoreCase("Car")){
            return new Car();
        }else {
            return new Motorcycle();
        }
    }
}
