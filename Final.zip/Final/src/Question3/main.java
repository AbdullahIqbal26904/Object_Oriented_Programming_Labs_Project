package Question3;

public class main {
    public static void main(String[] args) {
        //VehicleFactory car =new VehicleFactory("Car");
        Vehicle a = VehicleFactory.getVehicle("Car");
        Vehicle b = VehicleFactory.getVehicle("Motorcycle");

        a.Start();
        b.Start();
        a.Stop();
        b.Stop();
    }
}
