package Question3;

public class Motorcycle implements Vehicle{
    @Override
    public void Start() {
        System.out.println("Motorcycle engine started");
    }

    @Override
    public void Stop() {
        System.out.println("Motorcycle stopped.");
    }
}
