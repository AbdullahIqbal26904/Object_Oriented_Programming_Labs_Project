package Question3;

public interface Vehicle {
    void Start();
    void Stop();
}
