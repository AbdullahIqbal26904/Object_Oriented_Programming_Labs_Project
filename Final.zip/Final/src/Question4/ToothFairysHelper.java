package Question4;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class ToothFairysHelper {

    static int Necklace;
    static int Candy;
    static int Watch;

    static ArrayList<String > details = new ArrayList<>();

    public ToothFairysHelper() throws IOException {
        File myobj = new File("ToothFairyShoppingList.txt");
        if(myobj.createNewFile()){
            System.out.println("File created: "+myobj.getName());
        }else {
            System.out.println("File already exists");
        }
    }

    public void readFile() throws FileNotFoundException {
        File f = new File("ToothFairyList.txt");
        Scanner sc = new Scanner(f);
        while (sc.hasNext()) {
            String a = sc.next();
            details.add(a);
        }
    }
    public void writeFile() throws IOException {
        FileWriter fw = new FileWriter("ToothFairyShoppingList.txt");
        String[] arr;
        for(String d:details){
            arr=d.split(" ");
            if(arr[0].equalsIgnoreCase("F")&&arr[3].equalsIgnoreCase("Good")){
                fw.append(arr[1]+","+arr[2]+", Necklace\n");
                Necklace++;
            }else if(arr[3].equalsIgnoreCase("Bad")){
                fw.append(arr[1]+","+arr[2]+", Candy\n");
                Candy++;
            }else if(arr[0].equalsIgnoreCase("M")&&arr[3].equalsIgnoreCase("Good")){
                fw.append(arr[1]+","+arr[2]+", Watch\n");
                Watch++;
            }
        }
        fw.append("Necklace: "+Necklace+"\n");
        fw.append("Watch: "+Watch+"\n");
        fw.append("Candies: "+Candy+"\n");
        fw.close();
    }
}
