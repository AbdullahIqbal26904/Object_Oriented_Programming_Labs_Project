package Question1;

import java.util.Scanner;

public class main {
    public static int validateInput(int a) throws InvalidInputException {
        if(a<=0){
            throw new InvalidInputException("Invalid Number Entered.");
        }else {
            return a;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter number: ");
        int a =Integer.parseInt(sc.next());
        try {
            System.out.print(validateInput(a));
        } catch (InvalidInputException e) {
            System.out.print(e.getMessage());
        }
    }
}
