package Question5;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Hospital {
    Patient patient;
    private static int count =0;
    ArrayList<Patient> p;
    public Hospital() throws IOException {
        p=new ArrayList<>();
        File f = new File("Hospital.txt");
        if(f.createNewFile()){
            System.out.println("File created: "+f.getName());
        }else {
            System.out.println("File already exists.");
        }
    }
    public void addPatient(Patient patient) throws IOException {
        p.add(new Patient(patient));
        writeFile(p);
    }
    public void writeFile(ArrayList<Patient> p1) throws IOException {
        FileWriter f = new FileWriter("Hospital.txt");
        for(Patient x:p1){
            f.append(x.Name+"\n"+x.age+"\n"+x.disease+"\n"+x.dateOfAdmission+"\n"+x.getDateOfDischarge+"\n");
        }
        f.close();
    }
    public void displayDetails() throws FileNotFoundException {
        File f = new File("Hospital.txt");
        Scanner sc = new Scanner(f);
        while (sc.hasNext()){
            System.out.println("patient "+ ++count);
                System.out.println("Name: "+sc.next());
                System.out.println("Age: "+sc.next());
                System.out.println("disease: "+sc.next());
                System.out.println("date of admission: "+sc.next());
                System.out.println("date of discharge: "+sc.next());
        }
    }
    public void searchPatientByName(String name) throws FileNotFoundException {
        File f = new File("Hospital.txt");
        Scanner sc = new Scanner(f);
        while (sc.hasNext()){
            if(sc.next().equalsIgnoreCase(name)){
                System.out.println("Age: "+sc.next());
                System.out.println("disease: "+sc.next());
                System.out.println("date of admission: "+sc.next());
                System.out.println("date of discharge: "+sc.next());
                break;
            }

        }
    }
    public void searchPatientByAdmissionDate(Date date) throws FileNotFoundException {
        File f = new File("Hospital.txt");
        String[] a = new String[3];
        Scanner sc = new Scanner(f);
        while (sc.hasNext()){
            a[0]=sc.next();
            a[1]=sc.next();
            a[2]=sc.next();
            if(sc.next().equalsIgnoreCase(date.toString())){
                System.out.println("Name: "+a[0]);
                System.out.println("age: "+a[1]);
                System.out.println("disease: "+a[2]);
                System.out.println("date of discharge: "+sc.next());
                break;
            }

        }
    }
    public void calculateAveragelen() throws FileNotFoundException {
        File f = new File("Hospital.txt");
        Scanner sc = new Scanner(f);
        while (sc.hasNext()){
            sc.next();
            sc.next();
            sc.next();
            String a=sc.next();
            String b = sc.next();
            int yearsDuration=-Integer.parseInt(a.substring(0,1))+Integer.parseInt(b.substring(0,2));
            int monthDuration=-Integer.parseInt(a.substring(3,4))+Integer.parseInt(b.substring(3,4));
            int daysDuration=-Integer.parseInt(a.substring(6,7))+Integer.parseInt(b.substring(6,8));
            System.out.println("duration is :"+yearsDuration+" years "+monthDuration+" months "+daysDuration+" days");
        }
    }


}
