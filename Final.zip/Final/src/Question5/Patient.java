package Question5;


public class Patient {
    String Name;
    int age;
    String disease;
    Date dateOfAdmission;
    Date getDateOfDischarge;

    @Override
    public String toString() {
        return "Patient{" +
                "Name='" + Name + '\'' +
                ", age=" + age +
                ", disease='" + disease + '\'' +
                ", dateOfAdmission=" + dateOfAdmission +
                ", getDateOfDischarge=" + getDateOfDischarge +
                '}';
    }

    public Patient(String name, int age, String disease, Date dateOfAdmission, Date getDateOfDischarge) {
        Name = name;
        this.age = age;
        this.disease = disease;
        this.dateOfAdmission = dateOfAdmission;
        this.getDateOfDischarge = getDateOfDischarge;
    }
    public Patient(Patient patient){
        Name = patient.Name;
        this.age = patient.age;
        this.disease = patient.disease;
        this.dateOfAdmission = patient.dateOfAdmission;
        this.getDateOfDischarge = patient.getDateOfDischarge;
    }
}
