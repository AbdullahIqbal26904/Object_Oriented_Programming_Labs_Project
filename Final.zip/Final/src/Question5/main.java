package Question5;

import java.io.IOException;

public class main {
    public static void main(String[] args) throws IOException {
        Patient p1 = new Patient("abc",12,"bvc",new Date(23,12,02),new Date(23,11,30));
        Patient p2 = new Patient("xyz",23,"efg",new Date(23,12,02),new Date(23,11,30));
        Patient p3 = new Patient("xefg",32,"ehij",new Date(24,11,03),new Date(24,11,04));
        Hospital h = new Hospital();
        h.addPatient(p1);
        h.addPatient(p2);
        h.addPatient(p3);
        //h.displayDetails();
        h.searchPatientByName("abc");
        h.searchPatientByAdmissionDate(new Date(23,12,2));
        h.calculateAveragelen();
    }
}
