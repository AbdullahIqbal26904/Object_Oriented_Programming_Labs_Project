package Question2;

public class Sphere extends Shape{
    private float radius;
    public Sphere(int radius){
        this.radius=radius;
    }
    @Override
    public float getVolume() {
        return (float)  ((4/3)*Math.PI*radius*radius*radius);
    }

    @Override
    public String getShapeType() {
        return "Sphere";
    }

    @Override
    public String toString() {
        return
                "Shape Type=" + getShapeType() +
                        ",Volume= " + getVolume() +
                        ", Surface Area=" + getSurfaceArea();
    }

    public float getRadius() {
        return radius;
    }

    @Override
    public float getSurfaceArea() {
        return (float)(4*Math.PI*radius*radius) ;
    }
}
