package Question2;

public class main {
    public static void main(String[] args) {
        Shape sphere = new Sphere(4);
        Shape Cuboid = new Cuboid(10,5,12);
        Shape Cylinder = new Cylinder(2,12);
        Shape cube = new Cube(12,5,23);

        System.out.println(sphere);
        System.out.println(Cuboid);
        System.out.println(Cylinder);
        System.out.println(cube);
    }
}
