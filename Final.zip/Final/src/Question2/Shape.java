package Question2;

public abstract class Shape {
   public abstract float getVolume();
   public abstract String getShapeType();
   public abstract float getSurfaceArea();

}
