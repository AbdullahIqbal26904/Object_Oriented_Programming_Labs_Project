package Question2;

public class Cube extends Cuboid{
    public Cube(float length, float width, float height) {
        super(length, width, height);
    }
    public String getShapeType(){
        return "Cube";
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
