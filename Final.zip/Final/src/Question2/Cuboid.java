package Question2;

public class Cuboid extends Shape{
    private float length;
    private float width;
    private float height;

    public float getLength() {
        return length;
    }

    @Override
    public String toString() {
        return
                "Shape Type=" + getShapeType() +
                        ",Volume= " + getVolume() +
                ", Surface Area=" + getSurfaceArea();
    }

    public float getWidth() {
        return width;
    }

    public float getHeight() {
        return height;
    }

    public Cuboid(float length, float width, float height) {
        this.length = length;
        this.width = width;
        this.height = height;
    }

    @Override
    public float getVolume() {
        return length*width*height;
    }

    @Override
    public String getShapeType() {
        return "Cuboid";
    }

    @Override
    public float getSurfaceArea() {
        return 2*((length*width)+(width*height)+(height*length));
    }
}
