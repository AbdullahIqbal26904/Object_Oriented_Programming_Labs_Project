package Question2;

public class Cylinder extends Shape{
    private float radius;
    private float height;
    public Cylinder(float radius,float height){
        this.radius=radius;
        this.height=height;
    }
    @Override
    public float getVolume() {
        return (float) (height*Math.PI*radius*radius);
    }

    @Override
    public String getShapeType() {
        return "Cylinder";
    }

    @Override
    public String toString() {
        return
                "Shape Type=" + getShapeType() +
                        ",Volume= " + getVolume() +
                        ", Surface Area=" + getSurfaceArea();
    }

    public float getRadius() {
        return radius;
    }

    public float getHeight() {
        return height;
    }

    @Override
    public float getSurfaceArea() {
        return (float) (2*Math.PI*radius*(radius+height));
    }
}
