package Problem1;

public class lawyer extends employee {


    public lawyer() {
        super();

    }
    public int getHours(){
        return hours;
    }
    public double getSalary(){
        return salary;
    }
    public int getVacationDays(){
        return vacationDays+5;
    }
    public String getVacationForm(){
        return "pink";
    }
    public void print(){
        System.out.println("I will see you in court.");
    }
}
