package Problem1;

public class marketer extends employee {

    public marketer() {
        super();
    }
    public int getHours(){
        return hours;
    }
    public double getSalary(){
        return salary+=10000;
    }
    public int getVacationDays(){
        return vacationDays;
    }
    public String getVacationForm(){
        return vacationForm;
    }

    public void advertise(){
        System.out.println("Act now, while supplies last!");
    }
}
