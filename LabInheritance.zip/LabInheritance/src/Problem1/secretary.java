package Problem1;

public class secretary extends employee {
    public secretary() {
        super();
    }
    public int getHours(){
        return hours;
    }
    public double getSalary(){
        return salary;
    }
    public int getVacationDays(){
        return vacationDays;
    }
    public String getVacationForm(){
        return vacationForm;
    }
    public void TakeDictation(String takeDictation){
        System.out.println(takeDictation);
    }
}
