package Problem1;

public class Main {
    public static void main(String[] args) {
        lawyer l1 = new lawyer();
        System.out.println("lawyer \n"+l1.getSalary()+" "+l1.getHours()+" "+l1.getVacationDays()+" "+l1.getVacationForm());
        l1.print();
        secretary s = new secretary();
        System.out.println("secretary \n"+s.getSalary()+" "+s.getHours()+" "+s.getVacationDays()+" "+s.getVacationForm());
        s.TakeDictation("okieeee!!");
        legalSecretary s2 = new legalSecretary();
        System.out.println("legal secretary \n"+s2.getSalary()+" "+s2.getHours()+" "+s2.getVacationDays()+" "+s2.getVacationForm());
        s2.fileLegalBriefs();
        marketer m = new marketer();
        System.out.println("marketer \n"+m.getSalary()+" "+m.getHours()+" "+m.getVacationDays()+" "+m.getVacationForm());
        m.advertise();
        Janitor j = new Janitor();
        System.out.println("janitor \n"+j.getSalary()+" "+j.getHours()+" "+j.getVacationDays()+" "+j.getVacationForm());
        j.clean();


    }
}
