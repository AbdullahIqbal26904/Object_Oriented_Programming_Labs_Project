package Problem1;

public class legalSecretary extends secretary {


    public legalSecretary() {
        super();
    }
    public int getHours(){
        return hours;
    }
    public double getSalary(){
        return salary+=5000;
    }
    public int getVacationDays(){
        return vacationDays;
    }
    public String getVacationForm(){
        return vacationForm;
    }
    public void fileLegalBriefs(){
        System.out.println("I could file all days!");
    }
}
