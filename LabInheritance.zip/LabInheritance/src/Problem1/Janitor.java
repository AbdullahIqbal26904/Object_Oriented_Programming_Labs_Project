package Problem1;

public class Janitor extends employee{
    public Janitor() {
        super();
    }
    public int getHours(){
        return hours*=2;
    }
    public double getSalary(){
        return salary-=10000;
    }
    public int getVacationDays(){
        return vacationDays;
    }
    public String getVacationForm(){
        return vacationForm;
    }

    public void clean(){
        System.out.println("Working for the man.");
    }

}
