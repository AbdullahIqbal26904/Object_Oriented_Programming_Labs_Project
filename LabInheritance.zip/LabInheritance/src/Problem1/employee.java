package Problem1;

import javax.sql.rowset.serial.SerialStruct;

public class employee {
    int hours;
    double salary;
    int vacationDays;
    String vacationForm;
    
    public employee(){
        this.hours = 40;
        this.salary = 40000;
        this.vacationDays = 10;
        this.vacationForm = "yellow";
    }
    public int getHours(){
        return hours;
    }
    public double getSalary(){
        return salary;
    }
    public int getVacationDays(){
        return vacationDays;
    }
    public String getVacationForm(){
        return vacationForm;
    }
}
