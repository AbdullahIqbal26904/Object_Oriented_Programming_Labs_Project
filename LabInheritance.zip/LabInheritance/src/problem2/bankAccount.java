package problem2;

public class bankAccount {
    private double balance;
    private String owner;
    private static String accountNumber;
    protected static int nof=100001;

    public bankAccount(){
        this.balance=0;
        accountNumber=String.valueOf(nof)+"";
        nof++;
    }
    public bankAccount(String owner, double balance){
        this.balance=balance;
        this.owner=owner;
        this.accountNumber=String.valueOf(nof);
        nof++;
    }
    public bankAccount(bankAccount oldAccount,double balance){
        this.balance = oldAccount.balance;
        this.owner= oldAccount.owner;
        this.balance=balance;
    }
    public void deposit(double amount){
        balance+=amount;
    }
    public boolean withdraw(double amount){
        if(balance>amount){
            balance-=amount;
            return true;
        }
        return false;
    }
    public double getBalance(){
        return this.balance;
    }
    public String getOwner(){
        return this.owner;
    }
    public String getAccountNumber(){
        return this.accountNumber;
    }
    public void setBalance(double amount){
        balance+=amount;
    }
    public void setAccountNumber(String newAccountNumber){
        this.accountNumber=newAccountNumber;
    }

}
