package problem2;

public class checker {
    public static void main(String[] args) {
        checkingAccount c = new checkingAccount("Abdullah",600000);
        System.out.println(c.getBalance());
        System.out.println(c.getAccountNumber());
        System.out.println(c.getOwner());
        checkingAccount c2 = new checkingAccount("alpha",100000);
        System.out.println(c2.getBalance());
        System.out.println(c2.getAccountNumber());
        System.out.println(c2.getOwner());
        checkingAccount c3 = new checkingAccount("beta",78000);
        System.out.println(c3.getBalance());
        System.out.println(c3.getAccountNumber());
        System.out.println(c3.getOwner());
        System.out.println(c3.withdraw(10000));
        System.out.println(c3.getBalance());

        savingsAccount s1 = new savingsAccount("Nafay",100000);
        System.out.println(s1.getBalance());
        System.out.println(s1.getAccountNumber());
        System.out.println(s1.getOwner());
        s1.postInterest();
        System.out.println(s1.getBalance());

        savingsAccount s2 = new savingsAccount("Ashal",250000);
        System.out.println(s2.getBalance());
        System.out.println(s2.getAccountNumber());
        System.out.println(s2.getOwner());
        s2.postInterest();
        System.out.println(s2.getBalance());
        savingsAccount s3 = new savingsAccount("Ashal",250000);
        System.out.println(s3.getBalance());
        System.out.println(s3.getAccountNumber());
        System.out.println(s3.getOwner());
        s3.postInterest();
        System.out.println(s3.getBalance());
    }
}
