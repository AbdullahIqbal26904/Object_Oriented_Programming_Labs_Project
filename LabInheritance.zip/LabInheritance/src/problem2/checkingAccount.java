package problem2;

public class checkingAccount extends bankAccount{
    private double fee=15;
    public checkingAccount(String name, double amount){
        super(name,amount);
        setAccountNumber(getAccountNumber()+"-10");
    }
    public boolean withdraw(double amount){
        if(amount>fee){

           super.withdraw(amount);
            return true;
        }
        return false;
    }

}
