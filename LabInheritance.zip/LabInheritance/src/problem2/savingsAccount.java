package problem2;

public class savingsAccount extends bankAccount {
    private double rate=2.5;
    private static int  savingsNumber=0;
    private String accountNumber;


    public savingsAccount(String name,double amount){
        super(name,amount);
        setAccountNumber(getAccountNumber()+"-"+savingsNumber);
        savingsNumber++;
    }
    public void postInterest(){
       deposit((getBalance()*rate)/(100*12));
    }
}
