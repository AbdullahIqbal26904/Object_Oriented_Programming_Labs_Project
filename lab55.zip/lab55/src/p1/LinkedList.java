package p1;

public class LinkedList {
    Node head;
    public void append(int data) {
        if (head == null) {
            head = new Node(data);
            return;
        }
        Node current = head;
        while (current.next != null) {
            current = current.next;
        }
        current.next = new Node(data);
    }

    public void remove(int data) {
        if (head == null) {

        }
        if (head.data == data) {
            head = head.next;
            System.out.println("data removed");
            return;
        }
        Node current = head;
        while (current.next != null) {
            if (current.next.data == data) {
                current.next = current.next.next;
                return;
            }
            current = current.next;
        }
    }

    public void append(int data, int index){
        int count=0;
        if ( index==0) {
            Node b = new Node(data);
            b.next=head;
            head = b;
            return ;
        }
        Node current = head ;
        while ( current.next != null ) {
            if(count==index-1) {
                Node a = current.next;
                current.next=new Node(data);
                current.next.next=a;
            }
            current = current.next;
            count++;
        }
    }

    public void delete(int index){
        Node current = head;
        Node previous = null;
        if (index == 0) {
            head = head.next;
            return;
        }
        int count;
        for (count = 0;count < index; count++) {
            if (current == null) return;
            previous = current;
            current = current.next.next;
        }

        previous.next = current;

    }

    public static void printList(LinkedList list)
    {
        Node currNode = list.head;

        System.out.print("LinkedList: ");

        while (currNode != null) {
            System.out.print(currNode.data + " ");
            currNode = currNode.next;
        }
    }
    public void removesOccurance(int data){
        Node current=head;
        while (current!=null){
            if(current.data==data){
                remove(data);
            }
            current=current.next;
        }
    }
    public void reverseLinkedList() {
        Node current = head;
        Node prev = null, next = null;
        while (current != null) {
            next = current.next;
            current.next = prev;
            prev = current;
            current = next;
        }
        head = prev;
    }
    public LinkedList removeDuplicates(){
        Node currentNode = head;
        Node nextNode;
        while (currentNode!=null){
            nextNode=currentNode.next;
            while (nextNode.next!=null){
                if(nextNode.next.data==currentNode.data){
                    nextNode.next=nextNode.next.next;
                }
                else{
                    nextNode=nextNode.next;
                }
                currentNode=currentNode.next;
            }
        }
        return this;
    }


}
