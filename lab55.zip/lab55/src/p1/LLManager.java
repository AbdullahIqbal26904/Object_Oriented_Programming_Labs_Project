package p1;

public class LLManager {
    public static void main(String[] args)
    {
        LinkedList l = new LinkedList ();
        l.append (1);
        l.append (2);
        l.append(3);
        l.append (3);
        l.append(32);
        l.append (41);
        l.append(56);
        l.append(67,0);
        l.append(890,4);
        l.append(900);
        //LinkedList.printList(l);
        l.delete(0);
        l.delete(1);
        LinkedList.printList(l);
        //l.removesOccurance(3);
        //LinkedList.printList(l);

        l.reverseLinkedList();
        LinkedList.printList(l);

        l.append(3002);
        l.append(3002);
        LinkedList.printList(l);
        l.removeDuplicates();
        LinkedList.printList(l);


    }
}
