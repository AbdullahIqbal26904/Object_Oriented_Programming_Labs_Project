package p1;

public class Stack {
    Node head;
    public void push(int data) {
        Node a = new Node(data);
        if (head == null) {
            head = a;
            return;
        }else {
            a.next = head;
        }
        head = a;

    }
    public  int pop(){
        if(head==null){
            return 0;
        }
        int a = head.data;
        if(head.next!=null){
            head=head.next;
        }
        return a;
    }
}
