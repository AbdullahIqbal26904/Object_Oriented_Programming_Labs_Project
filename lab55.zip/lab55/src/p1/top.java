package p1;

public class top {
    int data;
    top next;
    public top (int data ) {
        this . data = data ;
        this . next = null ;
    }
}
