package p1;

public class stackmanager {
    public static void main(String[] args) {
        Stack s = new Stack();
        s.push(12);
        s.push(13);
        s.push(34);

        System.out.println(s.pop()   );
        System.out.println(s.pop()   );
        System.out.println(s.pop()   );

    }
}
