package problem3;

import java.io.FileNotFoundException;

public class checker {
    public static void main(String[] args) throws FileNotFoundException {
        String[] fName = {"Abdullah","Shiraz","ali","ahmed","Nafay","araiz","affan","shahzaib","sheikh","haseeb"};
        String[] sName = {"ammar","iqbal","afaf","ashal","naushad","nasir","mehmood","masood","ashraf","maniya"};
        String[] Student = new String[20];
        String bstd = null;
        for(int i=0;i<20;i++){
            Student s = new Student(randomName(fName),randomName(sName));
            Student[i]= s.getDetails();
            bstd=s.getBestStd();
            System.out.println(Student[i]);
            System.out.println();
        }
        if(bstd == null){
            System.out.println("No best student, everyone has failed at least one course.");
        }else {
            System.out.println("best student is: " + bstd);
        }

    }
    public static String randomName(String[] a){
        String name =a[(int)(Math.random()*10)];
        return name;
    }

}
