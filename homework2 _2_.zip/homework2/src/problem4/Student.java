package problem4;

import javax.sound.midi.Soundbank;
import java.io.*;
import java.util.Scanner;
import java.util.Objects;

public class Student {
    String fname, sname;
    String[] courses = new String[10];
    private static String bestStd;
    static int max1;
    int x=0;

    public Student(String fname, String sname,String[] a) {
        x=0;
        this.fname = fname;
        this.sname = sname;
        this.courses[0] = "Maths : ";
        this.courses[2] = "computer : ";
        this.courses[4] = "discrete maths : ";
        this.courses[6] = "history : ";
        this.courses[8] = "English : ";
        int failSubCount = 0;
        for (int i = 1; i < courses.length; i += 2) {
            this.courses[i] = a[x];
            x++;
        }
        String check = bestStd(courses);
        if (!Objects.equals(check, "")) {
            bestStd = check;
        }
    }

    public String getBestStd() {
        return bestStd;
    }

    public String getName() {
        return fname;
    }

    public String getsName() {
        return sname;
    }

    public int random() {
        return (int) (Math.random() * 101);
    }

    private static String calculateGrade(String a) {
        if (Integer.parseInt(a) >= 90) {
            return "A";
        }
        if (Integer.parseInt(a) >= 80) {
            return "B";
        }
        if (Integer.parseInt(a) >= 70) {
            return "C";
        }
        if (Integer.parseInt(a) >= 60) {
            return "D";
        }
        return "fail";
    }

    public String getDetails() {
        return   fname + "\n" + sname + "\n" + courses[0] + courses[1] + " " + calculateGrade(courses[1]) + "\n" + courses[2] + courses[3] + " " + calculateGrade(courses[3]) + "\n" + courses[4] + courses[5] + " " + calculateGrade(courses[5]) + "\n" + courses[6] + courses[7] + " " + calculateGrade(courses[7]) + "\n" + courses[8] + courses[9] + " " + calculateGrade(courses[9]);
    }

    public String bestStd(String[] a) {
        int failSubCount = 0;
        int total = 0;
        String f = "";
        for (int i = 1; i <= a.length; i += 2) {
            total += Integer.parseInt(a[i]);
            if (Integer.parseInt(a[i]) >= 60) {
                failSubCount++;
            }
        }
        if (total > max1 && failSubCount == 5) {
            String s="";
            max1 = total;
            for (int i=0;i<this.courses.length;i+=2){
                s+=this.courses[i]+"  "+this.courses[i+1]+" "+calculateGrade(this.courses[i+1])+"\n";
                x++;
            }

            f = getName() + " " + getsName() + " with total marks: " + total + " and passed " + failSubCount + " courses."+"\n"+s;
        }
        return f;
    }
/*

    public static String Readfromfile() throws FileNotFoundException {
        String last = "";
        File f1 = new File("C:\\Users\\hp\\IdeaProjects\\homework2\\Students.txt");
        String currentName = "";
        String Name = "";
        int currentTotal = 0;
        int maxTotal = 0;
        String[] Arr = new String[5];
        String newArr[] = new String[5];
        Scanner sc = new Scanner(f1);
        while (sc.hasNextLine()) {
            String s = sc.nextLine();
            if (!s.contains("first name")) {
                for (int i = 0; i <= 5; i++) {
                    s = sc.nextLine();
                }
            } else {
                currentTotal = 0;
                currentName = s + " " + sc.nextLine();
                for (int i = 0; i < 5; i++) {
                    String intConvert = sc.nextLine();
                    intConvert = intConvert .replaceAll("[A-Za-z]", "");
                    intConvert = intConvert.replaceAll(" ", "");
                    intConvert = intConvert.replaceAll(":", "");
                    currentTotal += Integer.parseInt(intConvert);
                    Arr[i] = intConvert;
                }
                if (currentTotal > maxTotal) {
                    maxTotal=currentTotal;
                    Name = currentName;
                    for (int i = 0; i < 5; i++) {
                        newArr[i] = Arr[i];
                    }
                }
            }
        }
        if (!Name.equals("")) {
            last = "best student from file is: "+Name+ " With total marks : "+maxTotal ;
            for (int i = 0; i < 5; i++) {
                if(!calculateGrade(newArr[i]).equals("fail")) {
                    last += "\n" + newArr[i] + " " + calculateGrade(newArr[i]);
                }
            }
        }else {
            last="no best student in file.";
        }
        return last;
    }*/
}
