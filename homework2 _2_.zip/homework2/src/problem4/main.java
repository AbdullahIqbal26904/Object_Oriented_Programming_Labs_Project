package problem4;


import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class main {
    public static void main(String[] args) throws FileNotFoundException {
        String[] Student = new String[20];
        String[] intArr = new String[5];
        String s1="",s2="",s0="";
        String bstd = null;
        File f1 = new File("C:\\Users\\hp\\IdeaProjects\\homework2\\Students.txt");
        Scanner sc = new Scanner(f1);
        for(int i=0;i<20;i++) {
             s0 = sc.nextLine();
            if (s0.substring(0, 5).equals("first")) {
                 s1 = s0;
                 s2 = sc.nextLine();
                for (int x = 0; x < 5; x++) {
                    String m = sc.nextLine();
                    m = m.replaceAll(" ", "");
                    m = m.replaceAll("[A-Za-z]", "");
                    m = m.replaceAll(":", "");
                    intArr[x] = m;
                }
            }
            Student s = new Student(s1,s2,intArr);
            Student[i]= s.getDetails();
            bstd=s.getBestStd();
            System.out.println(Student[i]);

        }
        if(bstd == null){
            System.out.println("No best student, everyone has failed at least one course.");
        }else {
            System.out.println("best student read from file is " + bstd);
        }
    }
}
