package Task2;

import java.io.FileNotFoundException;
import java.util.ArrayList;

public class cityFactory {
    ArrayList<city> Punjab = new ArrayList<>();
    ArrayList<city> Balochistan = new ArrayList<>();
    ArrayList<city> AzadKashmir = new ArrayList<>();
    ArrayList<city> KhyberPakhtunKhwa = new ArrayList<>();
    ArrayList<city> Sindh = new ArrayList<>();
    ArrayList<city> gigitBaltistan = new ArrayList<>();
    ArrayList<city> cities = new ArrayList<>();
    public void addInProvince(ArrayList<city> e) throws FileNotFoundException {
            for (city c:e){
            String name = c.getAdmin_name();
            switch (name){
                case "Punjab":
                    Punjab.add(c);
                    break;
                case "Sindh":
                    Sindh.add(c);
                    break;
                case "Khyber Pakhtunkhwa":
                    KhyberPakhtunKhwa.add(c);
                    break;
                case "Azad Kashmir":
                    AzadKashmir.add(c);
                    break;
                case "Balochistān":
                    Balochistan.add(c);
                    break;
                case "Gilgit-Baltistan":
                    gigitBaltistan.add(c);
                    break;
            }
        }
        //System.out.println(Punjab);
        //System.out.println(Sindh);
        //System.out.println(gigitBaltistan);
        //System.out.println(KhyberPakhtunKhwa);
    }
    public city removeCity(String adminName){
        switch (adminName){
            case "Sindh":
                if(!Sindh.isEmpty())
                    return Sindh.remove((int) (Math.random() * Sindh.size()));
                break;
            case "Punjab":
                if(!Punjab.isEmpty())
                    return Punjab.remove((int) (Math.random() * Punjab.size()));
            case "Balochistan":
                if(!Balochistan.isEmpty())
                    return Balochistan.remove((int) (Math.random() * Balochistan.size()));
            case "Gilgit-Baltistan":
                if(!Sindh.isEmpty())
                    return gigitBaltistan.remove((int) (Math.random() * gigitBaltistan.size()));
            case "Azad Kashmir":
                if(!AzadKashmir.isEmpty())
                    return AzadKashmir.remove((int) (Math.random() * AzadKashmir.size()));
            case "Khyber Pakhtunkhwa":
                if(!KhyberPakhtunKhwa.isEmpty())
                    return KhyberPakhtunKhwa.remove((int) (Math.random() * KhyberPakhtunKhwa.size()));
        }
        return null;
    }
}
