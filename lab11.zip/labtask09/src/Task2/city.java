package Task2;

import java.awt.*;

public class city {
    private String name;
    private double lat;
    private double lng;
    private String Country;
    private String iso2;
    private String Admin_name;
    private boolean pressed;

    public String getAdmin_name() {
        return Admin_name;
    }

    @Override
    public String toString() {
        return "city{" +
                "name='" + name + '\'' +
                ", lat=" + lat +
                ", lng=" + lng +
                ", Country='" + Country + '\'' +
                ", iso2='" + iso2 + '\'' +
                ", Admin_name='" + Admin_name + '\'' +
                '}';
    }

    public city(String name, double lat, double lng, String country, String iso2, String admin_name) {
        this.name = name;
        this.lat = lat;
        this.lng = lng;
        Country = country;
        this.iso2 = iso2;
        Admin_name = admin_name;
        pressed=false;
    }
    public void draw(Graphics g){

    }

}
