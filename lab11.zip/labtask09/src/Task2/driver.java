package Task2;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class driver {
    public static void main(String[] args) throws FileNotFoundException {
        File f = new File("C:\\Users\\hp\\IdeaProjects\\labtask09\\data.csv");
        Scanner sc = new Scanner(f);
        sc.nextLine();
        ArrayList<city> cities = new ArrayList<>();
        while (sc.hasNextLine()) {
            String[] data = sc.nextLine().split(",");
            //System.out.println(Arrays.toString(data));
            double lat = Double.parseDouble(data[1]);
            double lng = Double.parseDouble(data[2]);
            city c = new city(data[0], lat, lng, data[3], data[4], data[5]);
            //System.out.println(c);
            cities.add(c);
    }
        cityFactory c = new cityFactory();
        c.addInProvince(cities);
        System.out.println(c.removeCity("Punjab"));
        System.out.println(c.removeCity("Sindh"));
        System.out.println(c.removeCity("Azad Kashmir"));
        System.out.println(c.removeCity("Balochistan"));

    }}

