package Task1;

public class MuteQuack implements quackBehavior{
    public void quack() {
        System.out.println("<< Silence >>");
    }

}
