package Task1;

public class driver {
    public static void main(String[] args) {
        Duck mallard = new MallardDuck();
        mallard.display();
        mallard.performQuack();
        mallard.performFly();

        Duck Redhead = new RedHeadDuck();
        Redhead.display();
        Redhead.performFly();
        Redhead.performQuack();

        Duck Rubber = new RubberDuck();
        Rubber.display();

        Duck decoy = new DecoyDuck();
        decoy.display();


    }
}
