package Task1;

public class RedHeadDuck extends Duck{

    public RedHeadDuck() {

        this.QuackBehavior = new Quack();

        this.flyBehavior = new FlyNoWay();
    }

    @Override
    public void display() {
        System.out.println("I'm a redhead duck!");
    }
}
