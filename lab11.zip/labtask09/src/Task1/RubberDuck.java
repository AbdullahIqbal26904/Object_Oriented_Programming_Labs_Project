package Task1;

public class RubberDuck extends Duck {
    public RubberDuck(){
        this.QuackBehavior=new Quack();
    }

    @Override
    public void display() {
        System.out.println("I am Rubber duck! ");
    }

}
