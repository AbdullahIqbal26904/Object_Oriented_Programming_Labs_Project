package Task1;

public class DecoyDuck extends Duck{
    @Override
    public void display() {
        System.out.println("i am decoyDuck");
    }
}
