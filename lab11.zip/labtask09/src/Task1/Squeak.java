package Task1;

public class Squeak implements quackBehavior{
    @Override
    public void quack() {
        System.out.println("Squeak");
    }

}
