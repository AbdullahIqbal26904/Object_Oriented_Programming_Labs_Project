package Task1;

public interface quackBehavior {
        public void quack();
}
