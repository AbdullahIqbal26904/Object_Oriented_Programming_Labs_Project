package Task1;

public interface FlyBehavior {
     void fly();
}
