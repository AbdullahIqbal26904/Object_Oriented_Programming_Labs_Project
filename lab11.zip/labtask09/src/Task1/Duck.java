package Task1;

public abstract class Duck {
    FlyBehavior flyBehavior;
  quackBehavior QuackBehavior;

public Duck() {

        }

public abstract void display();

public void performFly() {
        this.flyBehavior.fly();
        }

public void performQuack() {
        this.QuackBehavior.quack();
        }

    public void swim() {
        System.out.println("All ducks float, even decoys!");
        }

// Dynamically set the behaviors for an object on the fly!
    public void setFlyBehavior(FlyBehavior fb) {
        this.flyBehavior = fb;
        }

    public void setQuackBehavior(quackBehavior qb) {
        this.QuackBehavior = qb;
        }
}
