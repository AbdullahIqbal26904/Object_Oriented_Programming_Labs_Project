package Task1;

public class Quack implements quackBehavior {
    public void quack(){
        System.out.println("Quack");
    }
}
