package The_Task;

import java.awt.*;
import java.awt.Point;

public class Rectangle
{
    private java.awt.Point center ;
    private int width;
    private int height;
    private int stroke;
    private Color button_color;
    private Color stroke_color;
    String text;

    public Rectangle(The_Task.Point center, int side, int height, Color button_color, Color stroke_color, int stroke)
    {

    }

    public Rectangle(int x, int y, int width, int height, Color button_color, Color stroke_color, int stroke)
    {
        center = new Point(x, y);
        this.width = width;
        this.height = height;
        this.button_color = button_color;
        this.stroke_color = stroke_color;
        this.stroke = stroke;
    }

    public Rectangle(Point p, int width, int height, Color button_color, Color stroke_color, int stroke)
    {
        this(p.x, p.y, width, height, button_color, stroke_color, stroke);
    }

    public void paint(Graphics g)
    {
        g.setColor(stroke_color);
        g.fillRect(center.x  , center.y  , width , height );
        g.setColor(button_color);
        g.fillRect(center.x+stroke  , center.y+stroke, width-2*stroke, height-2*stroke);
    }
}
