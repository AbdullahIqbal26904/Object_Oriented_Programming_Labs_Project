package The_Task;

import java.awt.*;

public class TitleBar extends Cell {
    public TitleBar(int x, int y, int width, int height, Color cell_Color, Color stroke_Color, int stroke, String text) {
        super(x, y, width, height, cell_Color, stroke_Color, stroke, text);
    }
   public void paintTitleBar(Graphics g){
        super.paintHighlighted(g);
   }

    public void redClosingButton(Graphics g){
        Square red = new Square((width-(width/16)),topLeft.y+stroke+2,height-7,Color.red,stroke_Color,3);
        red.paint(g);
    }

}
