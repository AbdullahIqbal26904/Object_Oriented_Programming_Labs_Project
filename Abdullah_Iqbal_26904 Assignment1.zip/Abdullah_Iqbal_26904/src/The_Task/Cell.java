package The_Task;

import java.awt.*;
import java.nio.channels.FileLock;

public class Cell {
    Point topLeft;
    int width;
    int height;
    int stroke;
    Color cell_Color;
    Color stroke_Color;
    String text;
    Font font;
    int fontSize;
    int fontStyle;

    public Cell(int x,int y,int width,int height,Color cell_Color,Color stroke_Color,int stroke,String text){
        topLeft= new Point(x,y);
        this.width=width;
        this.height=height;
        this.stroke=stroke;
        this.cell_Color=cell_Color;
        this.stroke_Color=stroke_Color;
        this.text=text;
    }
    public void paint(Graphics g)
    {
        Rectangle r1 = new Rectangle(topLeft.x, topLeft.y, width,height,cell_Color,stroke_Color,stroke);
        r1.paint(g);
        g.setColor(Color.black);
        font = g.getFont().deriveFont(fontSize);
        g.setFont(font);
        FontMetrics e = g.getFontMetrics();
        g.drawString(text, topLeft.x+width/20, topLeft.y+4*(e.getHeight()-e.getAscent()));
    }
    public void paintNormal(Graphics g){
        Rectangle r1 = new Rectangle(topLeft.x, topLeft.y, width,height,cell_Color,stroke_Color,stroke);
        r1.paint(g);
        g.setColor(Color.black);
        font = g.getFont().deriveFont(fontSize);
        g.setFont(font);
        FontMetrics e = g.getFontMetrics();
        g.drawString(text, topLeft.x+width/20, topLeft.y+4*(e.getHeight()-e.getAscent()));
    }
    public void paintHighlighted(Graphics g){
        Rectangle r1 = new Rectangle(topLeft.x, topLeft.y, width,height,cell_Color,stroke_Color,stroke);
        r1.paint(g);
        g.setColor(Color.white);
        Font f = new Font(Font.SERIF,Font.BOLD, (int) (height/1.5));
        g.setFont(f);
        FontMetrics e = g.getFontMetrics();
        g.drawString(text, topLeft.x+stroke+10, topLeft.y+4*(e.getHeight()-e.getAscent()));
    }
}

