package The_Task;

import java.awt.*;

public class Table  {
    public void paint(Graphics g) {
        int x=0;
        int y=0;
        int height=(600/17);
        int stroke=2;
        int width=800-(stroke*10);
        TitleBar t = new TitleBar(x,y,width,height, Color.black,Color.gray,stroke+1,"Data Table");
        t.paintTitleBar(g);
        t.redClosingButton(g);
        y=y+height;
        for(int column=0;column<5;column++){
            Cell t2 = new Cell(x,y,width/5,height, Color.getHSBColor(51,204,255),Color.blue,stroke,"Data");
            t2.paint(g);
            x+=(int)(width/5);
        }
        y=y+height;
        for(int i=0;i<17;i++){
            x=0;
            for(int column=0;column<5;column++){
                Cell t2 = new Cell(x,y,width/5,height, Color.lightGray,Color.blue,stroke,"default");
                t2.paintNormal(g);
                x+=(int)(width/5);
            }
            y+=height;
        }
    }
}
