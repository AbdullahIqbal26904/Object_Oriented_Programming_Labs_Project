package The_Task;

import javax.swing.*;

public class DrawingManager {
    public static void main(String[] args) {
        DrawingCanvas canvas=new DrawingCanvas();
        JFrame frame=new JFrame();
        frame.add(canvas);
        frame.setSize(800,800);
        //f.setLayout(null);
        frame.setVisible(true);
    }
}
