package The_Task;

import java.awt.*;

    public class DrawingCanvas extends Canvas {
        public void paint(Graphics g){
            Table t3 = new Table();
            t3.paint(g);
        }
}
