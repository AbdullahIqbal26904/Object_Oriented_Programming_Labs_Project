package CriticalPoints;


import The_Task.DrawingCanvas;

import javax.swing.*;
import java.awt.*;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;

import static CriticalPoints.extractingFromFile.*;

public class DrawingManager2 {
    public static void main(String[] args) throws FileNotFoundException {
        extractingFromFile e = new extractingFromFile();
        if(e.isFileEmpty()){
            DrawingCanvas canvas=new DrawingCanvas();
            JFrame frame=new JFrame();
            frame.add(canvas);
            frame.setSize(800,800);
            frame.setVisible(true);
        }else {
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter cell colour out of these 5: red yellow green blue lightgray");
            String s =sc.next();
            System.out.println("Enter Title bar colour out of these 5: red black green blue lightgray");
            String s1 =sc.next();
            System.out.println("Enter text colour out of these 5: red yellow green blue white");
            String s2 =sc.next();
            System.out.println("Enter border colour out of these 5: red yellow green blue lightgray");
            String s3 =sc.next();
            System.out.println("Enter first row colour out of these 5: red yellow green blue lightgray");
            String s4 =sc.next();
            DrawingCanvas2 canvas = new DrawingCanvas2();
            canvas.setColor(setcolor(s),setcolor(s2),setcolor(s3),setcolor(s1),setcolor(s4));
            JFrame frame = new JFrame();
            frame.add(canvas);
            frame.setSize(800, 800);
            frame.setVisible(true);
        }
    }
    public static Color setcolor(String s){
        if(s.equals("red")){
            return Color.red;
        }
        if(s.equals("yellow")){
            return Color.yellow;
        }
        if(s.equals("green")){
            return Color.green;
        }
        if(s.equals("blue")){
            return Color.blue;
        }
        if(s.equals("black")){
            return Color.black;
        }
        if(s.equals("white")){
            return Color.white;
        }
            return Color.lightGray;
    }
}