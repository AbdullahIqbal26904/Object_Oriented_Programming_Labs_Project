package CriticalPoints;

import java.awt.*;
import java.io.FileNotFoundException;
import java.util.Arrays;

public class DrawingCanvas2 extends Canvas {
    Color cellColor;
    Color titlebarColor;
    Color borderColor;
    Color textColor;
    Color firstRow;
    public void setColor(Color cellColor,Color textColor,Color borderColor,Color titlebarColor,Color firstRow){
        this.cellColor=cellColor;
        this.titlebarColor=titlebarColor;
        this.borderColor=borderColor;
        this.textColor=textColor;
        this.firstRow=firstRow;
    }
    public Color getCellColor(){
        return cellColor;
    }
    public Color getTextColor(){
        return textColor;
    }
    public Color getTitlebarColor(){
        return titlebarColor;
    }
    public Color getBorderColor(){
        return borderColor;
    }
    public Color getFirstRow(){
        return firstRow;
    }
    public void paint(Graphics g){
        extractingFromFile e = new extractingFromFile();
        String a = null;
        try {
            a = e.heading();
        } catch (FileNotFoundException ex) {
            throw new RuntimeException(ex);
        }
        String[] firstRow = new String[0];
        try {
            firstRow = e.read();
        } catch (FileNotFoundException ex) {
            throw new RuntimeException(ex);
        }
        String[][] b = new String[0][];
        try {
            b = e.read2(firstRow.length);
        } catch (FileNotFoundException ex) {
            throw new RuntimeException(ex);
        }
        int numberOfLine = 0;
        try {
            numberOfLine = e.nol();
        } catch (FileNotFoundException ex) {
            throw new RuntimeException(ex);
        }
        System.out.println(a);
        System.out.println(Arrays.toString(firstRow));
        System.out.println(Arrays.deepToString(b));
        Table2 t2 = new Table2();
        t2.paint(g,b,firstRow,numberOfLine,a,getCellColor(),getBorderColor(),getTextColor(),getTitlebarColor(),getFirstRow());
    }
}
