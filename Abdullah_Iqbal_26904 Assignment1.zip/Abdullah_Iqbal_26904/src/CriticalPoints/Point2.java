package CriticalPoints;

public class Point2 {
    int x;
    int y;

    Point2()
    {
        x=y=0;
    }

    Point2(int x, int y)
    {
        this.x = x;
        this.y = y;
    }

    Point2(Point2 p)
    {
        x = p.x;
        y = p.y;
    }
}
