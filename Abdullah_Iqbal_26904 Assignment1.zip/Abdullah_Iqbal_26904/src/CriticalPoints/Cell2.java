package CriticalPoints;

import The_Task.Point;
import The_Task.Rectangle;

import java.awt.*;

public class Cell2 {
    Point2 topLeft;
    int width;
    int height;
    int stroke;
    Color cell_Color;
    Color stroke_Color;
    Color text_Color;
    String text;
    Font font;
    int fontSize;
    int fontStyle;

    public Cell2(int x,int y,int width,int height,Color cell_Color,Color stroke_Color,Color text_Color,int stroke,String text){
        topLeft= new Point2(x,y);
        this.width=width;
        this.height=height;
        this.stroke=stroke;
        this.cell_Color=cell_Color;
        this.stroke_Color=stroke_Color;
        this.text_Color=text_Color;
        this.text=text;
    }
    public void paint(Graphics g)
    {
        The_Task.Rectangle r1 = new The_Task.Rectangle(topLeft.x, topLeft.y, width,height,cell_Color,stroke_Color,stroke);
        r1.paint(g);
        g.setColor(text_Color);
        font = g.getFont().deriveFont(fontSize);
        g.setFont(font);
        FontMetrics e = g.getFontMetrics();
        g.drawString(text, topLeft.x+width/20, topLeft.y+4*(e.getHeight()-e.getAscent()));
    }
    public void paintNormal(Graphics g){
        The_Task.Rectangle r1 = new The_Task.Rectangle(topLeft.x, topLeft.y, width,height,cell_Color,stroke_Color,stroke);
        r1.paint(g);
        g.setColor(text_Color);
        font = g.getFont().deriveFont(fontSize);
        g.setFont(font);
        FontMetrics e = g.getFontMetrics();
        g.drawString(text, topLeft.x+width/20, topLeft.y+4*(e.getHeight()-e.getAscent()));
    }
    public void paintHighlighted(Graphics g){
        The_Task.Rectangle r1 = new Rectangle(topLeft.x, topLeft.y, width,height,cell_Color,stroke_Color,stroke);
        r1.paint(g);
        g.setColor(Color.white);
        Font f = new Font(Font.SERIF,Font.BOLD, (int) (height/1.5));
        g.setFont(f);
        FontMetrics e = g.getFontMetrics();
        g.drawString(text, topLeft.x+stroke+10, topLeft.y+4*(e.getHeight()-e.getAscent()));
    }
}
