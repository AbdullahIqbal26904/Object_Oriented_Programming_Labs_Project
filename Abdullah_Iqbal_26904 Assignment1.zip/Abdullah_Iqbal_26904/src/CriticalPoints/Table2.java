package CriticalPoints;

import The_Task.Cell;
import The_Task.TitleBar;
import java.awt.*;
import java.util.Objects;
import java.util.Scanner;

public class Table2  {
    public void paint(Graphics g,String[][] a,String[] firstRow,int numberOfLines,String title,Color cellColor,Color borderColor, Color textColor, Color titlebarColor,Color first) {
        int x=0;
        int y=0;
        int height= (int) (800/(numberOfLines+4));
        int stroke=2;
        int width=800-(stroke*8);
        if(title==null) {
            TitleBar t = new TitleBar(x, y, width, height, titlebarColor, borderColor, stroke, "Data Table");
            t.paintTitleBar(g);
            t.redClosingButton(g);
        }else {
            TitleBar t = new TitleBar(x,y,width,height, titlebarColor,borderColor,stroke,title);
            t.paintTitleBar(g);
            t.redClosingButton(g);
        }
        y=y+height;
        for(int column=0;column< firstRow.length;column++){
            Cell2 t2 = new Cell2(x,y,width/(firstRow.length),height, first,borderColor,textColor,stroke,firstRow[column]);
            t2.paint(g);
            x+=width/(firstRow.length);
        }
        y=y+height;
        for(int i=0;i<numberOfLines-2;i++){
            x=0;
            for(int column=0;column<firstRow.length;column++){
                if(a[i][column] == null || Objects.equals(a[i][column], "")){
                    Cell2 t2 = new Cell2(x,y,width/(firstRow.length),height, cellColor,borderColor,textColor,stroke,"default");
                    t2.paintNormal(g);
                }else {
                    Cell2 t2 = new Cell2(x, y, width / (firstRow.length), height, cellColor, borderColor,textColor, stroke, a[i][column]);
                    t2.paintNormal(g);
                }
                x+=width/(firstRow.length);
            }
            y+=height;
        }
    }
}
