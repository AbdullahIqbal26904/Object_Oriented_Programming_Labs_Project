package CriticalPoints;

import java.awt.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class extractingFromFile extends Canvas {
    public boolean isFileEmpty() throws FileNotFoundException {
        File f2 = new File("C:\\Users\\hp\\IdeaProjects\\Abdullah_Iqbal_26904\\data.txt");
        Scanner s2 = new Scanner(f2);
        if(s2.hasNext()){
            return false;
        }
        return true;
    }
    public  String heading() throws FileNotFoundException {
        File f2 = new File("C:\\Users\\hp\\IdeaProjects\\Abdullah_Iqbal_26904\\data.txt");
        Scanner s2 = new Scanner(f2);
        String title;
        String dataHeading= s2.nextLine();
        if(dataHeading.contains("Title")){
            title=dataHeading.substring(7,dataHeading.length());
        }else {
            title=null;
        }
        return title;
    }
    public int nol() throws FileNotFoundException {
        File f1 = new File("C:\\Users\\hp\\IdeaProjects\\Abdullah_Iqbal_26904\\data.txt");
        Scanner sc = new Scanner(f1);
        int f=0;
        String s;
        while (sc.hasNext()){
            f++;
            s = sc.nextLine();
        }
        return f;
    }
    public String[] read() throws FileNotFoundException {
        File f2 = new File("C:\\Users\\hp\\IdeaProjects\\Abdullah_Iqbal_26904\\data.txt");
        Scanner s2 = new Scanner(f2);
        String s;
        String[] firstRow;
        String head= heading();
        if(head != null){
            s=s2.nextLine();
        }
        String title;
        s= s2.nextLine();
        firstRow=s.split(",");
        return firstRow;
    }
    public String[][] read2(int numberOfRows) throws FileNotFoundException {
        File f2 = new File("C:\\Users\\hp\\IdeaProjects\\Abdullah_Iqbal_26904\\data.txt");
        Scanner s2 = new Scanner(f2);
        int f = nol();
        int x=0;
        String[] c=new String[numberOfRows];
        String head= heading();
        if(head!=null){
            head=s2.nextLine();
            head=s2.nextLine();
            String[][] a = new String[f-2][numberOfRows];
            while (x<nol()-2){
                String line=s2.nextLine();
                String[] b;
                b=line.split(",");

                for(int i=0;i<b.length;i++){
                    c[i]=b[i];
                }
                for(int i=0;i<a[0].length;i++){
                    a[x][i]=c[i];
                }
                for (int g=0;g<c.length;g++){
                    c[g]=null;
                }
                x++;
            }
            return a;
        }
        head=s2.nextLine();
        String[][] a = new String[f-1][numberOfRows];
        while (x<nol()-1){
            String line=s2.nextLine();
            String[] b;
            b=line.split(",");
            for(int i=0;i<5;i++){
                a[x][i]=b[i];
            }
            x++;
        }
        return a;
    }
}
