package problem1;

public class SalaryEmployee extends Employee {
    private double weeklySalary;
    public SalaryEmployee(String fname,String lname,double weekSalary){
        super(fname, lname);
        this.weeklySalary=weekSalary;
    }
    public double getWeekSalary(){
        return weeklySalary;
    }
    public void setWeeklySalary(double weeklySalary){
        this.weeklySalary=weeklySalary;
    }
    public double earnings(){
        return weeklySalary*4;
    }
    public String toString()
        {
       return "Salaried Employye"+ "\n"+super.toString()+ "\nweekly salary: "+ getWeekSalary();
        }

}
