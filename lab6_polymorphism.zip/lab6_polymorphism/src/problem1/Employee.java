package problem1;

public abstract class Employee {
    private String fname;
    private String lname;
    public Employee(String fname,String lname){
        this.fname=fname;
        this.lname=lname;
    }
    public String getfname(){
        return fname;
    }
    public String getLname(){
        return lname;
    }
    public void setFname(String fname){
        this.fname=fname;
    }
    public void setLname(String lname){
        this.lname=lname;
    }
    public String toString(){
        return "First name: "+getfname()+"\nLast name: "+getLname();
    }
}
