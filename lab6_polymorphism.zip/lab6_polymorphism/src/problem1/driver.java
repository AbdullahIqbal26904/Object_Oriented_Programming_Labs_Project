package problem1;

public class driver {
    public static void main(String[] args) {
        SalaryEmployee emp1 = new SalaryEmployee("Abdullah","Iqbal",500000);
        HourlyEmployee emp2 = new HourlyEmployee("Haseeb","Ahmed",60000,6);
        HourlyEmployee emp3 = new HourlyEmployee("Hamza","Ali",70000,6);
        SalaryEmployee emp4 = new SalaryEmployee("Haris","Nooruddin",800000);
        SalaryEmployee emp5 = new SalaryEmployee("Abdul","Wasey",900000);
        Employee[] er={new SalaryEmployee("Abdullah","Iqbal",500000),
                new HourlyEmployee("Haseeb","Ahmed",60000,6),
                new HourlyEmployee("Hamza","Ali",70000,6),
                new SalaryEmployee("Haris","Nooruddin",800000),
                new SalaryEmployee("Abdul","Wasey",900000)};
        for(Employee employee : er){
            System.out.println(employee.toString());
            if(employee instanceof HourlyEmployee){
                System.out.println("Earnings: "+((HourlyEmployee) employee).earnings());
            }else {
                System.out.println("Earnings: "+((SalaryEmployee) employee).earnings());
            }
            System.out.println();
        }
    }
}
