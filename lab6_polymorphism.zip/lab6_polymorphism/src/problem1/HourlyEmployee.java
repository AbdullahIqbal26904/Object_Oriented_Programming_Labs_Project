package problem1;

public class HourlyEmployee extends Employee {
    private double hourly_wage;
    private int no_hours_worked;
    public HourlyEmployee(String fname,String lname,double hourly_wage,int no_hours_worked){
        super(fname, lname);
        this.hourly_wage=hourly_wage;
        this.no_hours_worked=no_hours_worked;
    }
    public double getHourly_wage(){
        return hourly_wage;
    }
    public int getNo_hours_worked(){
        return no_hours_worked;
    }
    public void setHourly_wage(double hourly_wage){
        this.hourly_wage=hourly_wage;
    }
    public void setNo_hours_worked(int no_hours_worked){
        this.no_hours_worked=no_hours_worked;
    }
    public double earnings(){
        double earnings = no_hours_worked*hourly_wage;
        return earnings;
    }
    public String toString()
    {
        return "Hourly Waged Employee "+ "\n"+super.toString()+ "\nHourly wage: "+ getHourly_wage()+"\nnumber of hours worked: "+getNo_hours_worked();
    }
}
