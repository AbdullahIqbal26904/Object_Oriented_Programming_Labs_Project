package problem2;

public class Sphere extends Shape {
    private double radius;
    public Sphere(double radius){
        this.radius=radius;
    }
    public double getRadius(){
        return radius;
    }
    public double getSurfaceArea(){
        return 4*Math.PI*getRadius()*getRadius();
    }
    public double getVolume(){
        return (4/3)*Math.PI*getRadius()*getRadius()*getRadius();
    }
    public String getShapeType(){
        return "Sphere";
    }
    public String toString(){
        return getShapeType()+" has radius of: "+getRadius()+" has surface area of: "+getSurfaceArea()+" Volume: "+getVolume();
    }
}
