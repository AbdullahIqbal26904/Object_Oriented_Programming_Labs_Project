package problem2;

public class Cuboid extends Shape {
    private double length;
    private double breadth;
    private double height;
    public Cuboid(double length,double breadth,double height){
        this.length=length;
        this.breadth=breadth;
        this.height=height;

    }
    public double getLength(){
        return length;
    }
    public double getBreadth(){
        return breadth;
    }
    public double getHeight(){
        return height;
    }
    public double getSurfaceArea(){
        return 2*(getLength()*getBreadth()+getBreadth()*getHeight()+getBreadth()*getLength());
    }
    public double getVolume(){
        return getLength()*getBreadth()*getHeight();
    }
    public String getShapeType(){
        return "Cuboid";
    }
    public String toString(){
        return getShapeType()+" has length of: "+getLength()+" height of: "+getHeight()+" has surface area of: "+getSurfaceArea()+" Volume: "+getVolume();
    }
}
