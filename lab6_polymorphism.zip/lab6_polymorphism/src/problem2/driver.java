package problem2;


import problem1.Employee;
import problem1.HourlyEmployee;
import problem1.SalaryEmployee;

import java.util.ArrayList;
import java.util.Iterator;

public class driver {
    public static void main(String[] args) {
//        Shape[] er = {new Sphere(3),
//                new Cuboid(5, 10, 4),
//                new Cylinder(6.7, 3),
//                new Cube(4)};
        ArrayList<Shape> er = new ArrayList<Shape>();
        er.add(new Sphere(3));
        er.add(new Cuboid(5, 10, 4));
        er.add(new Cylinder(6.7, 3));
        er.add(new Cube(4));

        Iterator<Shape> shapeIterator = er.iterator();
        while (shapeIterator.hasNext()) {
            Shape counter = shapeIterator.next();
            System.out.println(counter.toString());
            System.out.println(counter.getId());
        }
    }
}

