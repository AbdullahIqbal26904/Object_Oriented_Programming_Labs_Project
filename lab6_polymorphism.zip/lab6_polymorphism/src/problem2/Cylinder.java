package problem2;

public class Cylinder extends Shape {
    private double height;
    private double radius;
    public Cylinder(double height,double radius){
        this.height=height;
        this.radius=radius;
    }
    public double getHeight(){
        return height;
    }
    public double getRadius(){
        return radius;
    }
    public double getSurfaceArea(){
        return 2*Math.PI*getRadius()*(getRadius()+getHeight());
    }
    public double getVolume(){
        return getHeight()*Math.PI*getRadius()*getRadius();
    }
    public String getShapeType(){
        return "Cylinder";
    }
    public String toString(){
        return getShapeType()+" has radius of: "+getRadius()+" height of: "+getHeight()+" has surface area of: "+getSurfaceArea()+" Volume: "+getVolume();
    }
}
