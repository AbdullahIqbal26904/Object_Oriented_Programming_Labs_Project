package myComponents;

import java.awt.*;

public class Window extends MyButton{
    private final MyButton topBar;
    private final MyButton closeButton;
    private boolean visible;

    public Window(int x, int y, int width, int height, String text) {
        super(x, y, width, height,Color.BLACK, Color.GRAY);

        int topBarHeight = 30;
        topBar = new MyButton(x, y, width, topBarHeight, Color.BLACK, Color.GRAY, text);

        int closeButtonSize = 20;
        closeButton = new MyButton(x + width - closeButtonSize - 5, y + 5, closeButtonSize, closeButtonSize,  Color.WHITE, Color.RED);
    }

    public void paint(Graphics g) {
        super.paint4(g);
        topBar.paint4(g);
        closeButton.paint4(g);
    }

    public boolean Clicked(int x, int y){
        return closeButton.Clicked(x,y);
    }

    public void setVisible(boolean visible){
        this.visible = visible;
    }

    public boolean getVisible(){
        return visible;
    }
}
