package myComponents;

import javax.swing.*;
import java.awt.*;
import java.awt.image.ImageObserver;

public class LayerButton {
    private int x;
    private int y;
    private int width;
    private int height;
    private String name;
    public boolean pressed;
    Image Depressed,Pressed,Current;


    public LayerButton(int x, int y, int width, int height, String name) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.name = name;
        pressed=false;

        Current=Depressed;


    }

    public boolean IsClicked(int x, int y)
    {
        if(x > this.x && x < this.x + width && y > this.y && y < this.y + height)
        {
            if(pressed== true){
                pressed=false;
                Current=Depressed;
            }
            else {
                pressed = true;
                Current = Pressed;
            }
            return true;
        }
        pressed=false;
        Current=Depressed;
        return false;
    }

    public void paint(Graphics g, ImageObserver observer) {
        g.setColor(Color.BLACK);
        g.fillRect(x,y,width,height);
        if(pressed==true) g.setColor(Color.orange);
        else g.setColor(Color.white);
        g.fillRect(x+2,y+2,width-4,height-4);

        Font font=new Font("Arial",Font.PLAIN,13);
        g.setFont(font);
        g.setColor(Color.BLACK);
        FontMetrics m=g.getFontMetrics();
        int s_width=m.stringWidth(name);
        int s_height=m.getAscent()-m.getDescent();
        g.drawString(name,x+width/2-s_width/2,y+height/2+s_height/2);

        g.drawImage(Current,x+4,y+6,observer);
    }

    public void setY(int y){
        this.y=y;
    }
    public int getY(){
        return y;
    }
    public static void Exchange(LayerButton one, LayerButton two){
        int first_y=one.getY();
        one.setY(two.getY());
        two.setY(first_y);
    }
    public void setHeight(int height){
        this.height=height;

    }


}
