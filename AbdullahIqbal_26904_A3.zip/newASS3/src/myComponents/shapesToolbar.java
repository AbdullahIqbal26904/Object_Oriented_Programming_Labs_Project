package myComponents;

import javax.swing.*;
import java.awt.*;
import java.awt.image.ImageObserver;
import java.util.ArrayList;

public class shapesToolbar implements PositionListener {
    int x;
    int y;
    int height;
    private MyButton Rtriangle,Etriangle,Rectangle,Circle,Hexagon,Pentagon;
    private Image Rtriangle_pressed,Etriangle_pressed,Rectangle_pressed,Circle_pressed,Hexagon_pressed,Pentagon_pressed;
    private Image Rtriangle_unpressed,Etriangle_unpressed,Rectangle_unpressed,Circle_unpressed,Hexagon_unpressed,Pentagon_unpressed;

    int width;
    ArrayList<MyButton> shapes = new ArrayList<>();
    public shapesToolbar(int x, int y, int height, int width, Image pre, Image dep){
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;

        Rtriangle_unpressed = new ImageIcon("C:\\Users\\hp\\IdeaProjects\\newASS3\\src\\rtdep.png").getImage();
        Rtriangle_pressed = new ImageIcon("C:\\Users\\hp\\IdeaProjects\\newASS3\\src\\download.png").getImage();
        Rtriangle=new MyButton(200,0,100,40,Rtriangle_unpressed,Rtriangle_pressed);
        shapes.add(Rtriangle);

        Etriangle_unpressed = new ImageIcon("C:\\Users\\hp\\IdeaProjects\\newASS3\\src\\etd.png").getImage();
        Etriangle_pressed = new ImageIcon("C:\\Users\\hp\\IdeaProjects\\newASS3\\src\\etp.png").getImage();
        Etriangle=new MyButton(300,0,100,40,Etriangle_unpressed,Etriangle_pressed);
        shapes.add(Etriangle);

        Rectangle_unpressed = new ImageIcon("C:\\Users\\hp\\IdeaProjects\\newASS3\\src\\rd.jpg").getImage();
        Rectangle_pressed = new ImageIcon("C:\\Users\\hp\\IdeaProjects\\newASS3\\src\\rp.jpg").getImage();
        Rectangle=new MyButton(400,0,100,40,Rectangle_unpressed,Rectangle_pressed);
        shapes.add(Rectangle);

        Circle_unpressed = new ImageIcon("C:\\Users\\hp\\IdeaProjects\\newASS3\\src\\Circle_unpressed.png").getImage();
        Circle_pressed = new ImageIcon("C:\\Users\\hp\\IdeaProjects\\newASS3\\src\\Circle_pressed.png").getImage();
        Circle=new MyButton(200,40,100,40,Circle_unpressed,Circle_pressed);
        shapes.add(Circle);

        Hexagon_unpressed = new ImageIcon("C:\\Users\\hp\\IdeaProjects\\newASS3\\src\\Hexagon_unpressed.png").getImage();
        Hexagon_pressed = new ImageIcon("C:\\Users\\hp\\IdeaProjects\\newASS3\\src\\Hexagon_pressed.png").getImage();
        Hexagon=new MyButton(300,40,100,40,Hexagon_unpressed,Hexagon_pressed);
        shapes.add(Hexagon);

        Pentagon_unpressed = new ImageIcon("C:\\Users\\hp\\IdeaProjects\\newASS3\\src\\Pentagon_unpressed.png").getImage();
        Pentagon_pressed = new ImageIcon("C:\\Users\\hp\\IdeaProjects\\newASS3\\src\\Pentagon_pressed.png").getImage();
        Pentagon=new MyButton(400,40,100,40,Pentagon_unpressed,Pentagon_pressed);
        shapes.add(Pentagon);



    }
    public void paint(Graphics g, ImageObserver observer){
        g.setColor(Color.lightGray);
        g.fillRect(x,y,width,height);
        int count=0;
        for (MyButton bt:
             shapes) {
            count++;
            bt.paintf(g,observer);
        }
    }

    @Override
    public void click(int x, int y) {
        for (MyButton b: shapes){
            b.IsClicked2(x,y);
            if(b.isPressed()){
                b.getListener().onClick(x,y);
            }
        }
    }

    @Override
    public void press(int x, int y) {

    }

    @Override
    public void release(int x, int y) {

    }
}
