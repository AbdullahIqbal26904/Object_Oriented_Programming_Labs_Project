package myComponents;

public interface PositionListener {
    void click(int x, int y);
    void press(int x, int y);
    void release(int x, int y);
}
