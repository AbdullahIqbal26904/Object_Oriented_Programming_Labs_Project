package myComponents;

import javax.swing.*;
import java.awt.*;
import java.awt.image.ImageObserver;
import java.util.ArrayList;

public class Ctb implements PositionListener {
    private int x;
    private int y;
    private int width;
    private int height;
    ArrayList<ColorButton> color_buttons = new ArrayList<>();
    private ColorButton fill,stroke;
    Image grad;
    boolean gradient_press;
    private ColorGradient editcolor;
    private MyButton Close,gradient;
    private Image close;

    private MyButton select;

    public Ctb(int x, int y, int width, int height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;

        color_buttons.add(new ColorButton(660,0,80,40,Color.green));
        color_buttons.add(new ColorButton(660+80,0,80,40, Color.blue));
        color_buttons.add(new ColorButton(660+160,0,80,40,Color.PINK));

        color_buttons.add(new ColorButton(660,40,80,40,Color.yellow));
        color_buttons.add(new ColorButton(660+80,40,80,40,Color.magenta));
        color_buttons.add(new ColorButton(660+160,40,80,40,Color.orange));



        color_buttons.add(new ColorButton(660,80,80,40, Color.WHITE));
        color_buttons.add(new ColorButton(660+80,80,80,40, Color.WHITE));
        color_buttons.add(new ColorButton(660+160,80,80,40, Color.WHITE));
        //color_buttons.add(new ColorButton(x+160+30*3,y+10+60,20,20, Color.WHITE));


        fill=new ColorButton(x+10,y+2,40,40, Color.WHITE);
        stroke=new ColorButton(x+80,y+2,40,40, Color.WHITE);
        Image grad=new ImageIcon("C:\\Users\\hp\\IdeaProjects\\newASS3\\src\\multicolor.png").getImage();
        gradient=new MyButton(900,0,100,40,"Edit Color",grad,grad);
        gradient_press=false;

        editcolor=new ColorGradient(250,90,500,500);

        close=new ImageIcon("C:\\Users\\hp\\IdeaProjects\\newASS3\\src\\cross.png").getImage();
        Close= new MyButton(715, 92, 33, 33, "",close, close);


        Image Select=new ImageIcon("C:\\Users\\hp\\IdeaProjects\\newASS3\\src\\download (1).png").getImage();
        select=new MyButton(530,500,150,50,"",Select,Select);


    }

    public void paint(Graphics g, ImageObserver observer) {
       // g.setColor(Color.BLACK);
        g.fillRect(x,y,width+4,height+4);
        g.setColor(Color.LIGHT_GRAY);
        g.fillRect(x+2, y+2, width, height);
        g.setColor(Color.GRAY);
        g.fillRect(x+160, y+2, 300, 120);
        for (ColorButton b : color_buttons) {
            b.paint(g, observer);
        }

        fill.paint(g,observer);
        g.setColor(Color.BLACK);
        g.drawString("FILL",x+15,y+60);

        stroke.paint(g,observer);
        g.setColor(Color.BLACK);
        g.drawString("STROKE",x+70,y+60);

        g.setColor(Color.BLACK);
        gradient.paint(g,observer);
        g.drawString("GRADIENT",910,40);

        if(gradient_press){
            editcolor.Draw(g,observer);
            Close.paint(g,observer);
            g.setColor(Color.BLACK);
            g.fillRect(528,498,154,54);
            select.paint(g,observer);
        }
    }

    @Override
    public void click(int x, int y) {
        if (x > this.x && x < this.x + 140 && y > this.y && y < this.y + 100) {
            fill.IsClicked(x, y);
            stroke.IsClicked(x, y);
        }


        if (x > this.x+150 && x < this.x+150+190 && y > this.y && y < this.y + 100) {
            for (ColorButton b : color_buttons) {
                b.IsClicked(x, y);
                if (b.IsClicked(x, y)) {
                    if (fill.pressed) {
                        fill.setColor(b.getColor());
                    } else if (stroke.pressed) {
                        stroke.setColor(b.getColor());
                    }
                }
            }
        }

        if (x > this.x+350  && x < this.x+350+60 + 140 && y > this.y+10 && y < this.y+10+60) {
            if (gradient.IsClicked(x, y)) {
                gradient_press = true;

            }
        }

        if (gradient_press== true) {
            editcolor.IsClick(x, y);
            if (Close.IsClicked(x, y) == true) {
                gradient_press = false;
            }
            if(select.IsClicked(x,y)==true){
                fillColor(editcolor.getColor());
                gradient_press=false;
            }
        }


    }

    @Override
    public void press(int x, int y) {

    }

    @Override
    public void release(int x, int y) {

    }

    int count=0;
    public void fillColor(Color color) {
        color_buttons.get(6 + count).setColor(color);
        count++;
        if(count==3) count=0;
    }




}
