package myComponents;

import javax.swing.*;
import java.awt.*;
import java.awt.image.ImageObserver;
import java.util.ArrayList;

public class ltb implements PositionListener{
    private int x;
    private int y;
    private int width;
    private int height;

    private ArrayList<MyButton> command=new ArrayList<>();
    private ArrayList<LayerButton> many_layers=new ArrayList<>();

    private Image Add_pressed,Remove_pressed,Up_pressed,Down_pressed;
    private Image Add_unpressed,Remove_unpressed,Up_unpressed,Down_unpressed;
    private Image layer_head;
    private MyButton Add,Remove,Up,Down;
    private int layer_num=1;
    String S="Layer : ";
    private int l_height=32;
    private int l_width=250;

    public ltb(int x, int y, int width, int height,Image pre,Image dep) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;

        Add_pressed = new ImageIcon("C:\\Users\\hp\\IdeaProjects\\newASS3\\src\\Add_pressed.png").getImage();
        Add_unpressed = new ImageIcon("C:\\Users\\hp\\IdeaProjects\\newASS3\\src\\Add_unpressed.png").getImage();
        Add=new MyButton(900,600,50,32,"Add",dep,pre);
        command.add(Add);

        Remove_pressed = new ImageIcon("C:\\Users\\hp\\IdeaProjects\\giftzip (1)\\src\\Remove_pressed.png").getImage();
        Remove_unpressed = new ImageIcon("C:\\Users\\hp\\IdeaProjects\\giftzip (1)\\src\\Remove_unpressed.png").getImage();
        Remove=new MyButton(900,660,50,32,"Remove",dep,pre);
        command.add(Remove);

        Up_pressed = new ImageIcon("C:\\Users\\hp\\IdeaProjects\\giftzip (1)\\src\\Up_pressed.png").getImage();
        Up_unpressed = new ImageIcon("C:\\Users\\hp\\IdeaProjects\\giftzip (1)\\src\\Up_unpressed.png").getImage();
        Up=new MyButton(960,660,50,32,"Up",dep,pre);
        command.add(Up);

        Down_pressed = new ImageIcon("C:\\Users\\hp\\IdeaProjects\\giftzip (1)\\src\\Down_pressed.png").getImage();
        Down_unpressed = new ImageIcon("C:\\Users\\hp\\IdeaProjects\\giftzip (1)\\src\\Down_unpressed.png").getImage();
        Down=new MyButton(1020,660,50,32,"Down",dep,pre);
        command.add(Down);

        layer_head=new ImageIcon("C:\\Users\\hp\\IdeaProjects\\newASS3\\images.jpg").getImage().getScaledInstance(250,32,Image.SCALE_FAST);


        many_layers.add(new LayerButton(900,64,l_width,l_height,S+layer_num));

    }
    public void paint(Graphics g, ImageObserver observer) {
        g.setColor(Color.BLACK);
        g.fillRect(x,y,width,height);

        g.setColor(Color.GRAY);
        g.fillRect(900,650,250,100);

        g.drawImage(layer_head,x,y,observer);
        for (MyButton b : command) {
            b.paint(g, observer);
        }


        for(LayerButton l:many_layers){
            l.paint(g,observer);
        }


    }

    public void New_position(){
        int starty=64;
        int i=0;
        for(LayerButton s:many_layers){
            many_layers.get(i).setY(starty + (i*l_height));
            i++;
        }

    }

    @Override
    public void click(int x, int y) {
        if (x > this.x && x < this.x + width && y > this.y && y < this.y + height) {
            for (MyButton s : command) {
                s.IsClicked(x, y);
            }
        }

        if(x > this.x && x < this.x + width && y > this.y && y < 720-50)
            for (LayerButton s : many_layers) {
                if(s.IsClicked(x, y)) {
                }
            }

    }
    @Override
    public void press(int x, int y) {

    }

    @Override
    public void release(int x, int y) {

    }
}
