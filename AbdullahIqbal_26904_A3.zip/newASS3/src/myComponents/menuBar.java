package myComponents;

import java.awt.*;
import java.awt.image.ImageObserver;
import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class menuBar implements PositionListener {
    private int x;
    private int y;
    private int width;
    private int height;
    private boolean clicked = false;
    boolean filed=false;
    boolean editeD=false;
    Graphics g;
    ImageObserver observer;
    SaveFile saveFile;

    ArrayList<MyButton> buttons = new ArrayList<>();
    ArrayList<MyButton> fileDropdown = new ArrayList<>();
    ArrayList<MyButton> EditDropDown = new ArrayList<>();
    MyButton b1,b2,b3;
    private final ArrayList<MyButton> file_names = new ArrayList<>();
    private Window openWindow;


    public menuBar(int x, int y, int width, int height,Image pre,Image dep){
        this.x=x;
        this.y=y;
        this.width=width;
        this.height=height;

        MyButton button1 = new MyButton(0,0,100,40,"File",dep,pre);
        MyButton button2 = new MyButton(100,0,100,40,"Edit",dep,pre);
        b1 = new  MyButton(0,40,100,40,"New",dep,pre);
        b2 = new MyButton(0,80,100,40,"Open",dep,pre);
        b3 = new MyButton(0,120,100,40,"Save",dep,pre);
        buttons.add(button1);
        buttons.add(button2);
        openWindow = new Window(100,100,400,400,"files");

        button1.setListener(new ButtonListener() {
            @Override
            public void onClick(int x, int y) {
                //System.out.println("file clicked");

                fileDropdown.add(b1);
                fileDropdown.add(b2);
                fileDropdown.add(b3);
                b1.setListener(new ButtonListener() {
                    @Override
                    public void onClick(int x, int y) {
                        createNewFile();
                        System.out.println("new clicked");
                    }
                });
                b2.setListener(new ButtonListener() {
                    @Override
                    public void onClick(int x, int y) {
                        openFiles();
                        System.out.println("Open clicked");
                    }
                });
                b3.setListener(new ButtonListener() {
                    @Override
                    public void onClick(int x, int y) {
                        System.out.println("Save clicked");
                    }
                });

                filed=true;
                System.out.println("File clicked");
            }
        });
        button2.setListener(new ButtonListener() {
            @Override
            public void onClick(int x, int y) {
                System.out.println("edit clicked");
                MyButton e1 = new MyButton(100,40,100,40,"Undo",dep,pre);
                MyButton e2 =  new MyButton(100,80,100,40,"Redo",dep,pre);
                EditDropDown.add(e1);
                EditDropDown.add(e2);
                e1.setListener(new ButtonListener() {
                    @Override
                    public void onClick(int x, int y) {
                        System.out.println("Undo clicked");
                    }
                });
                e2.setListener(new ButtonListener() {
                    @Override
                    public void onClick(int x, int y) {
                        System.out.println("Redo clicked");
                    }
                });

                editeD=true;
            }
        });
        saveFile=new SaveFile();
        }
    public void paint(Graphics g, ImageObserver observer){
        g.setColor(Color.lightGray);
        g.fillRect(x,y,width,height);
        for (MyButton b: buttons){
            b.paint(g,observer);
        }
        for (MyButton b2:fileDropdown){
            b2.paint(g,observer);
        if(editeD){
            for (MyButton b3:EditDropDown){
                b3.paint(g,observer);
            }
        }
            if(openWindow.getVisible()){
                openWindow.paint(g);
                for(MyButton b:file_names){
                    b.paint4(g);
                }
        }
    }}

    @Override
    public void click(int x, int y) {
        for (MyButton b: buttons){
            b.IsClicked(x,y);
            if(b.IsPressed()){
                b.getListener().onClick(x,y);
            }
        }
        if (b2.Clicked(x, y)) {
            openWindow.setVisible(true);
            openFiles();
        }
            for (MyButton b2: fileDropdown){
                b2.IsClicked(x,y);
                if(b2.IsPressed()){
                    b2.getListener().onClick(x,y);
                }
            }
        for (MyButton b2: EditDropDown){
            b2.IsClicked(x,y);
            if(b2.IsPressed()){
                b2.getListener().onClick(x,y);
            }
        }

    }

    public void handleClick(int inputX, int inputY) {
        if (!openWindow.getVisible()) {
            if (openWindow.getVisible()) {
                if (b1.Clicked(inputX, inputY)) {
                    createNewFile();
                }
                if (b1.Clicked(inputX, inputY)) {
                    openWindow.setVisible(true);
                    openFiles();
                }
                if (b2.Clicked(inputX, inputY)) {
                    System.out.println("New Project Open");
                }
            }
        }
        else if (openWindow.getVisible()) {
            for(MyButton b : file_names){
                if(b.Clicked(inputX,inputY)){
                    System.out.println(b.getText()+" Opened");
                    openWindow.setVisible(false);
                    break;
                }
            }
            if (openWindow.Clicked(inputX, inputY)) {
                openWindow.setVisible(false);
            }
        }
    }
    public static void createNewFile() { //option 1

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH_mm_ss");
        String fileName = LocalDateTime.now().format(formatter) + ".txt";

        try {
            File save_file = new File("C:\\Users\\hp\\IdeaProjects\\newASS3\\src\\Files", fileName);
            if (save_file.createNewFile()) {
                System.out.println("File created: " + save_file.getName());
            } else {
                System.out.println("File already exists.");
            }

            System.out.println("Successfully created the file.");
        } catch (IOException e) {
            System.out.println("An error occurred while creating the file.");
            e.printStackTrace();
        }

    }
    public void openFiles(){ //option 3
        File file = new File("C:\\Users\\hp\\IdeaProjects\\newASS3\\src\\Files");
        String[] names = file.list();
        int y = 300;
        for (String name : names) {
            MyButton button = new MyButton(150, y, 300, 50, Color.BLACK, Color.GRAY, name);
            file_names.add(button);
            y += 50;
        }
    }



    @Override
    public void press(int x, int y) {

    }

    @Override
    public void release(int x, int y) {

    }
}
