package myComponents;

import java.awt.*;
import java.awt.image.ImageObserver;

public class MyButton
{
	public int x;
	public int y;
	private Image icon;
	private int width;
	private Color stroke_col;
	private Color button_col;
	private boolean img;
	private int height;
	private String text;
	public Image image_depressed;
	public Image image_pressed;
	private Image current_image;
	private boolean pressed;
	private Color textColor;
	private ButtonListener listener;

	public ButtonListener getListener() {
		return listener;
	}
	private boolean hovered;

	public void setListener(ButtonListener listener) {
		this.listener = listener;
	}

	public MyButton(int x, int y, int width, int height, String text, Image i_depressed, Image i_pressed)
	{
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		this.text=text;
		image_depressed = i_depressed.getScaledInstance(width,height,Image.SCALE_FAST);
		image_pressed = i_pressed.getScaledInstance(width,height,Image.SCALE_FAST);
		current_image = i_depressed.getScaledInstance(width,height,Image.SCALE_FAST);
		this.textColor=Color.black;
		listener=new ButtonListener() {
			@Override
			public void onClick(int x, int y) {

			}
		};
	}
	public MyButton(int x, int y, int width, int height,Image icon, Image i_depressed, Image i_pressed) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		image_depressed = i_depressed.getScaledInstance(width,height,Image.SCALE_FAST);
		image_pressed = i_pressed.getScaledInstance(width,height,Image.SCALE_FAST);
		current_image = image_depressed;
		this.img=true;
		this.icon = icon.getScaledInstance(width,height,Image.SCALE_FAST);

		listener = new ButtonListener() {
			@Override
			public void onClick(int x, int y) {

			}
		};
	}
	public MyButton(int x, int y, int width, int height, Image i_depressed, Image i_pressed)
	{
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		image_depressed = i_depressed.getScaledInstance(width, height, Image.SCALE_FAST);
		image_pressed = i_pressed.getScaledInstance(width, height, Image.SCALE_FAST);
		current_image = image_depressed;

		listener = new ButtonListener() {
			@Override
			public void onClick(int x, int y) {

			}
		};
	}
	public MyButton(int x, int y, int width, int height,Color color,Image i_depressed, Image i_pressed){
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		image_depressed = i_depressed.getScaledInstance(width,height,Image.SCALE_FAST);
		image_pressed = i_pressed.getScaledInstance(width,height,Image.SCALE_FAST);
		current_image = i_depressed.getScaledInstance(width,height,Image.SCALE_FAST);
		this.textColor=color;
		listener=new ButtonListener() {
			@Override
			public void onClick(int x, int y) {

			}
		};

	}
	public void setPressed(boolean pressed){
		this.pressed=pressed;
	}
	public MyButton(int x, int y, int length, int height, Color stroke_col, Color button_col, String text) {
		this.x = x;
		this.y = y;
		this.width = length;
		this.height = height;
		this.stroke_col = stroke_col;
		this.button_col = button_col;
		this.pressed = false;
		this.text = text;
	}
	public MyButton(int x, int y, int length, int height, Color stroke_col, Color button_col) {
		this.x = x;
		this.y = y;
		this.width = length;
		this.height = height;
		this.stroke_col = stroke_col;
		this.button_col = button_col;
		this.pressed = false;
		this.text = "";
	}

	public boolean isPressed() {
		return pressed;
	}

	public void paintf(Graphics graphics, ImageObserver observer) {
		graphics.drawImage(current_image, x, y, observer);

	}

	public void paint4(Graphics g){
			g.setColor(pressed ? Color.RED : stroke_col);
			g.fillRect(x, y, width, height);

			int innerButtonMargin = 3;
			g.setColor(button_col);
			g.fillRect(x + innerButtonMargin, y + innerButtonMargin, width - 2 * innerButtonMargin, height - 2 * innerButtonMargin);

			g.setColor(pressed ? Color.RED : stroke_col);
			FontMetrics fm = g.getFontMetrics();
			int textWidth = fm.stringWidth(text);
			int textHeight = fm.getHeight();
			int textX = x + (width - textWidth) / 2;
			int textY = y + (height - textHeight) / 2 + fm.getAscent();
			g.drawString(text, textX, textY);
		}

	public int getX() {
		return x;
	}
	public void Toggle(int inputX, int inputY) {
		if (Clicked(inputX, inputY)) {
			pressed = !pressed;
			if(img){
				changeImage();
			}
		}
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public String getText() {
		return text;
	}


	public Boolean IsPressed()
	{
		return pressed;
	}
	
	public boolean Clicked(int inputX, int inputY) {
		if (inputX >= x && inputX <= x + width && inputY >= y && inputY <= y + height) {
			return true;
		}
		return false;
	}
	
	public boolean IsClicked(int x, int y)
	{
		if(x > this.x && x < this.x + width && y > this.y && y < this.y + height)
		{
			pressed = true;
			current_image = image_pressed;
			this.textColor=Color.white;
			return true;
		}else {
			pressed=false;
			this.textColor=Color.black;
			current_image=image_depressed;
		}
		return false;
	}
	public void changeImage(){
		if(pressed){
			current_image = image_pressed;
		}
		else{
			current_image = image_depressed;
		}
	}
	public boolean IsClicked2(int x, int y){
		if(x > this.x && x < this.x + width && y > this.y && y < this.y + height)
		{
			pressed = true;
			current_image = image_pressed;
			this.textColor=textColor;
			return true;
		}
		else {
			pressed=false;
			current_image=image_depressed;
		}
		return false;
	}
	public void paint(Graphics graphics, ImageObserver observer){
		graphics.drawImage(current_image,x,y,observer);
		graphics.setColor(textColor);
		Font font = new Font(Font.SANS_SERIF,Font.BOLD,15);
		graphics.setFont(font);
		FontMetrics f=graphics.getFontMetrics();
		int f_width= f.stringWidth(text);
		int f_height = f.getAscent()-f.getDescent();
		graphics.drawString(text,x+width/2-f_width/2,y+height / 2+f_height/2);

	}
}
