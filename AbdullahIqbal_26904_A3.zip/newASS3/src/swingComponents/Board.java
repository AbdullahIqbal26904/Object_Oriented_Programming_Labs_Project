package swingComponents;

import myComponents.*;

import javax.swing.*;
import javax.swing.event.MouseInputListener;
import java.awt.*;
import java.awt.event.*;

public class Board extends JPanel
        implements ActionListener , MouseInputListener{

    private final int B_WIDTH = 1080;
    private final int B_HEIGHT = 720;
    private final int DELAY = 10;
    private Ctb  colorToolbar;

    private Timer timer;
    private int key = 0;
    private shapesToolbar shapes;
    private ltb layerTool;
    private boolean keyPressed = false;
    private boolean mousePressed = false;
    
    private boolean start_drawing = false;
    private menuBar Menu;

    //private colorToolbar Colortoolbar;
    Image pressed;
    Image depressed;

    private int x_init;
    private int y_init;
    private int x_final;
    private int y_final;
    
    private MyButton button;

    private class TAdapter extends KeyAdapter {

        @Override
        public void keyReleased(KeyEvent e) {
            
            int key = e.getKeyCode();
            keyPressed = false;

            if (key == KeyEvent.VK_SPACE) {
                
            }

        }

        @Override
        public void keyPressed(KeyEvent e) {

        	keyPressed = true;
            key = e.getKeyCode();

            if (key == KeyEvent.VK_SPACE) {
                
            }

        }
    }

    public Board() {

        initBoard();
    }

    private void InitializeAssets() {

        
        ImageIcon button_dep = new ImageIcon("C:\\Users\\hp\\IdeaProjects\\assignment3\\JavaPainter\\src\\square_depressed.png");
        depressed=button_dep.getImage();
        ImageIcon button_pre = new ImageIcon("C:\\Users\\hp\\IdeaProjects\\assignment3\\JavaPainter\\src\\square_pressed.png");
        pressed=button_pre.getImage();

    }

    private void initBoard() {

    	addMouseListener( this );
    	addMouseMotionListener( this );
    	addKeyListener(new TAdapter());
        setBackground(Color.WHITE);
        setPreferredSize(new Dimension(B_WIDTH, B_HEIGHT));
        setFocusable(true);

        InitializeAssets();

        Menu = new menuBar(0,0,B_WIDTH,40,pressed,depressed);
        shapes= new shapesToolbar(200,0,40,500,pressed,depressed);
        colorToolbar =new Ctb(500,0,B_WIDTH,40);
        layerTool=new ltb(900,40,B_WIDTH,B_HEIGHT,pressed,depressed);
        timer = new Timer(DELAY, this);
        timer.start();
    }

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Menu.paint(g,this);
        shapes.paint(g,this);
        colorToolbar.paint(g,this);
        layerTool.paint(g,this);
    }
    
    private void drawNotification(String text, Graphics g)
    {
    	g.setColor(Color.RED);
    	g.drawString(text + key + " pressed", 20, 20);
    }

    private void drawButton(Graphics g) {


    }

    @Override
    public void actionPerformed(ActionEvent e) {

        
        Toolkit.getDefaultToolkit().sync();
        repaint();
    }
    
    public void IsClicked(int x, int y)
    {
    	button.IsClicked(x, y);

    }
    

	@Override
	public void mouseClicked(MouseEvent e) {
		    Menu.click(e.getX(),e.getY());
            shapes.click(e.getX(),e.getY());
        colorToolbar.click(e.getX(),e.getY());
        Menu.handleClick(e.getX(),e.getY());
            layerTool.click(e.getX(),e.getY());
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		x_init = e.getX();
		y_init = e.getY();
		mousePressed = true;
		start_drawing = true;
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		mousePressed = false;
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		x_final = e.getX() - x_init;
		y_final = e.getY() - y_init;
	}
 }