package task2;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.ListIterator;

public class mailList {
    public static void main(String[] args) {
        LinkedList<address> a = new LinkedList<>();
        a.add(new address("A", "11 Ave", "U", "IL", "11111"));
        a.add(new address("R", "11 Lane", "M", "IL", "22222"));
        a.add(new address("T", "8 St", "C", "IL", "33333"));
        ListIterator l = a.listIterator(0);
        while (l.hasNext()){
            System.out.println(l.next());
        }
    }
}
