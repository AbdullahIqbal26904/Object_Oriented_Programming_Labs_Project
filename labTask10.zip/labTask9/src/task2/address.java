package task2;

public class address {
    private String name;
    private String street;
    private String city;
    private String state;
    private String code;

    @Override
    public String toString() {
        return
                "name='" + name + '\'' +
                ", street='" + street + '\'' +
                ", city='" + city + '\'' +
                ", state='" + state + '\'' +
                ", code='" + code + '\'' +
                '}';
    }

    public address(String name, String street, String city, String state, String code) {
        this.name=name;
        this.street=street;
        this.city=city;
        this.state=state;
        this.code=code;
    }
}
