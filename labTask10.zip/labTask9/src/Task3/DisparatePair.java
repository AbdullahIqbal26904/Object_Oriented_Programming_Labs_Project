package Task3;

public class DisparatePair<t1,t2> {
    t1 first;
    t2 second;
    public t1 getFirst() {
        return first;
    }

    public DisparatePair(t1 first, t2 second){
        this.first=first;
        this.second=second;
    }

    public t2 getSecond() {
        return second;
    }
}
