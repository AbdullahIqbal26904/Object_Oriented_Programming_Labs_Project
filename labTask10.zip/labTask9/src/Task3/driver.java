package Task3;

import java.util.ArrayList;
public class driver {
    public static void main(String[] args) {
        Pair<String> ps = new Pair<>("abc","efg");
        Pair<Double> pd = new Pair<>(29.0,67.9);
        System.out.println(ps.getFirst()+" "+ps.getSecond());
        System.out.println(pd.getFirst()+" "+pd.getSecond());
        ArrayList<DisparatePair> p= new ArrayList<>();
        p.add(new DisparatePair<>(1.3,3));
        p.add(new DisparatePair<>("abc",2));

       // System.out.println(p.get(0).getFirst()+" "+p.get(0).getSecond());
        for (DisparatePair p1:
             p) {
            System.out.println(p1.getFirst()+" "+p1.getSecond());
        }
    }
}
