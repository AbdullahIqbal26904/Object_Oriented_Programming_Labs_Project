package Task3;

public class Pair<t> {
    t first;
    t second;

    public t getFirst() {
        return first;
    }

    public Pair(t first, t second){
        this.first=first;
        this.second=second;
    }

    public t getSecond() {
        return second;
    }
}
