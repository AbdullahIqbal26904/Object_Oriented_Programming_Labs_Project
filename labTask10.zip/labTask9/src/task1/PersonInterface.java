package task1;

interface PersonInterface{
     int computeTotalWealth();
    String getName();
}
