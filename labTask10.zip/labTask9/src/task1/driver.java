package task1;

public class driver {
    public static void main(String[] args) {
        Person p1 = new Person(100,90,"Abdullah ","Iqbal");
        PersonInterface personInterface1 = p1;
        System.out.println(personInterface1.getName());
        System.out.println(personInterface1.computeTotalWealth());
        boolean b = p1==personInterface1;
        System.out.println("Do person1 and personinterface1 point to the same object instance? " + b);
        Person p2 = new Person(200,145,"Abdullah ","Iqbal");
        PersonInterface personInterface2 = p2;
        System.out.println(personInterface2.getName());
        System.out.println(personInterface2.computeTotalWealth());
        boolean b2 = p1==personInterface1;
        System.out.println("Do person1 and personinterface1 point to the same object instance? " + b2);
        Person p3 = new Person(100,90,"Abdullah ","Iqbal");
        PersonInterface personInterface3 = p3;
        System.out.println(personInterface3.getName());
        System.out.println(personInterface3.computeTotalWealth());
        boolean b3 = p1==personInterface1;
        System.out.println("Do person1 and personinterface1 point to the same object instance? " + b3);
        PersonInterface personinterface5 = new Person(3000, 4000, "Dadu ", "Daniel");
        System.out.println(personinterface5.getName());
        System.out.println(personinterface5.computeTotalWealth());

    }
}
