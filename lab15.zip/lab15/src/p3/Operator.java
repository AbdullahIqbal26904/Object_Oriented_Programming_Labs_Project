package p3;

public interface Operator {
    void operate();
}
