package p3;

public class Car implements Vehicle{
    private int speed;
    Operator operator;

    public void setOperator(Operator operator) {
        this.operator = operator;

    }

    public Car(int speed) {
        this.speed = speed;
    }

    @Override
    public void Start() {
        System.out.println("Car started");
    }

    @Override
    public boolean Stop(int distance) {
        int stoppingDistance = speed * speed / 20;
        return stoppingDistance <= distance;
    }

}
