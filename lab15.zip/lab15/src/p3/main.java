package p3;

public class main {
    public static void main(String[] args) {
//        Vehicle c = new Car(100);
//        c.Start();
//        System.out.println(c.Stop(50));
//        Vehicle c2 = new Bike(4);
//        c2.Start();
//        System.out.println(c2.Stop(150));
//        Vehicle c3 = new helicopter(50,new Pilot("xyz"));
//        c3.Start();
//        System.out.println(c3.Stop(70));
        TransportCompany t = new TransportCompany();
        t.makeTrip(100);
        t.makeTrip(1);
        t.makeTrip(3);
    }
}
