package p3;

public class Pilot implements Flyer{
    private String name;
    public Pilot(String name){
        this.name=name;
    }
    @Override
    public void operate() {
        System.out.println(name+" is operating helicopter.");
    }

    @Override
    public void flies() {
        System.out.println(name+" is flying helicopter");
    }
}
