package p3;

public interface Flyer extends Operator {
    void flies();
}
