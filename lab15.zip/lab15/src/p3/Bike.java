package p3;

public class Bike implements Vehicle{
    private int gear;
    Operator operator;

    public void setOperator(Operator operator) {
        this.operator = operator;
    }

    public Bike(int gear) {
        this.gear = gear;
    }

    @Override
    public void Start() {
        System.out.println("Bike started");
    }

    @Override
    public boolean Stop(int distance) {
        int stoppingDistance = gear * 10;
        return stoppingDistance <= distance;
    }

}
