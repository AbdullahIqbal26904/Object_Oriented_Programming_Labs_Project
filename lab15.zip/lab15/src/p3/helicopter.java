package p3;

public class helicopter implements Vehicle{
    private int rotations;
    Operator operator;

    public void setOperator(Operator operator) {
        this.operator = operator;
    }

    public helicopter(int rotations,Operator operator) {
        this.rotations = rotations;
        setOperator(operator);
    }

    @Override
    public void Start() {
        System.out.println("helicopter started.");
    }

    @Override
    public boolean Stop(int distance) {
        int stoppingDistance = rotations * 5;
        return stoppingDistance <= distance;
    }

}
