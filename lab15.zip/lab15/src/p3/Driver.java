package p3;

public class Driver implements Operator{
    private String name;
    public Driver(String name){
        this.name=name;
    }
    @Override
    public void operate() {
        System.out.println(name+" is operating car.");
    }
}
