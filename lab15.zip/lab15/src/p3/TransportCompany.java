package p3;

import java.util.ArrayList;
import java.util.Random;

public class TransportCompany {
    ArrayList<Car> v = new ArrayList<>();
    ArrayList<Bike> b = new ArrayList<>();
    ArrayList<helicopter> h = new ArrayList<>();
    ArrayList<Vehicle> vehicles = new ArrayList<>();
    static int count=0;
    Random r = new Random();
    public TransportCompany(){
        int ran = r.nextInt(10);
        for (int i=0; i<ran; i++){
            vehicles.add(new Car(r.nextInt(140)));
        }
        int ran2 = r.nextInt(10);
        for (int i=0; i<ran2; i++){
            vehicles.add(new Bike(r.nextInt(140)));
        }
        int ran3 = r.nextInt(10);
        for (int i=0; i<ran3; i++){
            vehicles.add(new helicopter(r.nextInt(600),new Driver("Pilot"+i+1)));
        }
    }
    public void makeTrip(int numberOfPassengers){
        Vehicle vehicle;
        Operator operator;
        if(numberOfPassengers==1){
             vehicle=getVehicle(numberOfPassengers);
            operator=new Rider("Rider"+ ++count);
        } else if (numberOfPassengers<=4) {
            vehicle=getVehicle(numberOfPassengers);
            operator=new Driver("Driver"+count++);
        }else {
            vehicle=getVehicle(numberOfPassengers);
            operator=new Pilot("pilot"+count++);
        }
        count++;
        vehicle.Start();
        operator.operate();
        boolean canStop = vehicle.Stop(r.nextInt(500));
        if (canStop) {
            System.out.println(vehicle+ " Vehicle stopped successfully");
        } else {
            System.out.println(vehicle+ " Vehicle could not stop in time");
        }
    }
    public Vehicle getVehicle(int numOfPassenger){
        Vehicle v2 = null;
        for (Vehicle v:
             vehicles) {
            if (v instanceof Bike && numOfPassenger==1){
                v2= v;
                break;
            }else if (v instanceof Car && numOfPassenger<=4){
                v2= v;
                break;
            }
            v2= v;
        }
        return v2;
    }
}
