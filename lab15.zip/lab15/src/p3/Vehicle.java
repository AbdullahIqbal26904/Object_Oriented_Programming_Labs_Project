package p3;

public interface Vehicle {
    public abstract void Start();
    abstract boolean Stop(int distance);
    void setOperator(Operator operator);
}
