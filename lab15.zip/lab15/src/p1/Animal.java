package p1;

public class Animal {
     String name,sound;
    public Animal(String name,String sound){
        this.name=name;
        this.sound=sound;
    }
    public void makeSound(){
        System.out.println(name+" "+sound);
    }

}
