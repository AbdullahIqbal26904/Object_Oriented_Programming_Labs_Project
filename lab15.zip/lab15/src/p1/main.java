package p1;

public class main {
    public static void main(String[] args) {
        Animal d = new Dog("xyz","barks");
        d.makeSound();
        Animal Cat = new Cat("abc","meow");
        Cat.makeSound();
    }
}
