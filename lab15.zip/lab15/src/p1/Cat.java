package p1;

public class Cat extends Animal{
    public Cat(String name, String sound) {
        super(name, sound);
    }
    @Override
    public void makeSound(){
        super.makeSound();
    }
}
