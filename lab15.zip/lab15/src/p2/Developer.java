package p2;

public class Developer extends Employee{
    private String language;
    public Developer(String name, double Salary, String department,String language) {
        super(name, Salary, department);
        this.language=language;
    }

    public String toString(){
        return "Developer "+super.toString()+" works on language: "+language;
    }
}
