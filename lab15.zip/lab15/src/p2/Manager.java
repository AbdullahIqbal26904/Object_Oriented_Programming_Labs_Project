package p2;

public class Manager extends Employee{
    double bonus;
    public Manager(String name, double Salary, String department,double bonus) {
        super(name, Salary, department);
        this.bonus=bonus;
    }

    public String toString(){
        return super.toString()+ " and bonus of: "+bonus;
    }


}
