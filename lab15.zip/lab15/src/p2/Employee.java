package p2;

public class Employee {
    String name;
    double Salary;
    String department;

    public Employee(String name,double Salary,String department){
        this.name=name;
        this.Salary=Salary;
        this.department=department;
    }

    public String toString() {
        return "Employee{" +
                "name='" + name + '\'' +
                ", Salary=" + Salary +
                ", department='" + department + '\'' +
                '}';
    }
}
