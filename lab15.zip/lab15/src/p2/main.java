package p2;

public class main {
    public static void main(String[] args) {
        Employee e1 = new Manager("abc",2000,"xyz",200);
        System.out.println(e1);
        Employee e2 = new Developer("fgh",9000,"uxy","java");
        System.out.println(e2);
    }
}
