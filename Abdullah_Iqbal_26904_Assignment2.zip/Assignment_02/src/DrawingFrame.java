import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;



public class DrawingFrame extends JFrame implements ActionListener,WindowListener {
    public static void main(String[] args)
    {
        JFrame frame = new JFrame( "Drawing Program" );
        frame.setDefaultCloseOperation(3);
        DrawingPanel panel = new DrawingPanel();
        frame.add( panel );
        FileIO f = new FileIO();
        frame.addWindowListener(new WindowListener() {
            @Override
            public void windowOpened(WindowEvent e) {
                panel.setstack(f.loadFromFile());
            }

            @Override
            public void windowClosing(WindowEvent e) {
                System.out.println("closing");
                f.saveToFile(panel.shapeStack);
            }

            @Override
            public void windowClosed(WindowEvent e) {

            }

            @Override
            public void windowIconified(WindowEvent e) {

            }

            @Override
            public void windowDeiconified(WindowEvent e) {

            }

            @Override
            public void windowActivated(WindowEvent e) {

            }

            @Override
            public void windowDeactivated(WindowEvent e) {

            }
        });
        frame.pack();
        frame.setVisible( true );
    }

    @Override
    public void actionPerformed(ActionEvent e) {

    }

    @Override
    public void windowOpened(WindowEvent e) {

    }

    @Override
    public void windowClosing(WindowEvent e) {

    }

    @Override
    public void windowClosed(WindowEvent e) {

    }

    @Override
    public void windowIconified(WindowEvent e) {

    }

    @Override
    public void windowDeiconified(WindowEvent e) {

    }

    @Override
    public void windowActivated(WindowEvent e) {

    }

    @Override
    public void windowDeactivated(WindowEvent e) {

    }
}
