import java.awt.*;
import java.util.Random;

public abstract class Shape {
    Point[] coordinates;
    int numOfVertices;
    Color color;
    int size;
    public abstract void Draw(Graphics g);
        public void setSize(int size){
            this.size=size;
        }
        public void setColor(Color color){
            this.color=color;
        }
        public void setCoordinates(Point[] coordinates) {
            this.coordinates = coordinates;
            this.numOfVertices = coordinates.length;
        }

    public Color getColor() {
        return color;
    }

    public Point[] getCoordinates() {
        return coordinates;
    }

    public void addPoint(Point point) {
        Point[] newCoordinates = new Point[numOfVertices + 1];
        for (int i = 0; i < numOfVertices; i++) {
            newCoordinates[i] = coordinates[i];
        }
        newCoordinates[numOfVertices] = point;
        coordinates = newCoordinates;
        numOfVertices++;
    }

}
