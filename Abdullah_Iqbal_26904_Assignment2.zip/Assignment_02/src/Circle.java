import java.awt.*;

public class Circle extends Shape {
    private int		size;
    private Point center;
    private Color 	color;
    Circle(int iSize, Point location, Color C)
    {
        setSize(iSize);
        setLocation(location);
        setColor(C);
    }
    public void setSize(int iSize) {
        if (iSize > 1) {
            size = iSize;
        } else {
            size = 1;
        }
    }
    void setLocation(Point Pcenter) {
        center = Pcenter;
    }
    public void setColor(Color Ccolor) {
        color = Ccolor;
    }
    int getSize()
    {
        return size;
    }

    Point getCenter()
    {
        return center;
    }

    public Color getColor()
    {
        return color;
    }
    public void Draw(Graphics g)
    {
        g.setColor(getColor());
        g.fillOval(getCenter().x - getSize()/2 ,getCenter().y - getSize()/2,getSize(),getSize());
    }
    public String toString(){
        return "Circle with size of: "+getSize();
    }
}
