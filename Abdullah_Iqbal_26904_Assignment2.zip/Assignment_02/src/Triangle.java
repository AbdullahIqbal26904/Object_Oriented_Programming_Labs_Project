import java.awt.*;

    public class Triangle extends Shape{

@Override
    public void Draw(Graphics g) {
        g.setColor(getColor());
        int[] xPoints = new int[3];
        int[] yPoints = new int[3];
        for (int i = 0; i < 3; i++) {
        xPoints[i] = coordinates[i].x;
        yPoints[i] = coordinates[i].y;
        }
        g.fillPolygon(xPoints,yPoints,numOfVertices);
        }

}
