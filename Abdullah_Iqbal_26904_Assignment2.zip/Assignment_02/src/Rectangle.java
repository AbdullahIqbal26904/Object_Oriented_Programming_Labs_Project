import java.awt.*;

public class Rectangle extends Shape {
    private int width;
    private int height;
    Point center;

    public void setWidth(int width) {
        this.width = width;
    }
    public void setHeight(int height) {
        this.height = height;
    }
    Rectangle(int width,int height, Point location, Color C)
    {
        setWidth(width);
        setHeight(height);
        setLocation(location);
        setColor(C);
    }
        void setLocation(Point Pcenter) {
            center = Pcenter;
        }
        public void setColor(Color Ccolor) {
            color = Ccolor;
        }
        int getSize()
        {
            return size;
        }
        Point getCenter()
        {
            return center;
        }
        public void Draw(Graphics g)
        {
            g.setColor(getColor());
            g.fillRect(getCenter().x ,getCenter().y ,width,height);
        }
        public String toString(){
        return "Rectangel with width of: "+width+" and height of: "+height;
        }

    public int getHeight() {
        return height;
    }

    public int getWidth() {
        return width;
    }
}
