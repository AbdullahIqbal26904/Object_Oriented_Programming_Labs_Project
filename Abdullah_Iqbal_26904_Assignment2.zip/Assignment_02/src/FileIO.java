import java.awt.*;
import java.io.*;
import java.util.Arrays;
import java.util.Random;

public class FileIO {
    public stacks loadFromFile() {
        stacks shapeStack = new stacks();
        try {
            File file = new File("C:\\Users\\hp\\IdeaProjects\\Assignment_02\\shapes.txt");
            BufferedReader reader = new BufferedReader(new FileReader(file));

            // Read the file line by line and create shapes
            String line;
            while ((line = reader.readLine()) != null) {
                Shape shape = null;
                //System.out.println(line);
                // Create the shape based on its type
                if (line.equals("Rectangle")) {
                    int x = Integer.parseInt(reader.readLine());
                    int y = Integer.parseInt(reader.readLine());
                    int height = Integer.parseInt(reader.readLine());
                    int width = Integer.parseInt(reader.readLine());
                    System.out.println("Rectangle");
                    System.out.println(x+"\n"+y+"\n"+height+"\n"+width+"\n");
                    shape = new Rectangle(width,height,new Point(x,y),getRandomColor());
                    shapeStack.push(shape);
                } else if (line.equals("Circle")) {
                    int x = Integer.parseInt(reader.readLine());
                    int y = Integer.parseInt(reader.readLine());
                    int size = Integer.parseInt(reader.readLine());
                    System.out.println("circle");
                    System.out.println(x+"\n"+y+"\n"+size+"\n");
                    shape=new Circle(size,new Point(x,y),getRandomColor());
                    shapeStack.push(shape);
                }
                else if (line.equals("Triangle")) {
                    int x1 = Integer.parseInt(reader.readLine());
                    int y1 = Integer.parseInt(reader.readLine());
                    int x2 = Integer.parseInt(reader.readLine());
                    int y2 = Integer.parseInt(reader.readLine());
                    int x3 = Integer.parseInt(reader.readLine());
                    int y3 = Integer.parseInt(reader.readLine());
                    shape=new Triangle();
                    shape.setColor(getRandomColor());
                    shape.addPoint(new Point(x1,y1));
                    shape.addPoint(new Point(x2,y2));
                    shape.addPoint(new Point(x3,y3));
                   // shape.setColor();
                    System.out.println("Triangle");
                    shapeStack.push(shape);
                }
            }

            return shapeStack;
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
    private Color getRandomColor() {
        Random random = new Random();
        float r = random.nextFloat();
        float g = random.nextFloat();
        float b = random.nextFloat();
        return new Color(r, g, b);
    }
    public void saveToFile(stacks stack) {
        try {
            File file = new File("C:\\Users\\hp\\IdeaProjects\\Assignment_02\\shapes.txt");
            FileWriter writer = new FileWriter(file);
            stacks current = new stacks();
            current=stack;
            while (current.head!=null) {
                Shape shape = current.pop();
                if (shape instanceof Rectangle) {
                    Rectangle rect = (Rectangle) shape;
                    writer.write("Rectangle\n");
                    writer.write(String.valueOf(rect.getCenter().x)+"\n");
                    writer.write(String.valueOf(rect.getCenter().y)+"\n");
                    writer.write(String.valueOf(rect.getHeight())+"\n");
                    writer.write(String.valueOf(rect.getWidth())+"\n");
                    //writer.write(rect.getColor());
                } else if (shape instanceof Circle) {
                    Circle circle = (Circle) shape;
                    writer.write("Circle\n");
                    writer.write(String.valueOf( circle.getCenter().x)+"\n");
                    writer.write(String.valueOf(circle.getCenter().y)+"\n");
                    writer.write(String.valueOf(circle.getSize())+"\n");
                   // writer.write(circle.getColor());
                } else if (shape instanceof Triangle) {
                    Triangle triangle = (Triangle) shape;
                    writer.write("Triangle\n");
                    writer.write(triangle.coordinates[0].x+"\n");
                    writer.write(triangle.coordinates[0].y+"\n");
                    writer.write(triangle.coordinates[1].x+"\n");
                    writer.write(triangle.coordinates[1].y+"\n");
                    writer.write(triangle.coordinates[2].x+"\n");
                    writer.write(triangle.coordinates[2].y+"\n");
                    //writer.write(triangle.getColor());
                }
            }
            writer.close();
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
}
