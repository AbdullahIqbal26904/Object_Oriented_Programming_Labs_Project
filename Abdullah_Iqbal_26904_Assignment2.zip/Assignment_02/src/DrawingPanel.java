import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;
public class DrawingPanel extends JPanel implements MouseListener, MouseMotionListener, KeyListener {
    /**
     *
     */
    private static final long serialVersionUID = 1L;
    int size;
    // PROPERTIES
    private final int DEFAULT_WIDTH  = 800;
    private final int DEFAULT_HEIGHT = 800;

    private int x1, y1, x2, y2;
    private int width,height;


    private Graphics g;
    Shape shapebeingdrawn;
    char shape;
     stacks shapeStack = new stacks();
    queue redo = new queue();
    Byte clicks=0;
    private String shapeType = "circle";
     DrawingPanel()
    {
        setBackground( Color.WHITE );
        setPreferredSize( new Dimension( DEFAULT_WIDTH, DEFAULT_HEIGHT ) );
        this.addMouseListener( this );
        this.addMouseMotionListener(this  );
        this.addKeyListener(this);
        setFocusable(true);
    }
    public void setstack(stacks a){
         this.shapeStack=a;
         setUpDrawingGraphics();
    }

    // METHOD
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
    }

    public void setUpDrawingGraphics() {
        g = getGraphics();
        g.setColor(Color.WHITE);
        g.fillRect(0, 0, 800, 800);
        Node current = null;
        if (shapeStack.head != null) {
            current = shapeStack.head;
        }
        while (current != null) {
            current.shape.Draw(g);
            current = current.next;
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        // TODO Auto-generated method stub
        if(SwingUtilities.isLeftMouseButton(e)&&shape=='3'){
                if (clicks == 0) {
                    shapebeingdrawn = new Triangle();
                }
        shapebeingdrawn.addPoint(new Point(e.getX(), e.getY()));
        clicks++;

        if (clicks == 3) {
            clicks = 0;
            shapebeingdrawn.setColor(getRandomColor());
            shapebeingdrawn.Draw(g);
            shapeStack.push(shapebeingdrawn);
        }
        }
    }

    private Color getRandomColor() {
        Random random = new Random();
        float r = random.nextFloat();
        float g = random.nextFloat();
        float b = random.nextFloat();
        return new Color(r, g, b);
    }

    @Override
    public void mousePressed(MouseEvent e) {
        // TODO Auto-generated method stub
        x1 = e.getX();
        y1 = e.getY();
        if(SwingUtilities.isLeftMouseButton(e))
        {
            if(shape=='1'){
                shapebeingdrawn = new Circle(size, new Point(x1, y1), getRandomColor());
                shapeStack.push(shapebeingdrawn);
                size=0;
            } else if (shape=='2') {
                shapebeingdrawn = new Rectangle(width,height,new Point(x1,y1), getRandomColor());
                shapeStack.push(shapebeingdrawn);
                ((Rectangle) shapebeingdrawn).setHeight(0);
                ((Rectangle) shapebeingdrawn).setWidth(0);
            }
            System.out.println("left mouse clicked");
        }
        else if(SwingUtilities.isRightMouseButton(e))
        {
            Shape s=  shapeStack.pop();
            redo.enqueue(s);
            System.out.println("right pressed and shape added to queue");
        }
        else if(SwingUtilities.isMiddleMouseButton(e))
        {
            shapeStack.push(redo.dequeue());
            System.out.println("middle pressed and shape removed from queue");
        }
        setUpDrawingGraphics();
    }

    @Override
    public void mouseReleased(MouseEvent e) {
    }


    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }

    @Override
    public void mouseDragged(MouseEvent e) {
        x2 = e.getX() ;
        y2 = e.getY() ;

        if(y2>800) y2=800;
        if(y2<0) y2=0;

        if(shape=='1'){
            shapebeingdrawn.setSize(2*(int)  Math.sqrt(Math.pow(x2-x1,2)+Math.pow(y2-y1,2)));
            shapebeingdrawn.Draw(g);
        } else if (shape=='2') {
             width=Math.abs(x1-x2);
             height=Math.abs(y1-y2);
            ((Rectangle) shapebeingdrawn).setWidth(width);
            ((Rectangle) shapebeingdrawn).setHeight(height);
            shapebeingdrawn.Draw(g);
        }
    }

    @Override
    public void mouseMoved(MouseEvent e) {
    }

    @Override
    public void keyTyped(KeyEvent e) {
        // TODO Auto-generated method stub

    }

    @Override
    public void keyPressed(KeyEvent e) {
        // TODO Auto-generated method stub
        shape=e.getKeyChar();
        g=getGraphics();
        if(shape=='1') {
            shapeType = "circle";
            displayshapename(g);
        } else if (shape=='2') {
            shapeType="Rectangle" ;
            displayshapename(g);
        } else if (shape=='3') {
            shapeType="Triangle";
            displayshapename(g);
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        // TODO Auto-generated method stub

    }
    public void displayshapename(Graphics g) {
        g.setColor(Color.GRAY);
        g.fillRect(50, 600, 190, 70);
        if (shapeType.equals("circle")) {
            g.setColor(Color.black);
            g.setFont(new Font("Serif", Font.PLAIN, 30));
            g.drawString("Circle", 80, 650);
        }
        if (shapeType.equals("Rectangle")) {

            g.setColor(Color.black);
            g.setFont(new Font("Serif", Font.PLAIN, 30));
            g.drawString("Rectangle", 80, 650);
        }
        if (shapeType.equals("Triangle")) {
            g.setColor(Color.black);
            g.setFont(new Font("Serif", Font.PLAIN, 30));
            g.drawString("Triangle", 80, 650);
        }
    }

}
