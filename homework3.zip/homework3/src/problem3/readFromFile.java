package problem3;

import problem2.DrawingCanvas2;
import problem2.Triangle;

import javax.swing.*;
import java.awt.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class readFromFile {
    public static void main(String[] args) throws FileNotFoundException {
        String s;
        JFrame m = new JFrame();
        DrawingCanvas1 h = new DrawingCanvas1();
        m.setSize(800,600);
        m.setVisible(true);
        File f1 = new File("C:\\Users\\hp\\IdeaProjects\\homework3\\shapes.txt");
        Scanner sc = new Scanner(f1);
        String[] arr;

        s = sc.next();
        if(s.equals("Triangle")){
            int[] xPoints = new int[3];
            int[] yPoints = new int[3];
            String a = sc.next();
            String b = sc.next();
            xPoints= stringToArray(a);
            yPoints=stringToArray(b);
            h.paintTriangle(m.getGraphics(), xPoints,yPoints);
        }
        s= sc.next();
        if(s.equals("Quadrilateral")){
            int[] xPoints = new int[4];
            int[] yPoints = new int[4];
            String a = sc.next();
            String b = sc.next();
            xPoints= stringToArray(a);
            yPoints=stringToArray(b);
            h.paintQuadrilateral(m.getGraphics(), xPoints,yPoints);
        }
        s= sc.next();
        if(s.equals("Hexagon")){
            int[] xPoints = new int[6];
            int[] yPoints = new int[6];
            String a = sc.next();
            String b = sc.next();
            xPoints= stringToArray(a);
            yPoints=stringToArray(b);
            h.paintHexagon(m.getGraphics(), xPoints,yPoints);
        }
        s= sc.next();
        if(s.equals("Pentagon")){
            int[] xPoints = new int[5];
            int[] yPoints = new int[5];
            String a = sc.next();
            String b = sc.next();
            xPoints= stringToArray(a);
            yPoints=stringToArray(b);
            h.paintPentagon(m.getGraphics(), xPoints,yPoints);
        }
        s= sc.next();
        if(s.equals("Pentagram")){
            int[] Points = new int[3];
            String a = sc.next();
            Points= stringToArray(a);
            h.paintPentagram(m.getGraphics(),Points);
        }
        s= sc.next();
        if(s.equals("Regular Pentagon")){
            int[] Points = new int[3];
            String a = sc.next();
            Points= stringToArray(a);
            h.paintRegularPentagon(m.getGraphics(),Points);
        }
        s= sc.next();
        if(s.equals("Regular Hexagon")){
            int[] Points = new int[3];
            String a = sc.next();
            Points= stringToArray(a);
            h.paintRegularHexagon(m.getGraphics(),Points);
        }

    }
    public static int[] stringToArray(String a){
        String[] numbers = a.split(",");
        int[] points = new int[numbers.length];

        for (int i = 0; i < points.length; i++) {
            points[i]=Integer.parseInt(numbers[i]);
            System.out.println(points[i]);
        }

        return points;

    }


}
