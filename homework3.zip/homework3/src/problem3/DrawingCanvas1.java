package problem3;

import problem2.*;

import java.awt.*;

public class DrawingCanvas1 {
    // These methods onwards are for problem 3
    // e.g they will read parameters from the file.
    public void paintTriangle(Graphics g, int[] a, int[] b){
        Triangle t1=new Triangle(a,b);
        t1.paint(g);
    }
    public void paintQuadrilateral(Graphics g,int[] a,int[] b){
        Quadrilateral q1 = new Quadrilateral(a,b);
        q1.paint(g);
    }
    public void paintHexagon(Graphics g,int[] a,int[] b){
        Hexagon h1 = new Hexagon(a,b);
        h1.paint(g);
    }
    public void paintPentagon(Graphics g,int[] a,int[] b){
        Pentagon p1 = new Pentagon(a,b);
        p1.paint(g);
    }
    public void paintPentagram(Graphics g,int[] a){
        Pentagram abcd = new Pentagram(a[0],a[1],a[2]);
        abcd.paint(g);
    }
    public void paintRegularPentagon(Graphics g,int[] a){
        RegularPentagon prp = new RegularPentagon(a[0],a[1],a[2]);
        prp.paint(g);
    }
    public void paintRegularHexagon(Graphics g,int[] a){
        RegularPentagon prp = new RegularPentagon(a[0],a[1],a[2]);
        prp.paint(g);
    }
}
