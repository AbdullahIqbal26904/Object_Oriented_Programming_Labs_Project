package problem2;

import java.awt.*;

public class Pentagram extends Polygon {
    int[] x2;
    int[] y2;

    public Pentagram(int x, int y, int R){
        int[] xP= new int[5];
        int[] yP=new int[5];
        int[] x2 = new int[5];
        int[] y2 = new int[5];
        for(int i=0;i<5;i++){
            x2[i]= x + (int) ((R/2.55)*Math.cos(Math.toRadians(126+i*72)));
            y2[i] = y + (int) ((R/2.55)*Math.sin(Math.toRadians(126+i*72)));
        }
        xP[0]= x + (int) (R*Math.cos(Math.toRadians(90+3*72)));
        yP[0] = y + (int) (R*Math.sin(Math.toRadians(90+3*72)));
        xP[1]= x + (int) (R*Math.cos(Math.toRadians(90+1*72)));
        yP[1] = y + (int) (R*Math.sin(Math.toRadians(90+1*72)));
        xP[2]= x + (int) (R*Math.cos(Math.toRadians(90+4*72)));
        yP[2] = y + (int) (R*Math.sin(Math.toRadians(90+4*72)));
        xP[3]= x + (int) (R*Math.cos(Math.toRadians(90+2*72)));
        yP[3] = y + (int) (R*Math.sin(Math.toRadians(90+2*72)));
        xP[4]= x + (int) (R*Math.cos(Math.toRadians(90+0*72)));
        yP[4] = y + (int) (R*Math.sin(Math.toRadians(90+0*72)));
        this.xpoints=xP;
        this.ypoints=yP;
        this.x2 = x2;
        this.y2 = y2;
    }

    public void paint(Graphics g){
        Polygon outside = new Polygon(xpoints, ypoints, 5);
        Polygon inside = new Polygon(x2, y2, 5);
        g.setColor(Color.red);
        g.fillPolygon(outside);
        g.fillPolygon(inside);
    }
}
