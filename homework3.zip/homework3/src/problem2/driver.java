package problem2;

import problem1.DrawingCanvas;

import javax.swing.*;

public class driver {
    public static void main(String[] args) {
        JFrame j = new JFrame();
        DrawingCanvas2 canvas2 = new DrawingCanvas2();
        j.add(canvas2);
        j.setSize(800,600);
        j.setVisible(true);
    }
}
