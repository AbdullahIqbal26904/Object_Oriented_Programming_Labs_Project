package problem2;

import java.awt.*;

public class Triangle extends Polygon {
    public Triangle(int[] xPoint, int[] yPoints){
        super(xPoint,yPoints,3);
    }
    public void paint(Graphics g){
        g.setColor(Color.gray);
        g.fillPolygon(this);
    }

}
