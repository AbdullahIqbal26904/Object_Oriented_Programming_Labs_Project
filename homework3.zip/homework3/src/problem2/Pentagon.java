package problem2;

import java.awt.*;

public class Pentagon extends Polygon {
    public Pentagon(int[] xPoint,int[] yPoints){
        super(xPoint,yPoints,5);

    }
    public void paint(Graphics g){
        g.setColor(Color.black);
        g.fillPolygon(this);
    }
}
