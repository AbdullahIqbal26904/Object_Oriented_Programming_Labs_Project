package problem2;

import java.awt.*;

public class RegularPentagon extends Polygon {


    public RegularPentagon(int x, int y, int R){
        int[] xP= new int[5];
        int[] yP=new int[5];

        for(int i=0;i<5;i++){
            xP[i]= x + (int) ((R)*Math.cos(Math.toRadians(126+i*72)));
            yP[i] = y + (int) ((R)*Math.sin(Math.toRadians(126+i*72)));
        }

        this.xpoints=xP;
        this.ypoints=yP;

    }

    public void paint(Graphics g){
        Polygon outside = new Polygon(xpoints, ypoints, 5);
        g.setColor(Color.red);
        g.fillPolygon(outside);
    }
}
