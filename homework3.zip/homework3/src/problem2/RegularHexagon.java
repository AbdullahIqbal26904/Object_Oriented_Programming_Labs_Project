package problem2;

import java.awt.*;

public class RegularHexagon extends Polygon {
    public RegularHexagon(int x, int y, int R){
        int[] xP= new int[6];
        int[] yP=new int[6];

        for(int i=0;i<6;i++){
            xP[i]= x + (int) (R*Math.cos(Math.toRadians(i*60)));
            yP[i] = y + (int) (R*Math.sin(Math.toRadians(i*60)));
        }

        this.xpoints=xP;
        this.ypoints=yP;

    }

    public void paint(Graphics g){
        Polygon outside = new Polygon(xpoints, ypoints, 6);
        g.setColor(Color.blue);
        g.fillPolygon(outside);
    }
}
