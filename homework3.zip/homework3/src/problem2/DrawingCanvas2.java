package problem2;

import java.awt.*;

public class DrawingCanvas2 extends Canvas {
    public void paint(Graphics g){
        int[] tx ={90*3,20*3,50*3};
        int[] ty={80*3,80*3,20*3};
        Triangle t1 = new Triangle(tx,ty);
        //t1.paint(g);
        int[] qx ={120*3,90*3,20*3,50*3};
        int[] qy={20*3,80*3,80*3,20*3};
        Quadrilateral q1 = new Quadrilateral(qx,qy);
        //q1.paint(g);
        int[] px ={70*3,120*3,90*3,20*3,50*3};
        int[] py={0,20*3,80*3,80*3,20*3};
        Pentagon p1 = new Pentagon(px,py);
        //p1.paint(g);
        int[] hx ={400+400,400+200,400-200,400-400,200,400+200};
        int[] hy={300,300+300,300+300,300,0,0};
        Hexagon h1 = new Hexagon(hx,hy);
       // h1.paint(g);
        Pentagram abcd = new Pentagram(400,300,200);
        abcd.paint(g);
        RegularPentagon r1 = new RegularPentagon(400,300,200);
        //r1.paint(g);
        RegularHexagon h2 = new RegularHexagon(400,300,200);
        //h2.paint(g);
    }
}
