package problem2;

import java.awt.*;

public class Quadrilateral extends Polygon {
    public Quadrilateral(int[] xPoint,int[] yPoints){
        super(xPoint,yPoints,4);

    }
    public void paint(Graphics g){
        g.setColor(Color.yellow);
        g.fillPolygon(this);
    }
}
