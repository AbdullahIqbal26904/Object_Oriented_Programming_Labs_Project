package problem1;

import java.awt.*;

public class DrawingCanvas extends Canvas {

    public void paint(Graphics g) {
        Rectangle r = new Rectangle(400, 300, 200, 100,"hello", Color.BLUE, Color.black, 2);
        r.paint(g);

    }

}
