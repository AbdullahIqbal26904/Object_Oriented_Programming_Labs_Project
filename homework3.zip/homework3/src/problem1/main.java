package problem1;

import javax.swing.*;
import java.awt.*;


public class main extends JPanel {
    public static void main(String[] args)
    {
        DrawingCanvas canvas=new DrawingCanvas();
        JFrame frame=new JFrame();
        frame.add(canvas);
        frame.setSize(800,600);
        //f.setLayout(null);
        frame.setVisible(true);
    }
}
