package problem1;

import javax.swing.*;
import java.awt.*;

public class Rectangle {
    int width;
    int height;
    String text;
    point center;
    Color button_color;
    Color stroke_color;
    int stroke;

    public Rectangle(int x, int y, int width, int height, String text, Color button_color, Color stroke_color, int stroke)
    {
        center = new point(x, y);
        this.width = width;
        this.height = height;
        this.text=text;
        this.button_color = button_color;
        this.stroke_color = stroke_color;
        this.stroke = stroke;
    }
    public void paint(Graphics g)
    {
        g.setColor(stroke_color);
        g.fillRect(center.x - width/2 - stroke , center.y - height/2 - stroke, width + stroke*2, height + stroke*2);
        g.setColor(button_color);
        g.fillRect(center.x - width/2 , center.y - height/2, width, height);
        g.setColor(Color.gray);
        Font f = new Font(Font.SERIF,Font.PLAIN,height/2);
        g.setFont(f);
        FontMetrics e = g.getFontMetrics();
        g.drawString(text, center.x-e.stringWidth(text)/2,center.y+e.getHeight()/2-e.getAscent()/2);

    }
}
