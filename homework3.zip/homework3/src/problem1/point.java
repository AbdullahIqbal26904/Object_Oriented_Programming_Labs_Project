package problem1;

public class point {
    int x;
    int y;
    public point(int x,int y){
        this.x=x;
        this.y=y;
    }
}
